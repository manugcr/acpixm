/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20230628 (64-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembly of /home/eclypsium/Desktop/output/bgrt.dat, Tue Jul 29 10:45:16 2025
 *
 * ACPI Data Table [BGRT]
 *
 * Format: [HexOffset DecimalOffset ByteLength]  FieldName : FieldValue (in hex)
 */

[000h 0000 004h]                   Signature : "BGRT"    [Boot Graphics Resource Table]
[004h 0004 004h]                Table Length : 00000038
[008h 0008 001h]                    Revision : 01
[009h 0009 001h]                    Checksum : 5A
[00Ah 0010 006h]                      Oem ID : "INSYDE"
[010h 0016 008h]                Oem Table ID : "H2O BIOS"
[018h 0024 004h]                Oem Revision : 00000001
[01Ch 0028 004h]             Asl Compiler ID : "ACPI"
[020h 0032 004h]       Asl Compiler Revision : 00040000

[024h 0036 002h]                     Version : 0001
[026h 0038 001h]      Status (decoded below) : 00
                                   Displayed : 0
                          Orientation Offset : 0
[027h 0039 001h]                  Image Type : 00
[028h 0040 008h]               Image Address : 0000000023B06000
[030h 0048 004h]               Image OffsetX : 00000240
[034h 0052 004h]               Image OffsetY : 000000C4

Raw Table Data: Length 56 (0x38)

    0000: 42 47 52 54 38 00 00 00 01 5A 49 4E 53 59 44 45  // BGRT8....ZINSYDE
    0010: 48 32 4F 20 42 49 4F 53 01 00 00 00 41 43 50 49  // H2O BIOS....ACPI
    0020: 00 00 04 00 01 00 00 00 00 60 B0 23 00 00 00 00  // .........`.#....
    0030: 40 02 00 00 C4 00 00 00                          // @.......
