/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20230628 (64-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembling to symbolic ASL+ operators
 *
 * Disassembly of /home/eclypsium/Desktop/output/ssdt8.dat, Tue Jul 29 10:45:16 2025
 *
 * Original Table Header:
 *     Signature        "SSDT"
 *     Length           0x00005112 (20754)
 *     Revision         0x02
 *     Checksum         0xDE
 *     OEM ID           "LENOVO"
 *     OEM Table ID     "CB-01   "
 *     OEM Revision     0x00000001 (1)
 *     Compiler ID      "INTL"
 *     Compiler Version 0x20160422 (538313762)
 */
DefinitionBlock ("", "SSDT", 2, "LENOVO", "CB-01   ", 0x00000001)
{
    External (_SB_.AAC0, FieldUnitObj)
    External (_SB_.ACRT, FieldUnitObj)
    External (_SB_.APSV, FieldUnitObj)
    External (_SB_.CBMI, FieldUnitObj)
    External (_SB_.CFGD, FieldUnitObj)
    External (_SB_.CLVL, FieldUnitObj)
    External (_SB_.CPPC, FieldUnitObj)
    External (_SB_.CTC0, FieldUnitObj)
    External (_SB_.CTC1, FieldUnitObj)
    External (_SB_.CTC2, FieldUnitObj)
    External (_SB_.OSCP, IntObj)
    External (_SB_.PAGD, DeviceObj)
    External (_SB_.PAGD._PUR, PkgObj)
    External (_SB_.PAGD._STA, MethodObj)    // 0 Arguments
    External (_SB_.PCI0, DeviceObj)
    External (_SB_.PCI0.B0D4, DeviceObj)
    External (_SB_.PCI0.GFX0.DD1F._BCL, MethodObj)    // 0 Arguments
    External (_SB_.PCI0.GFX0.DD1F._BCM, MethodObj)    // 1 Arguments
    External (_SB_.PCI0.GFX0.DD1F._BQC, MethodObj)    // 0 Arguments
    External (_SB_.PCI0.GFX0.DD1F._DCS, MethodObj)    // 0 Arguments
    External (_SB_.PCI0.LPCB.EC0_, DeviceObj)
    External (_SB_.PCI0.LPCB.EC0_.CTMP, IntObj)
    External (_SB_.PCI0.LPCB.EC0_.EST1, IntObj)
    External (_SB_.PCI0.LPCB.EC0_.EST2, IntObj)
    External (_SB_.PCI0.LPCB.EC0_.EST3, IntObj)
    External (_SB_.PCI0.LPCB.ECOK, MethodObj)    // 0 Arguments
    External (_SB_.PCI0.LPCB.H_EC.CMPP, FieldUnitObj)
    External (_SB_.PCI0.LPCB.H_EC.RBHF, FieldUnitObj)
    External (_SB_.PCI0.LPCB.H_EC.UVTH, FieldUnitObj)
    External (_SB_.PCI0.LPCB.H_EC.VBNL, FieldUnitObj)
    External (_SB_.PCI0.MHBR, FieldUnitObj)
    External (_SB_.PL10, FieldUnitObj)
    External (_SB_.PL11, FieldUnitObj)
    External (_SB_.PL12, FieldUnitObj)
    External (_SB_.PL20, FieldUnitObj)
    External (_SB_.PL21, FieldUnitObj)
    External (_SB_.PL22, FieldUnitObj)
    External (_SB_.PLW0, FieldUnitObj)
    External (_SB_.PLW1, FieldUnitObj)
    External (_SB_.PLW2, FieldUnitObj)
    External (_SB_.PR00, ProcessorObj)
    External (_SB_.PR00._PSS, MethodObj)    // 0 Arguments
    External (_SB_.PR00._TPC, IntObj)
    External (_SB_.PR00._TSD, MethodObj)    // 0 Arguments
    External (_SB_.PR00._TSS, MethodObj)    // 0 Arguments
    External (_SB_.PR00.LPSS, PkgObj)
    External (_SB_.PR00.TPSS, PkgObj)
    External (_SB_.PR00.TSMC, PkgObj)
    External (_SB_.PR00.TSMF, PkgObj)
    External (_SB_.PR01, ProcessorObj)
    External (_SB_.PR02, ProcessorObj)
    External (_SB_.PR03, ProcessorObj)
    External (_SB_.PR04, ProcessorObj)
    External (_SB_.PR05, ProcessorObj)
    External (_SB_.PR06, ProcessorObj)
    External (_SB_.PR07, ProcessorObj)
    External (_SB_.PR08, ProcessorObj)
    External (_SB_.PR09, ProcessorObj)
    External (_SB_.PR10, ProcessorObj)
    External (_SB_.PR11, ProcessorObj)
    External (_SB_.PR12, ProcessorObj)
    External (_SB_.PR13, ProcessorObj)
    External (_SB_.PR14, ProcessorObj)
    External (_SB_.PR15, ProcessorObj)
    External (_SB_.SLPB, DeviceObj)
    External (_SB_.TAR0, FieldUnitObj)
    External (_SB_.TAR1, FieldUnitObj)
    External (_SB_.TAR2, FieldUnitObj)
    External (_TZ_.ETMD, IntObj)
    External (_TZ_.TZ00, ThermalZoneObj)
    External (ACTT, IntObj)
    External (ATMC, IntObj)
    External (ATPC, IntObj)
    External (BATR, IntObj)
    External (CA2D, IntObj)
    External (CHGE, IntObj)
    External (CPU3, IntObj)
    External (CPU5, IntObj)
    External (CPU7, IntObj)
    External (CPUS, IntObj)
    External (CRTT, IntObj)
    External (CTDP, IntObj)
    External (DCFE, IntObj)
    External (DGPX, IntObj)
    External (DISE, IntObj)
    External (DPHL, IntObj)
    External (DPLL, IntObj)
    External (DPTF, IntObj)
    External (FND1, IntObj)
    External (HIDW, MethodObj)    // 4 Arguments
    External (HIWC, MethodObj)    // 1 Arguments
    External (IN34, IntObj)
    External (IPCS, MethodObj)    // 7 Arguments
    External (LPER, IntObj)
    External (LPOE, IntObj)
    External (LPOP, IntObj)
    External (LPOS, IntObj)
    External (LPOW, IntObj)
    External (MPL0, IntObj)
    External (MPL1, IntObj)
    External (MPL2, IntObj)
    External (ODV0, IntObj)
    External (ODV1, IntObj)
    External (ODV2, IntObj)
    External (ODV3, IntObj)
    External (ODV4, IntObj)
    External (ODV5, IntObj)
    External (ODV6, IntObj)
    External (ODV7, IntObj)
    External (ODV8, IntObj)
    External (ODV9, IntObj)
    External (ODVA, IntObj)
    External (ODVB, IntObj)
    External (ODVC, IntObj)
    External (ODVD, IntObj)
    External (ODVE, IntObj)
    External (ODVF, IntObj)
    External (PC00, IntObj)
    External (PCHE, FieldUnitObj)
    External (PNHM, IntObj)
    External (PPPR, IntObj)
    External (PPSZ, IntObj)
    External (PSVT, IntObj)
    External (PTMC, IntObj)
    External (PTPC, IntObj)
    External (PWRE, IntObj)
    External (PWRS, IntObj)
    External (S1AT, IntObj)
    External (S1CT, IntObj)
    External (S1DE, IntObj)
    External (S1HT, IntObj)
    External (S1PT, IntObj)
    External (S1S3, IntObj)
    External (S2AT, IntObj)
    External (S2CT, IntObj)
    External (S2DE, IntObj)
    External (S2HT, IntObj)
    External (S2PT, IntObj)
    External (S2S3, IntObj)
    External (S3AT, IntObj)
    External (S3CT, IntObj)
    External (S3DE, IntObj)
    External (S3HT, IntObj)
    External (S3PT, IntObj)
    External (S3S3, IntObj)
    External (S4AT, IntObj)
    External (S4CT, IntObj)
    External (S4DE, IntObj)
    External (S4HT, IntObj)
    External (S4PT, IntObj)
    External (S4S3, IntObj)
    External (S5AT, IntObj)
    External (S5CT, IntObj)
    External (S5DE, IntObj)
    External (S5HT, IntObj)
    External (S5PT, IntObj)
    External (S5S3, IntObj)
    External (SAC3, IntObj)
    External (SACT, IntObj)
    External (SADE, IntObj)
    External (SAHT, IntObj)
    External (SAT1, IntObj)
    External (SAT2, IntObj)
    External (SC31, IntObj)
    External (SC32, IntObj)
    External (SCT1, IntObj)
    External (SCT2, IntObj)
    External (SGE1, IntObj)
    External (SGE2, IntObj)
    External (SHT1, IntObj)
    External (SHT2, IntObj)
    External (SORC, IntObj)
    External (SPT1, IntObj)
    External (SPT2, IntObj)
    External (SSP1, IntObj)
    External (SSP2, IntObj)
    External (SSP3, IntObj)
    External (SSP4, IntObj)
    External (SSP5, IntObj)
    External (TCNT, IntObj)
    External (TSOD, IntObj)
    External (V1AT, IntObj)
    External (V1C3, IntObj)
    External (V1CR, IntObj)
    External (V1HT, IntObj)
    External (V1PV, IntObj)
    External (V2AT, IntObj)
    External (V2C3, IntObj)
    External (V2CR, IntObj)
    External (V2HT, IntObj)
    External (V2PV, IntObj)
    External (VSP1, IntObj)
    External (VSP2, IntObj)
    External (WAND, IntObj)
    External (WLC3, IntObj)
    External (WRAT, IntObj)
    External (WRCT, IntObj)
    External (WRFD, IntObj)
    External (WRHT, IntObj)
    External (WRPT, IntObj)
    External (WTSP, IntObj)
    External (WWAT, IntObj)
    External (WWC3, IntObj)
    External (WWCT, IntObj)
    External (WWHT, IntObj)
    External (WWPT, IntObj)

    Scope (\_SB)
    {
        Device (IETM)
        {
            Name (_HID, EisaId ("INT3400") /* Intel Dynamic Power Performance Management */)  // _HID: Hardware ID
            Method (_DSM, 4, Serialized)  // _DSM: Device-Specific Method
            {
                If (CondRefOf (HIWC))
                {
                    If (HIWC (Arg0))
                    {
                        If (CondRefOf (HIDW))
                        {
                            Return (HIDW (Arg0, Arg1, Arg2, Arg3))
                        }
                    }
                }

                Return (Buffer (One)
                {
                     0x00                                             // .
                })
            }

            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If (((\DPTF == One) && (\IN34 == One)))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Name (PTRP, Zero)
            Name (PSEM, Zero)
            Name (ATRP, Zero)
            Name (ASEM, Zero)
            Name (YTRP, Zero)
            Name (YSEM, Zero)
            Method (_OSC, 4, Serialized)  // _OSC: Operating System Capabilities
            {
                CreateDWordField (Arg3, Zero, STS1)
                CreateDWordField (Arg3, 0x04, CAP1)
                If ((Arg1 != One))
                {
                    STS1 &= 0xFFFFFF00
                    STS1 |= 0x0A
                    Return (Arg3)
                }

                If ((Arg2 != 0x02))
                {
                    STS1 &= 0xFFFFFF00
                    STS1 |= 0x02
                    Return (Arg3)
                }

                If (CondRefOf (\_SB.APSV))
                {
                    If ((PSEM == Zero))
                    {
                        PSEM = One
                        PTRP = \_SB.APSV /* External reference */
                    }
                }

                If (CondRefOf (\_SB.AAC0))
                {
                    If ((ASEM == Zero))
                    {
                        ASEM = One
                        ATRP = \_SB.AAC0 /* External reference */
                    }
                }

                If (CondRefOf (\_SB.ACRT))
                {
                    If ((YSEM == Zero))
                    {
                        YSEM = One
                        YTRP = \_SB.ACRT /* External reference */
                    }
                }

                If ((Arg0 == ToUUID ("b23ba85d-c8b7-3542-88de-8de2ffcfd698") /* Unknown UUID */))
                {
                    If (~(STS1 & One))
                    {
                        If ((CAP1 & One))
                        {
                            If ((CAP1 & 0x02))
                            {
                                \_SB.AAC0 = 0x6E
                                \_TZ.ETMD = Zero
                            }
                            Else
                            {
                                \_SB.AAC0 = ATRP /* \_SB_.IETM.ATRP */
                                \_TZ.ETMD = One
                            }

                            If ((CAP1 & 0x04))
                            {
                                \_SB.APSV = 0x6E
                            }
                            Else
                            {
                                \_SB.APSV = PTRP /* \_SB_.IETM.PTRP */
                            }

                            If ((CAP1 & 0x08))
                            {
                                \_SB.ACRT = 0xD2
                            }
                            Else
                            {
                                \_SB.ACRT = YTRP /* \_SB_.IETM.YTRP */
                            }

                            If (CondRefOf (\TZ.TZ00))
                            {
                                Notify (\_TZ.TZ00, 0x81) // Information Change
                            }
                        }
                        Else
                        {
                            \_SB.ACRT = YTRP /* \_SB_.IETM.YTRP */
                            \_SB.APSV = PTRP /* \_SB_.IETM.PTRP */
                            \_SB.AAC0 = ATRP /* \_SB_.IETM.ATRP */
                            \_TZ.ETMD = One
                        }
                    }

                    Return (Arg3)
                }

                Return (Arg3)
            }

            Method (DCFG, 0, NotSerialized)
            {
                Return (\DCFE) /* External reference */
            }

            Name (ODVX, Package (0x14)
            {
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero, 
                Zero
            })
            Method (ODVP, 0, Serialized)
            {
                ODVX [Zero] = \ODV0 /* External reference */
                ODVX [One] = \ODV1 /* External reference */
                ODVX [0x02] = \ODV2 /* External reference */
                ODVX [0x03] = \ODV3 /* External reference */
                ODVX [0x04] = \ODV4 /* External reference */
                ODVX [0x05] = \ODV5 /* External reference */
                ODVX [0x06] = \ODV6 /* External reference */
                ODVX [0x07] = \ODV7 /* External reference */
                ODVX [0x08] = \ODV8 /* External reference */
                ODVX [0x09] = \ODV9 /* External reference */
                ODVX [0x0A] = \ODVA /* External reference */
                ODVX [0x0B] = \ODVB /* External reference */
                ODVX [0x0C] = \ODVC /* External reference */
                ODVX [0x0D] = \ODVD /* External reference */
                ODVX [0x0E] = \ODVE /* External reference */
                ODVX [0x0F] = \ODVF /* External reference */
                ODVX [0x10] = \CPU3 /* External reference */
                ODVX [0x11] = \CPU5 /* External reference */
                ODVX [0x12] = \DGPX /* External reference */
                ODVX [0x13] = \CPU7 /* External reference */
                Return (ODVX) /* \_SB_.IETM.ODVX */
            }
        }
    }

    Scope (\_SB.IETM)
    {
        Method (KTOC, 1, Serialized)
        {
            If ((Arg0 > 0x0AAC))
            {
                Return (((Arg0 - 0x0AAC) / 0x0A))
            }
            Else
            {
                Return (Zero)
            }
        }

        Method (CTOK, 1, Serialized)
        {
            Return (((Arg0 * 0x0A) + 0x0AAC))
        }

        Method (C10K, 1, Serialized)
        {
            Name (TMP1, Buffer (0x10)
            {
                 0x00                                             // .
            })
            CreateByteField (TMP1, Zero, TMPL)
            CreateByteField (TMP1, One, TMPH)
            Local0 = (Arg0 + 0x0AAC)
            TMPL = (Local0 & 0xFF)
            TMPH = ((Local0 & 0xFF00) >> 0x08)
            ToInteger (TMP1, Local1)
            Return (Local1)
        }

        Method (K10C, 1, Serialized)
        {
            If ((Arg0 > 0x0AAC))
            {
                Return ((Arg0 - 0x0AAC))
            }
            Else
            {
                Return (Zero)
            }
        }
    }

    Scope (\_SB.PCI0.B0D4)
    {
        Name (PFLG, Zero)
        Method (_STA, 0, NotSerialized)  // _STA: Status
        {
            If ((\SADE == One))
            {
                Return (0x0F)
            }
            Else
            {
                Return (Zero)
            }
        }

        OperationRegion (MBAR, SystemMemory, ((MHBR << 0x0F) + 0x5000), 0x1000)
        Field (MBAR, ByteAcc, NoLock, Preserve)
        {
            Offset (0x930), 
            PTDP,   15, 
            Offset (0x932), 
            PMIN,   15, 
            Offset (0x934), 
            PMAX,   15, 
            Offset (0x936), 
            TMAX,   7, 
            Offset (0x938), 
            PWRU,   4, 
            Offset (0x939), 
            EGYU,   5, 
            Offset (0x93A), 
            TIMU,   4, 
            Offset (0x958), 
            Offset (0x95C), 
            LPMS,   1, 
            CTNL,   2, 
            Offset (0x978), 
            PCTP,   8, 
            Offset (0x998), 
            RP0C,   8, 
            RP1C,   8, 
            RPNC,   8, 
            Offset (0xF3C), 
            TRAT,   8, 
            Offset (0xF40), 
            PTD1,   15, 
            Offset (0xF42), 
            TRA1,   8, 
            Offset (0xF44), 
            PMX1,   15, 
            Offset (0xF46), 
            PMN1,   15, 
            Offset (0xF48), 
            PTD2,   15, 
            Offset (0xF4A), 
            TRA2,   8, 
            Offset (0xF4C), 
            PMX2,   15, 
            Offset (0xF4E), 
            PMN2,   15, 
            Offset (0xF50), 
            CTCL,   2, 
                ,   29, 
            CLCK,   1, 
            MNTR,   8
        }

        Name (XPCC, Zero)
        Method (PPCC, 0, Serialized)
        {
            If (((XPCC == Zero) && CondRefOf (\_SB.CBMI)))
            {
                Switch (ToInteger (\_SB.CBMI))
                {
                    Case (Zero)
                    {
                        If (((\_SB.CLVL >= One) && (\_SB.CLVL <= 0x03)))
                        {
                            CPL0 ()
                            XPCC = One
                        }
                    }
                    Case (One)
                    {
                        If (((\_SB.CLVL == 0x02) || (\_SB.CLVL == 0x03)))
                        {
                            CPL1 ()
                            XPCC = One
                        }
                    }
                    Case (0x02)
                    {
                        If ((\_SB.CLVL == 0x03))
                        {
                            CPL2 ()
                            XPCC = One
                        }
                    }

                }
            }

            Return (NPCC) /* \_SB_.PCI0.B0D4.NPCC */
        }

        Name (NPCC, Package (0x03)
        {
            0x02, 
            Package (0x06)
            {
                Zero, 
                0x88B8, 
                0xAFC8, 
                0x6D60, 
                0x7D00, 
                0x03E8
            }, 

            Package (0x06)
            {
                One, 
                0xDBBA, 
                0xDBBA, 
                Zero, 
                Zero, 
                0x03E8
            }
        })
        Method (CPNU, 2, Serialized)
        {
            Name (CNVT, Zero)
            Name (PPUU, Zero)
            Name (RMDR, Zero)
            If ((PWRU == Zero))
            {
                PPUU = One
            }
            Else
            {
                PPUU = (PWRU-- << 0x02)
            }

            Divide (Arg0, PPUU, RMDR, CNVT) /* \_SB_.PCI0.B0D4.CPNU.CNVT */
            If ((Arg1 == Zero))
            {
                Return (CNVT) /* \_SB_.PCI0.B0D4.CPNU.CNVT */
            }
            Else
            {
                CNVT *= 0x03E8
                RMDR *= 0x03E8
                RMDR /= PPUU
                CNVT += RMDR /* \_SB_.PCI0.B0D4.CPNU.RMDR */
                Return (CNVT) /* \_SB_.PCI0.B0D4.CPNU.CNVT */
            }
        }

        Method (CPL0, 0, NotSerialized)
        {
            \_SB.PCI0.B0D4.NPCC [Zero] = 0x02
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [Zero] = Zero
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [One] = \MPL0 /* External reference */
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x02] = CPNU (\_SB.PL10, One)
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x03] = (\_SB.PLW0 * 0x03E8)
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x04] = ((\_SB.PLW0 * 0x03E8
                ) + 0x0FA0)
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x05] = PPSZ /* External reference */
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [Zero] = One
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [One] = CPNU (\_SB.PL20, One)
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x02] = CPNU (\_SB.PL20, One)
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x03] = Zero
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x04] = Zero
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x05] = PPSZ /* External reference */
        }

        Method (CPL1, 0, NotSerialized)
        {
            \_SB.PCI0.B0D4.NPCC [Zero] = 0x02
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [Zero] = Zero
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [One] = \MPL1 /* External reference */
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x02] = CPNU (\_SB.PL11, One)
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x03] = (\_SB.PLW1 * 0x03E8)
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x04] = ((\_SB.PLW1 * 0x03E8
                ) + 0x0FA0)
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x05] = PPSZ /* External reference */
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [Zero] = One
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [One] = CPNU (\_SB.PL21, One)
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x02] = CPNU (\_SB.PL21, One)
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x03] = Zero
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x04] = Zero
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x05] = PPSZ /* External reference */
        }

        Method (CPL2, 0, NotSerialized)
        {
            \_SB.PCI0.B0D4.NPCC [Zero] = 0x02
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [Zero] = Zero
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [One] = \MPL2 /* External reference */
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x02] = CPNU (\_SB.PL12, One)
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x03] = (\_SB.PLW2 * 0x03E8)
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x04] = ((\_SB.PLW2 * 0x03E8
                ) + 0x0FA0)
            DerefOf (\_SB.PCI0.B0D4.NPCC [One]) [0x05] = PPSZ /* External reference */
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [Zero] = One
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [One] = CPNU (\_SB.PL22, One)
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x02] = CPNU (\_SB.PL22, One)
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x03] = Zero
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x04] = Zero
            DerefOf (\_SB.PCI0.B0D4.NPCC [0x02]) [0x05] = PPSZ /* External reference */
        }

        Name (LSTM, Zero)
        Name (_PPC, Zero)  // _PPC: Performance Present Capabilities
        Method (SPPC, 1, Serialized)
        {
            If (CondRefOf (\_SB.CPPC))
            {
                \_SB.CPPC = Arg0
            }

            Switch (ToInteger (\TCNT))
            {
                Case (0x10)
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                    Notify (\_SB.PR01, 0x80) // Status Change
                    Notify (\_SB.PR02, 0x80) // Status Change
                    Notify (\_SB.PR03, 0x80) // Status Change
                    Notify (\_SB.PR04, 0x80) // Status Change
                    Notify (\_SB.PR05, 0x80) // Status Change
                    Notify (\_SB.PR06, 0x80) // Status Change
                    Notify (\_SB.PR07, 0x80) // Status Change
                    Notify (\_SB.PR08, 0x80) // Status Change
                    Notify (\_SB.PR09, 0x80) // Status Change
                    Notify (\_SB.PR10, 0x80) // Status Change
                    Notify (\_SB.PR11, 0x80) // Status Change
                    Notify (\_SB.PR12, 0x80) // Status Change
                    Notify (\_SB.PR13, 0x80) // Status Change
                    Notify (\_SB.PR14, 0x80) // Status Change
                    Notify (\_SB.PR15, 0x80) // Status Change
                }
                Case (0x0E)
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                    Notify (\_SB.PR01, 0x80) // Status Change
                    Notify (\_SB.PR02, 0x80) // Status Change
                    Notify (\_SB.PR03, 0x80) // Status Change
                    Notify (\_SB.PR04, 0x80) // Status Change
                    Notify (\_SB.PR05, 0x80) // Status Change
                    Notify (\_SB.PR06, 0x80) // Status Change
                    Notify (\_SB.PR07, 0x80) // Status Change
                    Notify (\_SB.PR08, 0x80) // Status Change
                    Notify (\_SB.PR09, 0x80) // Status Change
                    Notify (\_SB.PR10, 0x80) // Status Change
                    Notify (\_SB.PR11, 0x80) // Status Change
                    Notify (\_SB.PR12, 0x80) // Status Change
                    Notify (\_SB.PR13, 0x80) // Status Change
                }
                Case (0x0C)
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                    Notify (\_SB.PR01, 0x80) // Status Change
                    Notify (\_SB.PR02, 0x80) // Status Change
                    Notify (\_SB.PR03, 0x80) // Status Change
                    Notify (\_SB.PR04, 0x80) // Status Change
                    Notify (\_SB.PR05, 0x80) // Status Change
                    Notify (\_SB.PR06, 0x80) // Status Change
                    Notify (\_SB.PR07, 0x80) // Status Change
                    Notify (\_SB.PR08, 0x80) // Status Change
                    Notify (\_SB.PR09, 0x80) // Status Change
                    Notify (\_SB.PR10, 0x80) // Status Change
                    Notify (\_SB.PR11, 0x80) // Status Change
                }
                Case (0x0A)
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                    Notify (\_SB.PR01, 0x80) // Status Change
                    Notify (\_SB.PR02, 0x80) // Status Change
                    Notify (\_SB.PR03, 0x80) // Status Change
                    Notify (\_SB.PR04, 0x80) // Status Change
                    Notify (\_SB.PR05, 0x80) // Status Change
                    Notify (\_SB.PR06, 0x80) // Status Change
                    Notify (\_SB.PR07, 0x80) // Status Change
                    Notify (\_SB.PR08, 0x80) // Status Change
                    Notify (\_SB.PR09, 0x80) // Status Change
                }
                Case (0x08)
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                    Notify (\_SB.PR01, 0x80) // Status Change
                    Notify (\_SB.PR02, 0x80) // Status Change
                    Notify (\_SB.PR03, 0x80) // Status Change
                    Notify (\_SB.PR04, 0x80) // Status Change
                    Notify (\_SB.PR05, 0x80) // Status Change
                    Notify (\_SB.PR06, 0x80) // Status Change
                    Notify (\_SB.PR07, 0x80) // Status Change
                }
                Case (0x07)
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                    Notify (\_SB.PR01, 0x80) // Status Change
                    Notify (\_SB.PR02, 0x80) // Status Change
                    Notify (\_SB.PR03, 0x80) // Status Change
                    Notify (\_SB.PR04, 0x80) // Status Change
                    Notify (\_SB.PR05, 0x80) // Status Change
                    Notify (\_SB.PR06, 0x80) // Status Change
                }
                Case (0x06)
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                    Notify (\_SB.PR01, 0x80) // Status Change
                    Notify (\_SB.PR02, 0x80) // Status Change
                    Notify (\_SB.PR03, 0x80) // Status Change
                    Notify (\_SB.PR04, 0x80) // Status Change
                    Notify (\_SB.PR05, 0x80) // Status Change
                }
                Case (0x05)
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                    Notify (\_SB.PR01, 0x80) // Status Change
                    Notify (\_SB.PR02, 0x80) // Status Change
                    Notify (\_SB.PR03, 0x80) // Status Change
                    Notify (\_SB.PR04, 0x80) // Status Change
                }
                Case (0x04)
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                    Notify (\_SB.PR01, 0x80) // Status Change
                    Notify (\_SB.PR02, 0x80) // Status Change
                    Notify (\_SB.PR03, 0x80) // Status Change
                }
                Case (0x03)
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                    Notify (\_SB.PR01, 0x80) // Status Change
                    Notify (\_SB.PR02, 0x80) // Status Change
                }
                Case (0x02)
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                    Notify (\_SB.PR01, 0x80) // Status Change
                }
                Default
                {
                    Notify (\_SB.PR00, 0x80) // Status Change
                }

            }
        }

        Name (TLPO, Package (0x06)
        {
            One, 
            One, 
            Zero, 
            One, 
            One, 
            0x02
        })
        Method (CLPO, 0, NotSerialized)
        {
            TLPO [One] = LPOE /* External reference */
            If (CondRefOf (\_SB.PR00._PSS))
            {
                If ((\_SB.OSCP & 0x0400))
                {
                    Local1 = SizeOf (\_SB.PR00.TPSS)
                }
                Else
                {
                    Local1 = SizeOf (\_SB.PR00.LPSS)
                }
            }
            Else
            {
                Local1 = Zero
            }

            If ((LPOP < Local1))
            {
                TLPO [0x02] = LPOP /* External reference */
            }
            Else
            {
                Local1--
                TLPO [0x02] = Local1
            }

            TLPO [0x03] = LPOS /* External reference */
            TLPO [0x04] = LPOW /* External reference */
            TLPO [0x05] = LPER /* External reference */
            Return (TLPO) /* \_SB_.PCI0.B0D4.TLPO */
        }

        Method (SPUR, 1, NotSerialized)
        {
            If ((Arg0 <= \TCNT))
            {
                If ((\_SB.PAGD._STA () == 0x0F))
                {
                    \_SB.PAGD._PUR [One] = Arg0
                    Notify (\_SB.PAGD, 0x80) // Status Change
                }
            }
        }

        Name (AEXL, Package (0x04)
        {
            "svchost.exe", 
            "dllhost.exe", 
            "smss.exe", 
            "WinSAT.exe"
        })
        Method (PCCC, 0, Serialized)
        {
            PCCX [Zero] = One
            Switch (ToInteger (CPNU (PTDP, Zero)))
            {
                Case (0x39)
                {
                    DerefOf (PCCX [One]) [Zero] = 0xA7F8
                    DerefOf (PCCX [One]) [One] = 0x00017318
                }
                Case (0x2F)
                {
                    DerefOf (PCCX [One]) [Zero] = 0x9858
                    DerefOf (PCCX [One]) [One] = 0x00014C08
                }
                Case (0x25)
                {
                    DerefOf (PCCX [One]) [Zero] = 0x7148
                    DerefOf (PCCX [One]) [One] = 0xD6D8
                }
                Case (0x19)
                {
                    DerefOf (PCCX [One]) [Zero] = 0x3E80
                    DerefOf (PCCX [One]) [One] = 0x7D00
                }
                Case (0x0F)
                {
                    DerefOf (PCCX [One]) [Zero] = 0x36B0
                    DerefOf (PCCX [One]) [One] = 0x7D00
                }
                Case (0x0B)
                {
                    DerefOf (PCCX [One]) [Zero] = 0x36B0
                    DerefOf (PCCX [One]) [One] = 0x61A8
                }
                Default
                {
                    DerefOf (PCCX [One]) [Zero] = 0xFF
                    DerefOf (PCCX [One]) [One] = 0xFF
                }

            }

            Return (PCCX) /* \_SB_.PCI0.B0D4.PCCX */
        }

        Name (PCCX, Package (0x02)
        {
            0x80000000, 
            Package (0x02)
            {
                0x80000000, 
                0x80000000
            }
        })
        Name (KEFF, Package (0x1E)
        {
            Package (0x02)
            {
                0x01BC, 
                Zero
            }, 

            Package (0x02)
            {
                0x01CF, 
                0x27
            }, 

            Package (0x02)
            {
                0x01E1, 
                0x4B
            }, 

            Package (0x02)
            {
                0x01F3, 
                0x6C
            }, 

            Package (0x02)
            {
                0x0206, 
                0x8B
            }, 

            Package (0x02)
            {
                0x0218, 
                0xA8
            }, 

            Package (0x02)
            {
                0x022A, 
                0xC3
            }, 

            Package (0x02)
            {
                0x023D, 
                0xDD
            }, 

            Package (0x02)
            {
                0x024F, 
                0xF4
            }, 

            Package (0x02)
            {
                0x0261, 
                0x010B
            }, 

            Package (0x02)
            {
                0x0274, 
                0x011F
            }, 

            Package (0x02)
            {
                0x032C, 
                0x01BD
            }, 

            Package (0x02)
            {
                0x03D7, 
                0x0227
            }, 

            Package (0x02)
            {
                0x048B, 
                0x026D
            }, 

            Package (0x02)
            {
                0x053E, 
                0x02A1
            }, 

            Package (0x02)
            {
                0x05F7, 
                0x02C6
            }, 

            Package (0x02)
            {
                0x06A8, 
                0x02E6
            }, 

            Package (0x02)
            {
                0x075D, 
                0x02FF
            }, 

            Package (0x02)
            {
                0x0818, 
                0x0311
            }, 

            Package (0x02)
            {
                0x08CF, 
                0x0322
            }, 

            Package (0x02)
            {
                0x179C, 
                0x0381
            }, 

            Package (0x02)
            {
                0x2DDC, 
                0x039C
            }, 

            Package (0x02)
            {
                0x44A8, 
                0x039E
            }, 

            Package (0x02)
            {
                0x5C35, 
                0x0397
            }, 

            Package (0x02)
            {
                0x747D, 
                0x038D
            }, 

            Package (0x02)
            {
                0x8D7F, 
                0x0382
            }, 

            Package (0x02)
            {
                0xA768, 
                0x0376
            }, 

            Package (0x02)
            {
                0xC23B, 
                0x0369
            }, 

            Package (0x02)
            {
                0xDE26, 
                0x035A
            }, 

            Package (0x02)
            {
                0xFB7C, 
                0x034A
            }
        })
        Name (CEUP, Package (0x06)
        {
            0x80000000, 
            0x80000000, 
            0x80000000, 
            0x80000000, 
            0x80000000, 
            0x80000000
        })
        Method (_TMP, 0, Serialized)  // _TMP: Temperature
        {
            Return (\_SB.IETM.CTOK (PCTP))
        }

        Method (_DTI, 1, NotSerialized)  // _DTI: Device Temperature Indication
        {
            LSTM = Arg0
            Notify (\_SB.PCI0.B0D4, 0x91) // Device-Specific
        }

        Method (_NTT, 0, NotSerialized)  // _NTT: Notification Temperature Threshold
        {
            Return (0x0ADE)
        }

        Name (PTYP, Zero)
        Method (_PSS, 0, NotSerialized)  // _PSS: Performance Supported States
        {
            If (CondRefOf (\_SB.PR00._PSS))
            {
                Return (\_SB.PR00._PSS ())
            }
            Else
            {
                Return (Package (0x02)
                {
                    Package (0x06)
                    {
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero
                    }, 

                    Package (0x06)
                    {
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero
                    }
                })
            }
        }

        Method (_TSS, 0, NotSerialized)  // _TSS: Throttling Supported States
        {
            If (CondRefOf (\_SB.PR00._TSS))
            {
                Return (\_SB.PR00._TSS ())
            }
            Else
            {
                Return (Package (0x02)
                {
                    Package (0x05)
                    {
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero
                    }, 

                    Package (0x05)
                    {
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero
                    }
                })
            }
        }

        Method (_TPC, 0, NotSerialized)  // _TPC: Throttling Present Capabilities
        {
            If (CondRefOf (\_SB.PR00._TPC))
            {
                Return (\_SB.PR00._TPC) /* External reference */
            }
            Else
            {
                Return (Zero)
            }
        }

        Method (_PTC, 0, NotSerialized)  // _PTC: Processor Throttling Control
        {
            If ((CondRefOf (\PC00) && (\PC00 != 0x80000000)))
            {
                If ((\PC00 & 0x04))
                {
                    Return (Package (0x02)
                    {
                        ResourceTemplate ()
                        {
                            Register (FFixedHW, 
                                0x00,               // Bit Width
                                0x00,               // Bit Offset
                                0x0000000000000000, // Address
                                ,)
                        }, 

                        ResourceTemplate ()
                        {
                            Register (FFixedHW, 
                                0x00,               // Bit Width
                                0x00,               // Bit Offset
                                0x0000000000000000, // Address
                                ,)
                        }
                    })
                }
                Else
                {
                    Return (Package (0x02)
                    {
                        ResourceTemplate ()
                        {
                            Register (SystemIO, 
                                0x05,               // Bit Width
                                0x00,               // Bit Offset
                                0x0000000000001810, // Address
                                ,)
                        }, 

                        ResourceTemplate ()
                        {
                            Register (SystemIO, 
                                0x05,               // Bit Width
                                0x00,               // Bit Offset
                                0x0000000000001810, // Address
                                ,)
                        }
                    })
                }
            }
            Else
            {
                Return (Package (0x02)
                {
                    ResourceTemplate ()
                    {
                        Register (FFixedHW, 
                            0x00,               // Bit Width
                            0x00,               // Bit Offset
                            0x0000000000000000, // Address
                            ,)
                    }, 

                    ResourceTemplate ()
                    {
                        Register (FFixedHW, 
                            0x00,               // Bit Width
                            0x00,               // Bit Offset
                            0x0000000000000000, // Address
                            ,)
                    }
                })
            }
        }

        Method (_TSD, 0, NotSerialized)  // _TSD: Throttling State Dependencies
        {
            If (CondRefOf (\_SB.PR00._TSD))
            {
                Return (\_SB.PR00._TSD ())
            }
            Else
            {
                Return (Package (0x02)
                {
                    Package (0x05)
                    {
                        0x05, 
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero
                    }, 

                    Package (0x05)
                    {
                        0x05, 
                        Zero, 
                        Zero, 
                        Zero, 
                        Zero
                    }
                })
            }
        }

        Method (_TDL, 0, NotSerialized)  // _TDL: T-State Depth Limit
        {
            If ((CondRefOf (\_SB.PR00._TSS) && CondRefOf (\_SB.CFGD)))
            {
                If ((\_SB.CFGD & 0x2000))
                {
                    Return ((SizeOf (\_SB.PR00.TSMF) - One))
                }
                Else
                {
                    Return ((SizeOf (\_SB.PR00.TSMC) - One))
                }
            }
            Else
            {
                Return (Zero)
            }
        }

        Method (_PDL, 0, NotSerialized)  // _PDL: P-state Depth Limit
        {
            If (CondRefOf (\_SB.PR00._PSS))
            {
                If ((\_SB.OSCP & 0x0400))
                {
                    Return ((SizeOf (\_SB.PR00.TPSS) - One))
                }
                Else
                {
                    Return ((SizeOf (\_SB.PR00.LPSS) - One))
                }
            }
            Else
            {
                Return (Zero)
            }
        }

        Method (_TSP, 0, Serialized)  // _TSP: Thermal Sampling Period
        {
            Return (\CPUS) /* External reference */
        }

        Method (_AC0, 0, Serialized)  // _ACx: Active Cooling, x=0-9
        {
            If ((\ATMC == Zero))
            {
                Return (0xFFFFFFFF)
            }

            Local1 = \_SB.IETM.CTOK (\ATMC)
            If ((LSTM >= Local1))
            {
                Return ((Local1 - 0x14))
            }
            Else
            {
                Return (Local1)
            }
        }

        Method (_AC1, 0, Serialized)  // _ACx: Active Cooling, x=0-9
        {
            If ((\ATMC == Zero))
            {
                Return (0xFFFFFFFF)
            }

            Local0 = \_SB.IETM.CTOK (\ATMC)
            Local0 -= 0x32
            If ((LSTM >= Local0))
            {
                Return ((Local0 - 0x14))
            }
            Else
            {
                Return (Local0)
            }
        }

        Method (_AC2, 0, Serialized)  // _ACx: Active Cooling, x=0-9
        {
            If ((\ATMC == Zero))
            {
                Return (0xFFFFFFFF)
            }

            Local0 = \_SB.IETM.CTOK (\ATMC)
            Local0 -= 0x64
            If ((LSTM >= Local0))
            {
                Return ((Local0 - 0x14))
            }
            Else
            {
                Return (Local0)
            }
        }

        Method (_AC3, 0, Serialized)  // _ACx: Active Cooling, x=0-9
        {
            If ((\ATMC == Zero))
            {
                Return (0xFFFFFFFF)
            }

            Local0 = \_SB.IETM.CTOK (\ATMC)
            Local0 -= 0x96
            If ((LSTM >= Local0))
            {
                Return ((Local0 - 0x14))
            }
            Else
            {
                Return (Local0)
            }
        }

        Method (_AC4, 0, Serialized)  // _ACx: Active Cooling, x=0-9
        {
            If ((\ATMC == Zero))
            {
                Return (0xFFFFFFFF)
            }

            Local0 = \_SB.IETM.CTOK (\ATMC)
            Local0 -= 0xC8
            If ((LSTM >= Local0))
            {
                Return ((Local0 - 0x14))
            }
            Else
            {
                Return (Local0)
            }
        }

        Method (_PSV, 0, Serialized)  // _PSV: Passive Temperature
        {
            If ((\PTMC == Zero))
            {
                Return (0xFFFFFFFF)
            }

            Return (\_SB.IETM.CTOK (\PTMC))
        }

        Method (_CRT, 0, Serialized)  // _CRT: Critical Temperature
        {
            If ((\SACT == Zero))
            {
                Return (0xFFFFFFFF)
            }

            Return (\_SB.IETM.CTOK (\SACT))
        }

        Method (_CR3, 0, Serialized)  // _CR3: Warm/Standby Temperature
        {
            If ((\SAC3 == Zero))
            {
                Return (0xFFFFFFFF)
            }

            Return (\_SB.IETM.CTOK (\SAC3))
        }

        Method (_HOT, 0, Serialized)  // _HOT: Hot Temperature
        {
            If ((\SAHT == Zero))
            {
                Return (0xFFFFFFFF)
            }

            Return (\_SB.IETM.CTOK (\SAHT))
        }

        Method (UVTH, 1, Serialized)
        {
        }
    }

    Scope (\_SB.IETM)
    {
        Name (CTSP, Package (0x01)
        {
            ToUUID ("e145970a-e4c1-4d73-900e-c9c5a69dd067") /* Unknown UUID */
        })
    }

    Scope (\_SB.PCI0.B0D4)
    {
        Method (TDPL, 0, Serialized)
        {
            Name (AAAA, Zero)
            Name (BBBB, Zero)
            Name (CCCC, Zero)
            Local0 = CTNL /* \_SB_.PCI0.B0D4.CTNL */
            If (((Local0 == One) || (Local0 == 0x02)))
            {
                Local0 = \_SB.CLVL /* External reference */
            }
            Else
            {
                Return (Package (0x01)
                {
                    Zero
                })
            }

            If ((CLCK == One))
            {
                Local0 = One
            }

            AAAA = CPNU (\_SB.PL10, One)
            BBBB = CPNU (\_SB.PL11, One)
            CCCC = CPNU (\_SB.PL12, One)
            Name (TMP1, Package (0x01)
            {
                Package (0x05)
                {
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000
                }
            })
            Name (TMP2, Package (0x02)
            {
                Package (0x05)
                {
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000
                }, 

                Package (0x05)
                {
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000
                }
            })
            Name (TMP3, Package (0x03)
            {
                Package (0x05)
                {
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000
                }, 

                Package (0x05)
                {
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000
                }, 

                Package (0x05)
                {
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000, 
                    0x80000000
                }
            })
            If ((Local0 == 0x03))
            {
                If ((AAAA > BBBB))
                {
                    If ((AAAA > CCCC))
                    {
                        If ((BBBB > CCCC))
                        {
                            Local3 = Zero
                            LEV0 = Zero
                            Local4 = One
                            LEV1 = One
                            Local5 = 0x02
                            LEV2 = 0x02
                        }
                        Else
                        {
                            Local3 = Zero
                            LEV0 = Zero
                            Local5 = One
                            LEV1 = 0x02
                            Local4 = 0x02
                            LEV2 = One
                        }
                    }
                    Else
                    {
                        Local5 = Zero
                        LEV0 = 0x02
                        Local3 = One
                        LEV1 = Zero
                        Local4 = 0x02
                        LEV2 = One
                    }
                }
                ElseIf ((BBBB > CCCC))
                {
                    If ((AAAA > CCCC))
                    {
                        Local4 = Zero
                        LEV0 = One
                        Local3 = One
                        LEV1 = Zero
                        Local5 = 0x02
                        LEV2 = 0x02
                    }
                    Else
                    {
                        Local4 = Zero
                        LEV0 = One
                        Local5 = One
                        LEV1 = 0x02
                        Local3 = 0x02
                        LEV2 = Zero
                    }
                }
                Else
                {
                    Local5 = Zero
                    LEV0 = 0x02
                    Local4 = One
                    LEV1 = One
                    Local3 = 0x02
                    LEV2 = Zero
                }

                Local1 = (\_SB.TAR0 + One)
                Local2 = (Local1 * 0x64)
                DerefOf (TMP3 [Local3]) [Zero] = AAAA /* \_SB_.PCI0.B0D4.TDPL.AAAA */
                DerefOf (TMP3 [Local3]) [One] = Local2
                DerefOf (TMP3 [Local3]) [0x02] = \_SB.CTC0 /* External reference */
                DerefOf (TMP3 [Local3]) [0x03] = Local1
                DerefOf (TMP3 [Local3]) [0x04] = Zero
                Local1 = (\_SB.TAR1 + One)
                Local2 = (Local1 * 0x64)
                DerefOf (TMP3 [Local4]) [Zero] = BBBB /* \_SB_.PCI0.B0D4.TDPL.BBBB */
                DerefOf (TMP3 [Local4]) [One] = Local2
                DerefOf (TMP3 [Local4]) [0x02] = \_SB.CTC1 /* External reference */
                DerefOf (TMP3 [Local4]) [0x03] = Local1
                DerefOf (TMP3 [Local4]) [0x04] = Zero
                Local1 = (\_SB.TAR2 + One)
                Local2 = (Local1 * 0x64)
                DerefOf (TMP3 [Local5]) [Zero] = CCCC /* \_SB_.PCI0.B0D4.TDPL.CCCC */
                DerefOf (TMP3 [Local5]) [One] = Local2
                DerefOf (TMP3 [Local5]) [0x02] = \_SB.CTC2 /* External reference */
                DerefOf (TMP3 [Local5]) [0x03] = Local1
                DerefOf (TMP3 [Local5]) [0x04] = Zero
                Return (TMP3) /* \_SB_.PCI0.B0D4.TDPL.TMP3 */
            }

            If ((Local0 == 0x02))
            {
                If ((AAAA > BBBB))
                {
                    Local3 = Zero
                    Local4 = One
                    LEV0 = Zero
                    LEV1 = One
                    LEV2 = Zero
                }
                Else
                {
                    Local4 = Zero
                    Local3 = One
                    LEV0 = One
                    LEV1 = Zero
                    LEV2 = Zero
                }

                Local1 = (\_SB.TAR0 + One)
                Local2 = (Local1 * 0x64)
                DerefOf (TMP2 [Local3]) [Zero] = AAAA /* \_SB_.PCI0.B0D4.TDPL.AAAA */
                DerefOf (TMP2 [Local3]) [One] = Local2
                DerefOf (TMP2 [Local3]) [0x02] = \_SB.CTC0 /* External reference */
                DerefOf (TMP2 [Local3]) [0x03] = Local1
                DerefOf (TMP2 [Local3]) [0x04] = Zero
                Local1 = (\_SB.TAR1 + One)
                Local2 = (Local1 * 0x64)
                DerefOf (TMP2 [Local4]) [Zero] = BBBB /* \_SB_.PCI0.B0D4.TDPL.BBBB */
                DerefOf (TMP2 [Local4]) [One] = Local2
                DerefOf (TMP2 [Local4]) [0x02] = \_SB.CTC1 /* External reference */
                DerefOf (TMP2 [Local4]) [0x03] = Local1
                DerefOf (TMP2 [Local4]) [0x04] = Zero
                Return (TMP2) /* \_SB_.PCI0.B0D4.TDPL.TMP2 */
            }

            If ((Local0 == One))
            {
                Switch (ToInteger (\_SB.CBMI))
                {
                    Case (Zero)
                    {
                        Local1 = (\_SB.TAR0 + One)
                        Local2 = (Local1 * 0x64)
                        DerefOf (TMP1 [Zero]) [Zero] = AAAA /* \_SB_.PCI0.B0D4.TDPL.AAAA */
                        DerefOf (TMP1 [Zero]) [One] = Local2
                        DerefOf (TMP1 [Zero]) [0x02] = \_SB.CTC0 /* External reference */
                        DerefOf (TMP1 [Zero]) [0x03] = Local1
                        DerefOf (TMP1 [Zero]) [0x04] = Zero
                        LEV0 = Zero
                        LEV1 = Zero
                        LEV2 = Zero
                    }
                    Case (One)
                    {
                        Local1 = (\_SB.TAR1 + One)
                        Local2 = (Local1 * 0x64)
                        DerefOf (TMP1 [Zero]) [Zero] = BBBB /* \_SB_.PCI0.B0D4.TDPL.BBBB */
                        DerefOf (TMP1 [Zero]) [One] = Local2
                        DerefOf (TMP1 [Zero]) [0x02] = \_SB.CTC1 /* External reference */
                        DerefOf (TMP1 [Zero]) [0x03] = Local1
                        DerefOf (TMP1 [Zero]) [0x04] = Zero
                        LEV0 = One
                        LEV1 = One
                        LEV2 = One
                    }
                    Case (0x02)
                    {
                        Local1 = (\_SB.TAR2 + One)
                        Local2 = (Local1 * 0x64)
                        DerefOf (TMP1 [Zero]) [Zero] = CCCC /* \_SB_.PCI0.B0D4.TDPL.CCCC */
                        DerefOf (TMP1 [Zero]) [One] = Local2
                        DerefOf (TMP1 [Zero]) [0x02] = \_SB.CTC2 /* External reference */
                        DerefOf (TMP1 [Zero]) [0x03] = Local1
                        DerefOf (TMP1 [Zero]) [0x04] = Zero
                        LEV0 = 0x02
                        LEV1 = 0x02
                        LEV2 = 0x02
                    }

                }

                Return (TMP1) /* \_SB_.PCI0.B0D4.TDPL.TMP1 */
            }

            Return (Zero)
        }

        Name (MAXT, Zero)
        Method (TDPC, 0, NotSerialized)
        {
            Return (MAXT) /* \_SB_.PCI0.B0D4.MAXT */
        }

        Name (LEV0, Zero)
        Name (LEV1, Zero)
        Name (LEV2, Zero)
        Method (STDP, 1, Serialized)
        {
            If ((Arg0 >= \_SB.CLVL))
            {
                Return (Zero)
            }

            Switch (ToInteger (Arg0))
            {
                Case (Zero)
                {
                    Local0 = LEV0 /* \_SB_.PCI0.B0D4.LEV0 */
                }
                Case (One)
                {
                    Local0 = LEV1 /* \_SB_.PCI0.B0D4.LEV1 */
                }
                Case (0x02)
                {
                    Local0 = LEV2 /* \_SB_.PCI0.B0D4.LEV2 */
                }

            }

            Switch (ToInteger (Local0))
            {
                Case (Zero)
                {
                    CPL0 ()
                }
                Case (One)
                {
                    CPL1 ()
                }
                Case (0x02)
                {
                    CPL2 ()
                }

            }

            Notify (\_SB.PCI0.B0D4, 0x83) // Device-Specific Change
        }
    }

    Scope (\_SB.PCI0)
    {
        Device (DPLY)
        {
            Name (_HID, EisaId ("INT3406") /* Intel Dynamic Platform & Thermal Framework Display Participant */)  // _HID: Hardware ID
            Name (_UID, "DPLY")  // _UID: Unique ID
            Name (_STR, Unicode ("Display"))  // _STR: Description String
            Name (PTYP, 0x0A)
            Name (PFLG, Zero)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If ((DISE == One))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Method (DDDL, 0, NotSerialized)
            {
                Return (\DPLL) /* External reference */
            }

            Method (DDPC, 0, NotSerialized)
            {
                Return (\DPHL) /* External reference */
            }

            Method (_BCL, 0, NotSerialized)  // _BCL: Brightness Control Levels
            {
                If (CondRefOf (\_SB.PCI0.GFX0.DD1F._BCL))
                {
                    Return (\_SB.PCI0.GFX0.DD1F._BCL ())
                }
                Else
                {
                    Return (Package (0x01)
                    {
                        Zero
                    })
                }
            }

            Method (_BCM, 1, NotSerialized)  // _BCM: Brightness Control Method
            {
                If (CondRefOf (\_SB.PCI0.GFX0.DD1F._BCM))
                {
                    \_SB.PCI0.GFX0.DD1F._BCM (Arg0)
                }
            }

            Method (_BQC, 0, NotSerialized)  // _BQC: Brightness Query Current
            {
                If (CondRefOf (\_SB.PCI0.GFX0.DD1F._BQC))
                {
                    Return (\_SB.PCI0.GFX0.DD1F._BQC ())
                }
                Else
                {
                    Return (Zero)
                }
            }

            Method (_DCS, 0, NotSerialized)  // _DCS: Display Current Status
            {
                If (CondRefOf (\_SB.PCI0.GFX0.DD1F._DCS))
                {
                    Return (\_SB.PCI0.GFX0.DD1F._DCS ())
                }
                Else
                {
                    Return (Zero)
                }
            }
        }
    }

    Scope (\_SB)
    {
        Device (WWAN)
        {
            Name (_HID, EisaId ("INT3408"))  // _HID: Hardware ID
            Name (_UID, "WWAN")  // _UID: Unique ID
            Name (_STR, Unicode ("WWAN"))  // _STR: Description String
            Name (PTYP, 0x0F)
            Name (CTYP, Zero)
            Name (PFLG, Zero)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If ((WAND == One))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Name (GTSH, 0x14)
            Name (LSTM, Zero)
            Method (_DTI, 1, NotSerialized)  // _DTI: Device Temperature Indication
            {
                LSTM = Arg0
                Notify (\_SB.WWAN, 0x91) // Device-Specific
            }

            Method (_NTT, 0, NotSerialized)  // _NTT: Notification Temperature Threshold
            {
                Return (0x0ADE)
            }

            Method (_AC0, 0, Serialized)  // _ACx: Active Cooling, x=0-9
            {
                If (CTYP)
                {
                    If ((WWPT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Local1 = \_SB.IETM.CTOK (WWPT)
                }
                Else
                {
                    If ((WWAT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Local1 = \_SB.IETM.CTOK (WWAT)
                }

                If ((LSTM > Local1))
                {
                    Return ((Local1 - GTSH))
                }
                Else
                {
                    Return (Local1)
                }
            }

            Method (_PSV, 0, Serialized)  // _PSV: Passive Temperature
            {
                If (CTYP)
                {
                    If ((WWAT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Return (\_SB.IETM.CTOK (WWAT))
                }
                Else
                {
                    If ((WWPT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Return (\_SB.IETM.CTOK (WWPT))
                }
            }

            Method (_CRT, 0, Serialized)  // _CRT: Critical Temperature
            {
                If ((WWCT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (WWCT))
            }

            Method (_CR3, 0, Serialized)  // _CR3: Warm/Standby Temperature
            {
                If ((WWC3 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (WWC3))
            }

            Method (_HOT, 0, Serialized)  // _HOT: Hot Temperature
            {
                If ((WWHT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (WWHT))
            }
        }
    }

    Scope (\_SB)
    {
        Device (WRLS)
        {
            Name (_HID, EisaId ("INT3408"))  // _HID: Hardware ID
            Name (_UID, "WRLS")  // _UID: Unique ID
            Name (_STR, Unicode ("Wireless WiFi, WiGig"))  // _STR: Description String
            Name (PTYP, 0x07)
            Name (CTYP, Zero)
            Name (PFLG, Zero)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If ((\WRFD == One))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Name (GTSH, 0x14)
            Name (LSTM, Zero)
            Method (_DTI, 1, NotSerialized)  // _DTI: Device Temperature Indication
            {
                LSTM = Arg0
                Notify (\_SB.WRLS, 0x91) // Device-Specific
            }

            Method (_NTT, 0, NotSerialized)  // _NTT: Notification Temperature Threshold
            {
                Return (0x0ADE)
            }

            Method (_TSP, 0, Serialized)  // _TSP: Thermal Sampling Period
            {
                Return (\WTSP) /* External reference */
            }

            Method (_AC0, 0, Serialized)  // _ACx: Active Cooling, x=0-9
            {
                If (CTYP)
                {
                    If ((\WRPT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Local1 = \_SB.IETM.CTOK (\WRPT)
                }
                Else
                {
                    If ((\WRAT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Local1 = \_SB.IETM.CTOK (\WRAT)
                }

                If ((LSTM >= Local1))
                {
                    Return ((Local1 - GTSH))
                }
                Else
                {
                    Return (Local1)
                }
            }

            Method (_PSV, 0, Serialized)  // _PSV: Passive Temperature
            {
                If (CTYP)
                {
                    If ((\WRAT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Return (\_SB.IETM.CTOK (\WRAT))
                }
                Else
                {
                    If ((\WRPT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Return (\_SB.IETM.CTOK (\WRPT))
                }
            }

            Method (_CRT, 0, Serialized)  // _CRT: Critical Temperature
            {
                If ((\WRCT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\WRCT))
            }

            Method (_CR3, 0, Serialized)  // _CR3: Warm/Standby Temperature
            {
                If ((\WLC3 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\WLC3))
            }

            Method (_HOT, 0, Serialized)  // _HOT: Hot Temperature
            {
                If ((\WRHT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\WRHT))
            }
        }
    }

    Scope (\_SB)
    {
        Device (CAM1)
        {
            Name (_HID, EisaId ("INT340B"))  // _HID: Hardware ID
            Name (_UID, "CAM1")  // _UID: Unique ID
            Name (_STR, Unicode ("2D Camera"))  // _STR: Description String
            Name (PTYP, 0x1B)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If ((\CA2D == One))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Name (PPSS, Package (0x05)
            {
                Package (0x08)
                {
                    0x64, 
                    Zero, 
                    Zero, 
                    Zero, 
                    0x64, 
                    0x1E, 
                    "FPS", 
                    Zero
                }, 

                Package (0x08)
                {
                    0x50, 
                    Zero, 
                    Zero, 
                    Zero, 
                    0x50, 
                    0x18, 
                    "FPS", 
                    Zero
                }, 

                Package (0x08)
                {
                    0x3C, 
                    Zero, 
                    Zero, 
                    Zero, 
                    0x3C, 
                    0x12, 
                    "FPS", 
                    Zero
                }, 

                Package (0x08)
                {
                    0x28, 
                    Zero, 
                    Zero, 
                    Zero, 
                    0x28, 
                    0x0C, 
                    "FPS", 
                    Zero
                }, 

                Package (0x08)
                {
                    0x14, 
                    Zero, 
                    Zero, 
                    Zero, 
                    0x14, 
                    0x06, 
                    "FPS", 
                    Zero
                }
            })
            Method (PPPC, 0, NotSerialized)
            {
                Return (Zero)
            }

            Method (PPDL, 0, NotSerialized)
            {
                Return (0x04)
            }
        }
    }

    Scope (\_SB)
    {
        Device (STG1)
        {
            Name (_HID, EisaId ("INT340A"))  // _HID: Hardware ID
            Name (_UID, "STG1")  // _UID: Unique ID
            Name (_STR, Unicode ("Storage"))  // _STR: Description String
            Name (PTYP, 0x1D)
            Name (CTYP, Zero)
            Name (PFLG, Zero)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If (\SGE1)
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Method (PPCC, 0, Serialized)
            {
                Return (NPCC) /* \_SB_.STG1.NPCC */
            }

            Name (NPCC, Package (0x02)
            {
                0x02, 
                Package (0x06)
                {
                    Zero, 
                    0x03E8, 
                    0x2710, 
                    Zero, 
                    Zero, 
                    0x03E8
                }
            })
            Name (PATC, Zero)
            Method (_AC0, 0, Serialized)  // _ACx: Active Cooling, x=0-9
            {
                If ((\SAT1 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\SAT1))
            }

            Method (_PSV, 0, Serialized)  // _PSV: Passive Temperature
            {
                If ((\SPT1 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\SPT1))
            }

            Method (_CRT, 0, Serialized)  // _CRT: Critical Temperature
            {
                If ((\SCT1 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\SCT1))
            }

            Method (_CR3, 0, Serialized)  // _CR3: Warm/Standby Temperature
            {
                If ((\SC31 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\SC31))
            }

            Method (_HOT, 0, Serialized)  // _HOT: Hot Temperature
            {
                If ((\SHT1 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\SHT1))
            }

            Method (PORT, 0, Serialized)
            {
                Return (0xFFFFFFFF)
            }
        }
    }

    Scope (\_SB)
    {
        Device (STG2)
        {
            Name (_HID, EisaId ("INT340A"))  // _HID: Hardware ID
            Name (_UID, "STG2")  // _UID: Unique ID
            Name (_STR, Unicode ("Storage"))  // _STR: Description String
            Name (PTYP, 0x1D)
            Name (CTYP, Zero)
            Name (PFLG, Zero)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If (\SGE2)
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Method (PPCC, 0, Serialized)
            {
                Return (NPCC) /* \_SB_.STG2.NPCC */
            }

            Name (NPCC, Package (0x02)
            {
                0x02, 
                Package (0x06)
                {
                    Zero, 
                    0x03E8, 
                    0x2710, 
                    Zero, 
                    Zero, 
                    0x03E8
                }
            })
            Name (PATC, Zero)
            Method (_AC0, 0, Serialized)  // _ACx: Active Cooling, x=0-9
            {
                If ((\SAT2 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\SAT2))
            }

            Method (_PSV, 0, Serialized)  // _PSV: Passive Temperature
            {
                If ((\SPT2 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\SPT2))
            }

            Method (_CRT, 0, Serialized)  // _CRT: Critical Temperature
            {
                If ((\SCT2 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\SCT2))
            }

            Method (_CR3, 0, Serialized)  // _CR3: Warm/Standby Temperature
            {
                If ((\SC32 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\SC32))
            }

            Method (_HOT, 0, Serialized)  // _HOT: Hot Temperature
            {
                If ((\SHT2 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\SHT2))
            }

            Method (PORT, 0, Serialized)
            {
                Return (0xFFFFFFFF)
            }
        }
    }

    Scope (\_SB)
    {
        Device (VIR1)
        {
            Name (_HID, EisaId ("INT3409"))  // _HID: Hardware ID
            Name (_UID, "VIR1")  // _UID: Unique ID
            Name (PTYP, 0x15)
            Name (_STR, Unicode ("Virtual Sensor 1"))  // _STR: Description String
            Name (PFLG, Zero)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If ((VSP1 == One))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Name (PATC, Zero)
            Name (LSTM, Zero)
            Method (_DTI, 1, NotSerialized)  // _DTI: Device Temperature Indication
            {
                LSTM = Arg0
                Notify (\_SB.VIR1, 0x91) // Device-Specific
            }

            Method (_NTT, 0, NotSerialized)  // _NTT: Notification Temperature Threshold
            {
                Return (0x0ADE)
            }

            Name (VSCT, Package (0x02)
            {
                One, 
                Package (0x00){}
            })
            Name (VSPT, Package (0x02)
            {
                One, 
                Package (0x03)
                {
                    Package (0x02)
                    {
                        0x0BD7, 
                        0x012C
                    }, 

                    Package (0x02)
                    {
                        0x0C3B, 
                        0x64
                    }, 

                    Package (0x02)
                    {
                        0x0C9F, 
                        0x0A
                    }
                }
            })
            Method (_AC0, 0, Serialized)  // _ACx: Active Cooling, x=0-9
            {
                If ((\V1AT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Local1 = \_SB.IETM.CTOK (\V1AT)
                If ((LSTM >= Local1))
                {
                    Return ((Local1 - 0x14))
                }
                Else
                {
                    Return (Local1)
                }
            }

            Method (_AC1, 0, Serialized)  // _ACx: Active Cooling, x=0-9
            {
                If ((\V1AT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return ((_AC0 () - 0x1E))
            }

            Method (_AC2, 0, Serialized)  // _ACx: Active Cooling, x=0-9
            {
                If ((\V1AT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return ((_AC1 () - 0x1E))
            }

            Method (_PSV, 0, Serialized)  // _PSV: Passive Temperature
            {
                If ((\V1PV == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\V1PV))
            }

            Method (_CRT, 0, Serialized)  // _CRT: Critical Temperature
            {
                If ((\V1CR == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\V1CR))
            }

            Method (_CR3, 0, Serialized)  // _CR3: Warm/Standby Temperature
            {
                If ((\V1C3 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\V1C3))
            }

            Method (_HOT, 0, Serialized)  // _HOT: Hot Temperature
            {
                If ((\V1HT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\V1HT))
            }
        }
    }

    Scope (\_SB)
    {
        Device (VIR2)
        {
            Name (_HID, EisaId ("INT3409"))  // _HID: Hardware ID
            Name (_UID, "VIR2")  // _UID: Unique ID
            Name (PTYP, 0x15)
            Name (_STR, Unicode ("Virtual Sensor 2"))  // _STR: Description String
            Name (PFLG, Zero)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If ((VSP2 == One))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Name (PATC, Zero)
            Name (LSTM, Zero)
            Method (_DTI, 1, NotSerialized)  // _DTI: Device Temperature Indication
            {
                LSTM = Arg0
                Notify (\_SB.VIR2, 0x91) // Device-Specific
            }

            Method (_NTT, 0, NotSerialized)  // _NTT: Notification Temperature Threshold
            {
                Return (0x0ADE)
            }

            Name (VSCT, Package (0x02)
            {
                One, 
                Package (0x00){}
            })
            Name (VSPT, Package (0x02)
            {
                One, 
                Package (0x03)
                {
                    Package (0x02)
                    {
                        0x0BD7, 
                        0x012C
                    }, 

                    Package (0x02)
                    {
                        0x0C3B, 
                        0x64
                    }, 

                    Package (0x02)
                    {
                        0x0C9F, 
                        0x0A
                    }
                }
            })
            Method (_AC0, 0, Serialized)  // _ACx: Active Cooling, x=0-9
            {
                If ((\V2AT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Local1 = \_SB.IETM.CTOK (\V2AT)
                If ((LSTM >= Local1))
                {
                    Return ((Local1 - 0x14))
                }
                Else
                {
                    Return (Local1)
                }
            }

            Method (_AC1, 0, Serialized)  // _ACx: Active Cooling, x=0-9
            {
                If ((\V1AT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return ((_AC0 () - 0x1E))
            }

            Method (_AC2, 0, Serialized)  // _ACx: Active Cooling, x=0-9
            {
                If ((\V1AT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return ((_AC1 () - 0x1E))
            }

            Method (_PSV, 0, Serialized)  // _PSV: Passive Temperature
            {
                If ((\V2PV == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\V2PV))
            }

            Method (_CRT, 0, Serialized)  // _CRT: Critical Temperature
            {
                If ((\V2CR == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\V2CR))
            }

            Method (_CR3, 0, Serialized)  // _CR3: Warm/Standby Temperature
            {
                If ((\V2C3 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\V2C3))
            }

            Method (_HOT, 0, Serialized)  // _HOT: Hot Temperature
            {
                If ((\V2HT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\V2HT))
            }
        }
    }

    Scope (\_SB)
    {
        Device (PCHP)
        {
            Name (_HID, EisaId ("INT3405"))  // _HID: Hardware ID
            Name (_UID, "PCHP")  // _UID: Unique ID
            Name (_STR, Unicode ("Intel PCH FIVR Participant"))  // _STR: Description String
            Name (PTYP, 0x05)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If ((\PCHE == One))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Method (RFC0, 1, Serialized)
            {
                IPCS (0xA3, One, 0x08, Zero, Arg0, Zero, Zero)
            }

            Method (RFC1, 1, Serialized)
            {
                IPCS (0xA3, One, 0x08, One, Arg0, Zero, Zero)
            }

            Method (SEMI, 1, Serialized)
            {
                IPCS (0xA3, One, 0x08, 0x02, Arg0, Zero, Zero)
            }
        }
    }

    Scope (\_SB)
    {
        Device (BAT1)
        {
            Name (_HID, EisaId ("INT3532"))  // _HID: Hardware ID
            Name (_UID, "1")  // _UID: Unique ID
            Name (_STR, Unicode ("Battery 1 Participant"))  // _STR: Description String
            Name (PTYP, 0x0C)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If ((\BATR == One))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Method (PMAX, 0, Serialized)
            {
                Return (Zero)
            }

            Method (CTYP, 0, NotSerialized)
            {
                Return (0x03)
            }

            Method (PBSS, 0, NotSerialized)
            {
                Return (0x64)
            }

            Method (DPSP, 0, Serialized)
            {
                Return (\PPPR) /* External reference */
            }

            Method (RBHF, 0, NotSerialized)
            {
                Return (0xFFFFFFFF)
            }

            Method (VBNL, 0, NotSerialized)
            {
                Return (0xFFFFFFFF)
            }

            Method (CMPP, 0, NotSerialized)
            {
                Return (0xFFFFFFFF)
            }
        }
    }

    Scope (\_SB.PCI0.LPCB.EC0)
    {
        Device (SEN1)
        {
            Name (_HID, EisaId ("INT3403") /* DPTF Temperature Sensor */)  // _HID: Hardware ID
            Name (_UID, "SEN1")  // _UID: Unique ID
            Name (_STR, Unicode ("Sensor 1 GPU choke"))  // _STR: Description String
            Name (PTYP, 0x03)
            Name (CTYP, Zero)
            Name (PFLG, Zero)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If ((\S1DE == One))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Method (_TMP, 0, Serialized)  // _TMP: Temperature
            {
                If (\_SB.PCI0.LPCB.ECOK ())
                {
                    Return (\_SB.IETM.CTOK (\_SB.PCI0.LPCB.EC0.EST1))
                }

                Return (0x0BB8)
            }

            Name (GTSH, 0x14)
            Name (LSTM, Zero)
            Method (_DTI, 1, NotSerialized)  // _DTI: Device Temperature Indication
            {
                LSTM = Arg0
                Notify (\_SB.PCI0.LPCB.EC0.SEN1, 0x91) // Device-Specific
            }

            Method (_NTT, 0, NotSerialized)  // _NTT: Notification Temperature Threshold
            {
                Return (0x0ADE)
            }

            Method (_TSP, 0, Serialized)  // _TSP: Thermal Sampling Period
            {
                Return (0x32)
            }

            Method (_PSV, 0, Serialized)  // _PSV: Passive Temperature
            {
                If (CTYP)
                {
                    If ((\S1AT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Return (\_SB.IETM.CTOK (\S1AT))
                }
                Else
                {
                    If ((\S1PT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Return (\_SB.IETM.CTOK (\S1PT))
                }
            }

            Method (_CRT, 0, Serialized)  // _CRT: Critical Temperature
            {
                If ((\S1CT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\S1CT))
            }

            Method (_CR3, 0, Serialized)  // _CR3: Warm/Standby Temperature
            {
                If ((\S1S3 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\S1S3))
            }

            Method (_HOT, 0, Serialized)  // _HOT: Hot Temperature
            {
                If ((\S1HT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\S1HT))
            }
        }
    }

    Scope (\_SB.PCI0.LPCB.EC0)
    {
        Device (SEN2)
        {
            Name (_HID, EisaId ("INT3403") /* DPTF Temperature Sensor */)  // _HID: Hardware ID
            Name (_UID, "SEN2")  // _UID: Unique ID
            Name (_STR, Unicode ("Sensor 2 CPU choke"))  // _STR: Description String
            Name (PTYP, 0x03)
            Name (CTYP, Zero)
            Name (PFLG, Zero)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If ((\S2DE == One))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Method (_TMP, 0, Serialized)  // _TMP: Temperature
            {
                If (\_SB.PCI0.LPCB.ECOK ())
                {
                    Return (\_SB.IETM.CTOK (\_SB.PCI0.LPCB.EC0.EST2))
                }

                Return (0x0BB8)
            }

            Name (GTSH, 0x14)
            Name (LSTM, Zero)
            Method (_DTI, 1, NotSerialized)  // _DTI: Device Temperature Indication
            {
                LSTM = Arg0
                Notify (\_SB.PCI0.LPCB.EC0.SEN2, 0x91) // Device-Specific
            }

            Method (_NTT, 0, NotSerialized)  // _NTT: Notification Temperature Threshold
            {
                Return (0x0ADE)
            }

            Method (_TSP, 0, Serialized)  // _TSP: Thermal Sampling Period
            {
                Return (0x0A)
            }

            Method (_PSV, 0, Serialized)  // _PSV: Passive Temperature
            {
                If (CTYP)
                {
                    If ((\S2AT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Return (\_SB.IETM.CTOK (\S2AT))
                }
                Else
                {
                    If ((\S2PT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Return (\_SB.IETM.CTOK (\S2PT))
                }
            }

            Method (_CRT, 0, Serialized)  // _CRT: Critical Temperature
            {
                If ((\S2CT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\S2CT))
            }

            Method (_CR3, 0, Serialized)  // _CR3: Warm/Standby Temperature
            {
                If ((\S2S3 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\S2S3))
            }

            Method (_HOT, 0, Serialized)  // _HOT: Hot Temperature
            {
                If ((\S2HT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\S2HT))
            }
        }
    }

    Scope (\_SB.PCI0.LPCB.EC0)
    {
        Device (SEN3)
        {
            Name (_HID, EisaId ("INT3403") /* DPTF Temperature Sensor */)  // _HID: Hardware ID
            Name (_UID, "SEN3")  // _UID: Unique ID
            Name (_STR, Unicode ("Thermistor Ambient"))  // _STR: Description String
            Name (PTYP, 0x03)
            Name (CTYP, Zero)
            Name (PFLG, Zero)
            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                If ((\S3DE == One))
                {
                    Return (0x0F)
                }
                Else
                {
                    Return (Zero)
                }
            }

            Method (_TMP, 0, Serialized)  // _TMP: Temperature
            {
                If (\_SB.PCI0.LPCB.ECOK ())
                {
                    Return (\_SB.IETM.CTOK (\_SB.PCI0.LPCB.EC0.EST3))
                }

                Return (0x0BB8)
            }

            Name (GTSH, 0x14)
            Name (LSTM, Zero)
            Method (_DTI, 1, NotSerialized)  // _DTI: Device Temperature Indication
            {
                LSTM = Arg0
                Notify (\_SB.PCI0.LPCB.EC0.SEN3, 0x91) // Device-Specific
            }

            Method (_NTT, 0, NotSerialized)  // _NTT: Notification Temperature Threshold
            {
                Return (0x0ADE)
            }

            Method (_TSP, 0, Serialized)  // _TSP: Thermal Sampling Period
            {
                Return (0x32)
            }

            Method (_PSV, 0, Serialized)  // _PSV: Passive Temperature
            {
                If (CTYP)
                {
                    If ((\S3AT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Return (\_SB.IETM.CTOK (\S3AT))
                }
                Else
                {
                    If ((\S3PT == Zero))
                    {
                        Return (0xFFFFFFFF)
                    }

                    Return (\_SB.IETM.CTOK (\S3PT))
                }
            }

            Method (_CRT, 0, Serialized)  // _CRT: Critical Temperature
            {
                If ((\S3CT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\S3CT))
            }

            Method (_CR3, 0, Serialized)  // _CR3: Warm/Standby Temperature
            {
                If ((\S3S3 == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\S3S3))
            }

            Method (_HOT, 0, Serialized)  // _HOT: Hot Temperature
            {
                If ((\S3HT == Zero))
                {
                    Return (0xFFFFFFFF)
                }

                Return (\_SB.IETM.CTOK (\S3HT))
            }
        }
    }

    Scope (\_SB.IETM)
    {
        Name (PTTL, 0x14)
        Name (PSVP, Package (0x05)
        {
            0x02, 
            Package (0x0C)
            {
                \_SB.PCI0.B0D4, 
                \_SB.PCI0.LPCB.EC0.SEN1, 
                One, 
                0x1E, 
                0x0C28, 
                0x09, 
                0x00010000, 
                "Max", 
                0x01F4, 
                0x0A, 
                0x0A, 
                Zero
            }, 

            Package (0x0C)
            {
                \_SB.PCI0.B0D4, 
                \_SB.PCI0.LPCB.EC0.SEN2, 
                One, 
                0x0F, 
                0x0D2C, 
                0x09, 
                0x00010000, 
                "Max", 
                0x01F4, 
                0x0A, 
                0x0A, 
                Zero
            }, 

            Package (0x0C)
            {
                \_SB.PCI0.B0D4, 
                \_SB.PCI0.LPCB.EC0.SEN3, 
                One, 
                0x32, 
                0x0C46, 
                0x09, 
                0x00010000, 
                "Max", 
                0x01F4, 
                0x0A, 
                0x0A, 
                Zero
            }, 

            Package (0x0C)
            {
                \_SB.PCI0.B0D4, 
                \_SB.PCI0.B0D4, 
                One, 
                0x0A, 
                0x0D04, 
                0x09, 
                0x00010000, 
                "Max", 
                0x03E8, 
                0x0A, 
                0x0A, 
                Zero
            }
        })
        Method (PSVT, 0, NotSerialized)
        {
            Return (PSVP) /* \_SB_.IETM.PSVP */
        }
    }

    Scope (\_SB.IETM)
    {
        Name (DP2P, Package (0x01)
        {
            ToUUID ("9e04115a-ae87-4d1c-9500-0f3e340bfe75") /* Unknown UUID */
        })
        Name (DPSP, Package (0x01)
        {
            ToUUID ("42a441d6-ae6a-462b-a84b-4a8ce79027d3") /* Unknown UUID */
        })
        Name (DASP, Package (0x01)
        {
            ToUUID ("3a95c389-e4b8-4629-a526-c52c88626bae") /* Unknown UUID */
        })
        Name (DA2P, Package (0x01)
        {
            ToUUID ("0e56fab6-bdfc-4e8c-8246-40ecfd4d74ea") /* Unknown UUID */
        })
        Name (DCSP, Package (0x01)
        {
            ToUUID ("97c68ae7-15fa-499c-b8c9-5da81d606e0a") /* Unknown UUID */
        })
        Name (RFIP, Package (0x01)
        {
            ToUUID ("c4ce1849-243a-49f3-b8d5-f97002f38e6a") /* Unknown UUID */
        })
        Name (POBP, Package (0x01)
        {
            ToUUID ("f5a35014-c209-46a4-993a-eb56de7530a1") /* Unknown UUID */
        })
        Name (DAPP, Package (0x01)
        {
            ToUUID ("63be270f-1c11-48fd-a6f7-3af253ff3e2d") /* Unknown UUID */
        })
        Name (DVSP, Package (0x01)
        {
            ToUUID ("6ed722a7-9240-48a5-b479-31eef723d7cf") /* Unknown UUID */
        })
        Name (DPID, Package (0x01)
        {
            ToUUID ("42496e14-bc1b-46e8-a798-ca915464426f") /* Unknown UUID */
        })
    }

    Scope (\_SB.IETM)
    {
        Method (TEVT, 2, Serialized)
        {
            Switch (ToString (Arg0, Ones))
            {
                Case ("IETM")
                {
                    Notify (\_SB.IETM, Arg1)
                }
                Case ("B0D4")
                {
                    Notify (\_SB.PCI0.B0D4, Arg1)
                }
                Case ("CAM1")
                {
                    Notify (\_SB.CAM1, Arg1)
                }
                Case ("CHRG")
                {
                }
                Case ("DPLY")
                {
                    Notify (\_SB.PCI0.DPLY, Arg1)
                }
                Case ("PCHP")
                {
                    Notify (\_SB.PCHP, Arg1)
                }
                Case ("SEN2")
                {
                }
                Case ("SEN3")
                {
                }
                Case ("SEN4")
                {
                }
                Case ("SEN5")
                {
                }
                Case ("STG1")
                {
                    Notify (\_SB.STG1, Arg1)
                }
                Case ("STG2")
                {
                    Notify (\_SB.STG2, Arg1)
                }
                Case ("TFN1")
                {
                }
                Case ("TPWR")
                {
                }
                Case ("VIR1")
                {
                    Notify (\_SB.VIR1, Arg1)
                }
                Case ("VIR2")
                {
                    Notify (\_SB.VIR2, Arg1)
                }
                Case ("WRLS")
                {
                    Notify (\_SB.WRLS, Arg1)
                }
                Case ("WWAN")
                {
                    Notify (\_SB.WWAN, Arg1)
                }

            }
        }
    }

    Scope (\_SB.IETM)
    {
        Name (L5C5, Package (0x01)
        {
            Buffer (0x051B)
            {
                /* 0000 */  0xE5, 0x1F, 0x94, 0x00, 0x00, 0x00, 0x00, 0x02,  // ........
                /* 0008 */  0x00, 0x00, 0x00, 0x40, 0x67, 0x64, 0x64, 0x76,  // ...@gddv
                /* 0010 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0018 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0020 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0028 */  0x00, 0x00, 0x00, 0x00, 0x4F, 0x45, 0x4D, 0x20,  // ....OEM 
                /* 0030 */  0x45, 0x78, 0x70, 0x6F, 0x72, 0x74, 0x65, 0x64,  // Exported
                /* 0038 */  0x20, 0x44, 0x61, 0x74, 0x61, 0x56, 0x61, 0x75,  //  DataVau
                /* 0040 */  0x6C, 0x74, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // lt......
                /* 0048 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0050 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0058 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0060 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0068 */  0x00, 0x00, 0x00, 0x00, 0x55, 0x8C, 0xE0, 0x7C,  // ....U..|
                /* 0070 */  0x3C, 0x59, 0xD2, 0x5C, 0x5D, 0x2B, 0xBA, 0x98,  // <Y.\]+..
                /* 0078 */  0x47, 0x8C, 0xAA, 0x08, 0xC2, 0x12, 0xB0, 0x34,  // G......4
                /* 0080 */  0x06, 0xC8, 0xB7, 0x12, 0x50, 0xC9, 0xF1, 0xCD,  // ....P...
                /* 0088 */  0xB2, 0xB7, 0x62, 0x0D, 0x87, 0x04, 0x00, 0x00,  // ..b.....
                /* 0090 */  0x52, 0x45, 0x50, 0x4F, 0x5D, 0x00, 0x00, 0x00,  // REPO]...
                /* 0098 */  0x01, 0x7A, 0x5E, 0x00, 0x00, 0x00, 0x00, 0x00,  // .z^.....
                /* 00A0 */  0x00, 0x00, 0x72, 0x87, 0xCD, 0xFF, 0x6D, 0x24,  // ..r...m$
                /* 00A8 */  0x47, 0xDB, 0x3D, 0x24, 0x92, 0xB4, 0x16, 0x6F,  // G.=$...o
                /* 00B0 */  0x45, 0xD8, 0xC3, 0xF5, 0x66, 0x14, 0x9F, 0x22,  // E...f.."
                /* 00B8 */  0xD7, 0xF7, 0xDE, 0x67, 0x90, 0x9A, 0xA2, 0x0D,  // ...g....
                /* 00C0 */  0x39, 0x25, 0xAD, 0xC3, 0x1A, 0xAD, 0x52, 0x0B,  // 9%....R.
                /* 00C8 */  0x75, 0x38, 0xE1, 0xA4, 0x14, 0x44, 0x7C, 0x4B,  // u8...D|K
                /* 00D0 */  0x00, 0x7B, 0x58, 0x92, 0xA1, 0x2C, 0x24, 0x25,  // .{X..,$%
                /* 00D8 */  0xF0, 0xF0, 0xC7, 0xAA, 0x83, 0xDD, 0x8F, 0x04,  // ........
                /* 00E0 */  0xE7, 0x04, 0xBD, 0xED, 0x55, 0x92, 0xD9, 0xA2,  // ....U...
                /* 00E8 */  0xA5, 0xA9, 0x28, 0xB7, 0x11, 0xBB, 0xF9, 0x21,  // ..(....!
                /* 00F0 */  0x1D, 0xA4, 0x9B, 0x4B, 0xE7, 0xC3, 0x5D, 0xEF,  // ...K..].
                /* 00F8 */  0x91, 0x96, 0x16, 0x4A, 0x35, 0x0D, 0xC0, 0xC5,  // ...J5...
                /* 0100 */  0xD5, 0xEE, 0x3B, 0x61, 0xBA, 0x1A, 0x6F, 0x88,  // ..;a..o.
                /* 0108 */  0x0B, 0xCB, 0x7D, 0x5E, 0x37, 0x52, 0x3E, 0x37,  // ..}^7R>7
                /* 0110 */  0x97, 0x38, 0xBE, 0x38, 0xD5, 0xE4, 0x51, 0x48,  // .8.8..QH
                /* 0118 */  0xB6, 0xF4, 0x7E, 0x6E, 0xAA, 0x1A, 0x06, 0x86,  // ..~n....
                /* 0120 */  0xEC, 0x8C, 0xEC, 0x7F, 0xD8, 0x28, 0x43, 0x35,  // .....(C5
                /* 0128 */  0x8C, 0x2A, 0xB2, 0x11, 0x2D, 0x66, 0xF2, 0x59,  // .*..-f.Y
                /* 0130 */  0x1A, 0xA4, 0x42, 0x5F, 0xF3, 0xF0, 0x48, 0x17,  // ..B_..H.
                /* 0138 */  0x2A, 0x3F, 0x19, 0x70, 0x2E, 0x79, 0x5D, 0xF8,  // *?.p.y].
                /* 0140 */  0xA2, 0x47, 0xBA, 0x34, 0x2C, 0xB2, 0x39, 0xA1,  // .G.4,.9.
                /* 0148 */  0x8D, 0xD6, 0xA6, 0x75, 0xDD, 0x7C, 0xA7, 0x89,  // ...u.|..
                /* 0150 */  0xF7, 0xD2, 0x14, 0x05, 0xCA, 0x1F, 0x99, 0x9A,  // ........
                /* 0158 */  0x04, 0x7B, 0x27, 0x9D, 0x4D, 0x6C, 0xEB, 0x2E,  // .{'.Ml..
                /* 0160 */  0x97, 0x00, 0x3C, 0xB2, 0x02, 0xBF, 0x39, 0x84,  // ..<...9.
                /* 0168 */  0xB6, 0xFF, 0x11, 0x06, 0x00, 0x60, 0x17, 0x58,  // .....`.X
                /* 0170 */  0x4E, 0x73, 0xF3, 0xDE, 0x49, 0xD4, 0x24, 0xD2,  // Ns..I.$.
                /* 0178 */  0xFC, 0x29, 0xB3, 0xB6, 0x39, 0xB1, 0x63, 0x29,  // .)..9.c)
                /* 0180 */  0xAB, 0xDB, 0x25, 0x50, 0x21, 0x9B, 0xCD, 0x94,  // ..%P!...
                /* 0188 */  0x6E, 0xE6, 0xD4, 0xEF, 0xD6, 0xF8, 0xDC, 0x74,  // n......t
                /* 0190 */  0x57, 0x02, 0x58, 0x71, 0xBA, 0xB6, 0x09, 0xB8,  // W.Xq....
                /* 0198 */  0x5F, 0x8A, 0xB3, 0x8E, 0xBB, 0x9F, 0x7C, 0x24,  // _.....|$
                /* 01A0 */  0x51, 0x95, 0x62, 0x90, 0x5B, 0x5C, 0x57, 0xAC,  // Q.b.[\W.
                /* 01A8 */  0xFA, 0xA9, 0x37, 0xAA, 0xCD, 0x4E, 0x07, 0x6F,  // ..7..N.o
                /* 01B0 */  0x89, 0xD8, 0x44, 0x83, 0x49, 0xC3, 0xDC, 0xE5,  // ..D.I...
                /* 01B8 */  0xE8, 0xE6, 0x7D, 0x41, 0x83, 0x2B, 0x0D, 0x50,  // ..}A.+.P
                /* 01C0 */  0xCA, 0xD2, 0x50, 0x4C, 0x5B, 0x4A, 0x4D, 0x4B,  // ..PL[JMK
                /* 01C8 */  0xA0, 0x36, 0x51, 0x96, 0x36, 0x30, 0x45, 0x8D,  // .6Q.60E.
                /* 01D0 */  0x43, 0x9B, 0xBF, 0x3F, 0x00, 0x97, 0x06, 0x5C,  // C..?...\
                /* 01D8 */  0x1A, 0x26, 0x01, 0x1C, 0x0E, 0x7A, 0x08, 0x8E,  // .&...z..
                /* 01E0 */  0xC1, 0xD3, 0x80, 0x7D, 0xAF, 0x35, 0x7C, 0x96,  // ...}.5|.
                /* 01E8 */  0xCA, 0x16, 0x94, 0xF8, 0x42, 0xDC, 0xDA, 0xF7,  // ....B...
                /* 01F0 */  0xA5, 0xA1, 0xC8, 0xF3, 0xC0, 0xC3, 0xD5, 0x40,  // .......@
                /* 01F8 */  0xBE, 0xA7, 0x75, 0x09, 0x2B, 0x83, 0xAE, 0xF3,  // ..u.+...
                /* 0200 */  0x46, 0xCD, 0xFF, 0x96, 0x7E, 0xB3, 0x90, 0x77,  // F...~..w
                /* 0208 */  0x9E, 0xAC, 0x9E, 0x8A, 0xE9, 0x04, 0x74, 0x60,  // ......t`
                /* 0210 */  0xC9, 0x9C, 0x56, 0xC4, 0xE0, 0x1E, 0xBB, 0x60,  // ..V....`
                /* 0218 */  0x2A, 0xCA, 0x42, 0xF2, 0x57, 0x02, 0x6E, 0xB1,  // *.B.W.n.
                /* 0220 */  0xB3, 0x89, 0xF3, 0x82, 0x43, 0xF6, 0x79, 0x62,  // ....C.yb
                /* 0228 */  0x58, 0x74, 0x8E, 0xD6, 0x2A, 0x7D, 0x16, 0x81,  // Xt..*}..
                /* 0230 */  0x91, 0x73, 0xD1, 0xE0, 0x9D, 0x8C, 0xCB, 0xD3,  // .s......
                /* 0238 */  0x4C, 0x4C, 0x05, 0x4A, 0x40, 0x26, 0x84, 0x9E,  // LL.J@&..
                /* 0240 */  0x53, 0xF1, 0x08, 0x79, 0xBF, 0xB3, 0x91, 0xDB,  // S..y....
                /* 0248 */  0x49, 0x9B, 0x1C, 0xB8, 0x2D, 0x9A, 0x6D, 0xC9,  // I...-.m.
                /* 0250 */  0x2E, 0xC4, 0x00, 0x2C, 0xE6, 0xB4, 0x4B, 0x81,  // ...,..K.
                /* 0258 */  0xEF, 0x2E, 0x32, 0xFB, 0x8A, 0x57, 0x1A, 0x8B,  // ..2..W..
                /* 0260 */  0x91, 0x07, 0xE9, 0xAC, 0x20, 0x7B, 0xD8, 0x4D,  // .... {.M
                /* 0268 */  0x9B, 0x14, 0x5D, 0xA0, 0x24, 0x99, 0x7A, 0xC1,  // ..].$.z.
                /* 0270 */  0xBC, 0xE0, 0x85, 0xEB, 0xFC, 0xBD, 0x0D, 0x2D,  // .......-
                /* 0278 */  0x2E, 0xFC, 0xCA, 0x44, 0x08, 0x51, 0xA5, 0x7D,  // ...D.Q.}
                /* 0280 */  0xBB, 0xF9, 0x7F, 0x46, 0x96, 0x61, 0x7E, 0x57,  // ...F.a~W
                /* 0288 */  0x73, 0x8C, 0x8E, 0x9B, 0x8F, 0x62, 0xF7, 0xF9,  // s....b..
                /* 0290 */  0x59, 0x7A, 0x26, 0x39, 0xDA, 0x1E, 0x77, 0x1D,  // Yz&9..w.
                /* 0298 */  0x5E, 0x9B, 0x23, 0x39, 0x4B, 0xE2, 0x24, 0x4D,  // ^.#9K.$M
                /* 02A0 */  0x73, 0x13, 0x03, 0xE3, 0xFA, 0x65, 0xB2, 0xB5,  // s....e..
                /* 02A8 */  0x93, 0x8E, 0x90, 0x15, 0x09, 0x37, 0x4A, 0x4E,  // .....7JN
                /* 02B0 */  0xFF, 0x6C, 0x86, 0x57, 0x0B, 0x8E, 0x2F, 0x58,  // .l.W../X
                /* 02B8 */  0x01, 0xBF, 0x80, 0x6E, 0xB3, 0x1D, 0xD3, 0x7C,  // ...n...|
                /* 02C0 */  0x33, 0x66, 0xBC, 0x5E, 0x00, 0x24, 0x10, 0xF7,  // 3f.^.$..
                /* 02C8 */  0xCA, 0x39, 0x01, 0x94, 0x59, 0xA8, 0x0C, 0x12,  // .9..Y...
                /* 02D0 */  0xAD, 0xDD, 0x0F, 0x84, 0xCD, 0x45, 0x58, 0x6B,  // .....EXk
                /* 02D8 */  0xB9, 0x83, 0xAC, 0x29, 0x70, 0xE8, 0x9A, 0x6E,  // ...)p..n
                /* 02E0 */  0x26, 0x7C, 0x80, 0xFB, 0x0B, 0xD3, 0x66, 0x98,  // &|....f.
                /* 02E8 */  0x91, 0x74, 0x04, 0xDA, 0xA7, 0xAF, 0x8A, 0xC4,  // .t......
                /* 02F0 */  0xA3, 0xA1, 0x3C, 0x5E, 0x5A, 0x23, 0x42, 0xEE,  // ..<^Z#B.
                /* 02F8 */  0x21, 0xC8, 0x12, 0xEC, 0x4B, 0xDD, 0x7C, 0x6D,  // !...K.|m
                /* 0300 */  0x4B, 0x61, 0x39, 0x11, 0xFC, 0xD1, 0x9E, 0xC5,  // Ka9.....
                /* 0308 */  0x2E, 0x96, 0x06, 0x1B, 0xDD, 0xB3, 0x97, 0x42,  // .......B
                /* 0310 */  0x10, 0x2A, 0xF6, 0x62, 0x69, 0xEA, 0x30, 0xCF,  // .*.bi.0.
                /* 0318 */  0x30, 0xDE, 0xDA, 0x6B, 0x0B, 0xCD, 0xBC, 0x53,  // 0..k...S
                /* 0320 */  0xE3, 0x43, 0x0D, 0xB5, 0x7F, 0x02, 0x49, 0xBB,  // .C....I.
                /* 0328 */  0x96, 0x1B, 0x4D, 0x81, 0x93, 0xD1, 0x59, 0x62,  // ..M...Yb
                /* 0330 */  0xC3, 0xFB, 0xCE, 0x98, 0x2C, 0x1A, 0xEA, 0x34,  // ....,..4
                /* 0338 */  0x53, 0x2C, 0x10, 0xC1, 0x87, 0x58, 0x89, 0xFD,  // S,...X..
                /* 0340 */  0xF5, 0xFD, 0xDE, 0x90, 0x0F, 0x6C, 0x52, 0x99,  // .....lR.
                /* 0348 */  0x59, 0x03, 0xDD, 0xF4, 0xC6, 0x2A, 0x47, 0x77,  // Y....*Gw
                /* 0350 */  0x4B, 0x49, 0x2D, 0xE5, 0xE4, 0x57, 0xCE, 0x1E,  // KI-..W..
                /* 0358 */  0x92, 0xBC, 0xCB, 0x92, 0x81, 0xA0, 0x1C, 0x1E,  // ........
                /* 0360 */  0xF0, 0x90, 0x82, 0xBA, 0x1A, 0x0D, 0xEE, 0x2D,  // .......-
                /* 0368 */  0x21, 0x29, 0x7B, 0xF3, 0x22, 0x25, 0xAF, 0x78,  // !){."%.x
                /* 0370 */  0x83, 0x62, 0x07, 0x4E, 0xB8, 0x2C, 0x7E, 0x8F,  // .b.N.,~.
                /* 0378 */  0xC1, 0x07, 0x09, 0xCD, 0x59, 0x4A, 0x4A, 0x67,  // ....YJJg
                /* 0380 */  0x64, 0xA1, 0xA6, 0x3A, 0x25, 0xA1, 0x0F, 0x42,  // d..:%..B
                /* 0388 */  0x0C, 0x7D, 0xC3, 0x54, 0x83, 0x32, 0xDC, 0x43,  // .}.T.2.C
                /* 0390 */  0x8E, 0xB9, 0x5B, 0x84, 0xC6, 0x04, 0x89, 0xD5,  // ..[.....
                /* 0398 */  0x3F, 0xD9, 0x9B, 0x22, 0x96, 0x95, 0xFA, 0x86,  // ?.."....
                /* 03A0 */  0xF4, 0x40, 0x21, 0xCC, 0x69, 0x6B, 0xD3, 0xAB,  // .@!.ik..
                /* 03A8 */  0x11, 0xB1, 0x2C, 0xC9, 0x0D, 0x14, 0x88, 0x39,  // ..,....9
                /* 03B0 */  0x5D, 0x71, 0x88, 0x57, 0x8D, 0xCC, 0xB2, 0xBB,  // ]q.W....
                /* 03B8 */  0x9F, 0x17, 0xE8, 0x2B, 0xA3, 0xAA, 0xBC, 0xC6,  // ...+....
                /* 03C0 */  0xF5, 0xB4, 0xFD, 0x2D, 0xFA, 0x77, 0xCC, 0x89,  // ...-.w..
                /* 03C8 */  0x89, 0x92, 0xBB, 0x5F, 0x36, 0x92, 0xA2, 0xB0,  // ..._6...
                /* 03D0 */  0xE6, 0xC9, 0x95, 0x4A, 0x07, 0x13, 0x46, 0x53,  // ...J..FS
                /* 03D8 */  0x00, 0x63, 0xCB, 0x89, 0xBB, 0x43, 0x54, 0xE4,  // .c...CT.
                /* 03E0 */  0xA2, 0xF2, 0x90, 0xCF, 0x40, 0xAA, 0x29, 0x14,  // ....@.).
                /* 03E8 */  0x6E, 0xF5, 0x21, 0x59, 0x11, 0x3B, 0xBC, 0x65,  // n.!Y.;.e
                /* 03F0 */  0x1F, 0x12, 0x3D, 0x90, 0x49, 0x4B, 0x93, 0x8C,  // ..=.IK..
                /* 03F8 */  0x65, 0xBA, 0x84, 0xED, 0x38, 0xA2, 0x39, 0x3D,  // e...8.9=
                /* 0400 */  0x41, 0x97, 0x16, 0xA7, 0x1F, 0x89, 0xDB, 0xFE,  // A.......
                /* 0408 */  0xC4, 0xB3, 0x35, 0x7B, 0x52, 0xAB, 0xF0, 0x41,  // ..5{R..A
                /* 0410 */  0xA7, 0xB4, 0xE5, 0xE9, 0x4A, 0x6F, 0x4B, 0xFF,  // ....JoK.
                /* 0418 */  0x3B, 0x09, 0x8B, 0xEE, 0x21, 0xF9, 0xCC, 0xDB,  // ;...!...
                /* 0420 */  0x2D, 0xD7, 0xEA, 0x17, 0xFA, 0xD3, 0x3B, 0x27,  // -.....;'
                /* 0428 */  0xC6, 0x26, 0xB7, 0x8E, 0x1A, 0xB2, 0xC4, 0x03,  // .&......
                /* 0430 */  0xD0, 0x03, 0xD2, 0x8F, 0x91, 0xA6, 0xCC, 0x56,  // .......V
                /* 0438 */  0x8E, 0xC8, 0x04, 0x1D, 0x3F, 0x35, 0x3B, 0x9B,  // ....?5;.
                /* 0440 */  0xFD, 0x31, 0xE4, 0xC5, 0xB9, 0xFB, 0xF3, 0xDE,  // .1......
                /* 0448 */  0x36, 0x4E, 0xA0, 0x6D, 0x25, 0x4B, 0xC6, 0xDF,  // 6N.m%K..
                /* 0450 */  0xB3, 0xD0, 0xC0, 0x8B, 0x43, 0xB2, 0xD1, 0x09,  // ....C...
                /* 0458 */  0x5E, 0x7D, 0x63, 0xA5, 0x6C, 0x26, 0x6E, 0xF9,  // ^}c.l&n.
                /* 0460 */  0x63, 0x3B, 0x44, 0x9D, 0x1E, 0xCB, 0xA2, 0x7C,  // c;D....|
                /* 0468 */  0xE9, 0x6B, 0xC8, 0xDE, 0xE6, 0x07, 0x16, 0x4F,  // .k.....O
                /* 0470 */  0xDC, 0x17, 0x56, 0x54, 0x7C, 0xF7, 0x12, 0x7E,  // ..VT|..~
                /* 0478 */  0xB3, 0xB8, 0xF5, 0x72, 0xAB, 0xF5, 0xED, 0x62,  // ...r...b
                /* 0480 */  0x98, 0xBB, 0x9F, 0xF0, 0xAF, 0xD6, 0x1C, 0xDA,  // ........
                /* 0488 */  0x9E, 0x95, 0x2A, 0x45, 0x94, 0x67, 0xEE, 0xFA,  // ..*E.g..
                /* 0490 */  0x89, 0xAA, 0x1D, 0x0D, 0xFF, 0x3C, 0x23, 0x26,  // .....<#&
                /* 0498 */  0x2E, 0xA9, 0x64, 0xA0, 0x2B, 0x05, 0x36, 0x2A,  // ..d.+.6*
                /* 04A0 */  0x0D, 0x99, 0xD1, 0x21, 0xFE, 0x5F, 0x32, 0x64,  // ...!._2d
                /* 04A8 */  0xB4, 0x50, 0xEA, 0x22, 0x36, 0x9B, 0xDB, 0x83,  // .P."6...
                /* 04B0 */  0xB5, 0x55, 0xAF, 0x0E, 0xD3, 0x88, 0x03, 0x13,  // .U......
                /* 04B8 */  0x75, 0x5C, 0x27, 0x67, 0xAB, 0x9E, 0x76, 0x2E,  // u\'g..v.
                /* 04C0 */  0xBA, 0x13, 0x86, 0x73, 0x60, 0x84, 0xF6, 0x10,  // ...s`...
                /* 04C8 */  0x7D, 0xBD, 0xB9, 0x5C, 0x0C, 0x2C, 0xFE, 0x02,  // }..\.,..
                /* 04D0 */  0x1C, 0x8E, 0xB4, 0x3F, 0xAB, 0xB4, 0x64, 0xA6,  // ...?..d.
                /* 04D8 */  0xAE, 0xE8, 0xE8, 0x7B, 0xA3, 0xF8, 0xF2, 0xAF,  // ...{....
                /* 04E0 */  0x72, 0x7B, 0x92, 0xC9, 0xEE, 0x71, 0xB8, 0xD2,  // r{...q..
                /* 04E8 */  0x9C, 0x3B, 0x91, 0xE1, 0xAA, 0xF1, 0x49, 0xC9,  // .;....I.
                /* 04F0 */  0x80, 0xBD, 0x7C, 0xB9, 0x68, 0x4F, 0x9D, 0x24,  // ..|.hO.$
                /* 04F8 */  0xA8, 0x17, 0xF8, 0xAF, 0x17, 0x11, 0xC0, 0xC6,  // ........
                /* 0500 */  0x86, 0x9C, 0xFB, 0xB6, 0x1A, 0x45, 0x49, 0x28,  // .....EI(
                /* 0508 */  0xEC, 0xE8, 0x08, 0x46, 0xFC, 0x8A, 0x4D, 0xE8,  // ...F..M.
                /* 0510 */  0x51, 0x51, 0xE1, 0xA8, 0xB6, 0xC1, 0x75, 0x0F,  // QQ....u.
                /* 0518 */  0x3E, 0x7E, 0x26                                 // >~&
            }
        })
        Name (L435, Package (0x01)
        {
            Buffer (0x043B)
            {
                /* 0000 */  0xE5, 0x1F, 0x94, 0x00, 0x00, 0x00, 0x00, 0x02,  // ........
                /* 0008 */  0x00, 0x00, 0x00, 0x40, 0x67, 0x64, 0x64, 0x76,  // ...@gddv
                /* 0010 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0018 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0020 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0028 */  0x00, 0x00, 0x00, 0x00, 0x4F, 0x45, 0x4D, 0x20,  // ....OEM 
                /* 0030 */  0x45, 0x78, 0x70, 0x6F, 0x72, 0x74, 0x65, 0x64,  // Exported
                /* 0038 */  0x20, 0x44, 0x61, 0x74, 0x61, 0x56, 0x61, 0x75,  //  DataVau
                /* 0040 */  0x6C, 0x74, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // lt......
                /* 0048 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0050 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0058 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0060 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0068 */  0x00, 0x00, 0x00, 0x00, 0x6E, 0x68, 0x2C, 0xF9,  // ....nh,.
                /* 0070 */  0xB4, 0xEB, 0x79, 0x3C, 0xCF, 0xA2, 0xCA, 0x74,  // ..y<...t
                /* 0078 */  0x3D, 0xDF, 0x46, 0x08, 0x15, 0xC8, 0x9F, 0x6E,  // =.F....n
                /* 0080 */  0xCB, 0x11, 0xE4, 0x7F, 0x95, 0xE3, 0x40, 0x16,  // ......@.
                /* 0088 */  0x99, 0x71, 0x6D, 0xD0, 0xA7, 0x03, 0x00, 0x00,  // .qm.....
                /* 0090 */  0x52, 0x45, 0x50, 0x4F, 0x5D, 0x00, 0x00, 0x00,  // REPO]...
                /* 0098 */  0x01, 0xDC, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00,  // ..@.....
                /* 00A0 */  0x00, 0x00, 0x72, 0x87, 0xCD, 0xFF, 0x6D, 0x24,  // ..r...m$
                /* 00A8 */  0x47, 0xDB, 0x3D, 0x24, 0x92, 0xB4, 0x16, 0x6F,  // G.=$...o
                /* 00B0 */  0x45, 0xD8, 0xC3, 0xF5, 0x66, 0x14, 0x9F, 0x22,  // E...f.."
                /* 00B8 */  0xD7, 0xF7, 0xDE, 0x67, 0x90, 0x9A, 0xA2, 0x0D,  // ...g....
                /* 00C0 */  0x39, 0x25, 0xAD, 0xC3, 0x1A, 0xAD, 0x52, 0x0B,  // 9%....R.
                /* 00C8 */  0x75, 0x38, 0xE1, 0xA4, 0x14, 0x40, 0xED, 0xAE,  // u8...@..
                /* 00D0 */  0x64, 0x44, 0x96, 0xF5, 0x7A, 0x32, 0x35, 0x23,  // dD..z25#
                /* 00D8 */  0x13, 0x13, 0x89, 0xBD, 0x20, 0x18, 0x46, 0x92,  // .... .F.
                /* 00E0 */  0xF7, 0xF5, 0xA9, 0x7E, 0x7C, 0xBF, 0x37, 0xB2,  // ...~|.7.
                /* 00E8 */  0xFC, 0x9F, 0x2D, 0x5F, 0xF1, 0x9E, 0x6C, 0x1B,  // ..-_..l.
                /* 00F0 */  0x66, 0x40, 0xD8, 0x58, 0xCA, 0xDE, 0xAB, 0xCD,  // f@.X....
                /* 00F8 */  0x4D, 0xFA, 0xC6, 0x4F, 0xC5, 0xD9, 0xC3, 0x7F,  // M..O....
                /* 0100 */  0x81, 0xBD, 0xC7, 0x3E, 0x7A, 0x16, 0x90, 0xC2,  // ...>z...
                /* 0108 */  0xDB, 0x96, 0xAE, 0x88, 0xF2, 0xC3, 0x2D, 0xC6,  // ......-.
                /* 0110 */  0x69, 0x4F, 0x53, 0xC6, 0x09, 0x1B, 0x36, 0x21,  // iOS...6!
                /* 0118 */  0x60, 0xFD, 0xF3, 0x8A, 0x27, 0x55, 0xD7, 0xB3,  // `...'U..
                /* 0120 */  0xE9, 0x22, 0x9E, 0xF9, 0xA1, 0xEA, 0xB0, 0x3E,  // .".....>
                /* 0128 */  0x53, 0x6A, 0x74, 0xEB, 0x5E, 0x0C, 0x7C, 0xFC,  // Sjt.^.|.
                /* 0130 */  0x36, 0x29, 0x94, 0x14, 0x95, 0x9B, 0x7B, 0xEA,  // 6)....{.
                /* 0138 */  0x30, 0xBC, 0x14, 0x8F, 0xB7, 0x21, 0xC2, 0x9A,  // 0....!..
                /* 0140 */  0x48, 0x3B, 0x6F, 0x81, 0x0A, 0x52, 0x4E, 0x2F,  // H;o..RN/
                /* 0148 */  0x1B, 0x0C, 0xD4, 0x97, 0x3E, 0xEC, 0xDE, 0x14,  // ....>...
                /* 0150 */  0x34, 0x30, 0x3B, 0x34, 0xAB, 0x36, 0xB0, 0xE5,  // 40;4.6..
                /* 0158 */  0xB5, 0xD0, 0x0A, 0x5C, 0x0D, 0x8E, 0x95, 0x09,  // ...\....
                /* 0160 */  0xB7, 0xD8, 0x00, 0xE1, 0x49, 0xB7, 0x36, 0xD4,  // ....I.6.
                /* 0168 */  0xD8, 0x2D, 0xDF, 0x4A, 0x53, 0x5E, 0xEF, 0x0C,  // .-.JS^..
                /* 0170 */  0xCF, 0xC9, 0xED, 0x17, 0x7D, 0xE8, 0x70, 0x7F,  // ....}.p.
                /* 0178 */  0x54, 0x44, 0x75, 0xBD, 0xCB, 0x6D, 0x14, 0xB4,  // TDu..m..
                /* 0180 */  0xCC, 0xA6, 0x5F, 0x72, 0x86, 0x70, 0x86, 0x6C,  // .._r.p.l
                /* 0188 */  0x86, 0x8E, 0x79, 0x98, 0x23, 0x29, 0xA8, 0x1E,  // ..y.#)..
                /* 0190 */  0x91, 0xEC, 0x11, 0x1F, 0xE3, 0x6A, 0xF5, 0xA6,  // .....j..
                /* 0198 */  0x87, 0x35, 0xAE, 0x4F, 0xD5, 0x37, 0x34, 0x8C,  // .5.O.74.
                /* 01A0 */  0x31, 0x0D, 0x74, 0xBA, 0x08, 0x44, 0xE3, 0x4C,  // 1.t..D.L
                /* 01A8 */  0x63, 0xB7, 0x39, 0xFC, 0x44, 0x6F, 0x98, 0x94,  // c.9.Do..
                /* 01B0 */  0xFD, 0x17, 0x8E, 0x22, 0x20, 0x38, 0x9C, 0xC6,  // ..." 8..
                /* 01B8 */  0x22, 0x88, 0x4A, 0x63, 0x21, 0x5A, 0x43, 0x3C,  // ".Jc!ZC<
                /* 01C0 */  0xA0, 0x78, 0x86, 0x43, 0x37, 0xC5, 0x88, 0xF8,  // .x.C7...
                /* 01C8 */  0x43, 0x87, 0x87, 0x36, 0xAB, 0xC7, 0x16, 0x71,  // C..6...q
                /* 01D0 */  0x2F, 0x05, 0xCF, 0xC1, 0x98, 0xA7, 0x25, 0x87,  // /.....%.
                /* 01D8 */  0x2E, 0x4C, 0xCC, 0x6B, 0x7A, 0x1F, 0x08, 0xDE,  // .L.kz...
                /* 01E0 */  0xFA, 0x13, 0x1A, 0xA8, 0xD3, 0x83, 0x40, 0x9D,  // ......@.
                /* 01E8 */  0x79, 0xBB, 0x34, 0x03, 0xBE, 0x97, 0x9C, 0xEC,  // y.4.....
                /* 01F0 */  0xB0, 0x45, 0x04, 0xE8, 0x7D, 0x9B, 0x82, 0xD4,  // .E..}...
                /* 01F8 */  0xF7, 0x39, 0x46, 0x61, 0x11, 0x04, 0x80, 0xC6,  // .9Fa....
                /* 0200 */  0xAB, 0xB7, 0x67, 0x1D, 0xC2, 0x23, 0x04, 0x20,  // ..g..#. 
                /* 0208 */  0xA6, 0xE8, 0x74, 0x8D, 0x17, 0x89, 0x78, 0xB1,  // ..t...x.
                /* 0210 */  0xE4, 0x78, 0x1B, 0x32, 0x33, 0xD4, 0x72, 0xD8,  // .x.23.r.
                /* 0218 */  0x5E, 0xCC, 0x47, 0x71, 0x41, 0xE7, 0x17, 0x2B,  // ^.GqA..+
                /* 0220 */  0x14, 0xCA, 0x37, 0xE2, 0x03, 0xD0, 0xAE, 0xE5,  // ..7.....
                /* 0228 */  0x35, 0x46, 0xED, 0x66, 0x8D, 0x81, 0x10, 0x92,  // 5F.f....
                /* 0230 */  0x17, 0x7C, 0x91, 0x08, 0x1A, 0xE3, 0x35, 0xF5,  // .|....5.
                /* 0238 */  0x8E, 0xDF, 0x66, 0x0E, 0x54, 0x1D, 0x73, 0x15,  // ..f.T.s.
                /* 0240 */  0x34, 0x19, 0xB1, 0xA6, 0xAA, 0x5E, 0xDE, 0x39,  // 4....^.9
                /* 0248 */  0x5A, 0xC4, 0x24, 0x21, 0xA1, 0x16, 0x2F, 0x36,  // Z.$!../6
                /* 0250 */  0xE3, 0x28, 0xE1, 0x18, 0xAC, 0xEF, 0xD9, 0x03,  // .(......
                /* 0258 */  0x2B, 0xA3, 0xE4, 0x76, 0xC8, 0x88, 0x24, 0x55,  // +..v..$U
                /* 0260 */  0xB9, 0xCF, 0x19, 0xAD, 0xD2, 0xB3, 0xEF, 0x4C,  // .......L
                /* 0268 */  0xAC, 0xD3, 0xE4, 0xFE, 0x28, 0xED, 0x36, 0x9A,  // ....(.6.
                /* 0270 */  0x6C, 0xAD, 0xE3, 0x95, 0x20, 0x50, 0x95, 0x28,  // l... P.(
                /* 0278 */  0xE0, 0x83, 0xCF, 0x0E, 0xFB, 0xB7, 0x00, 0xE9,  // ........
                /* 0280 */  0x0C, 0x9B, 0x79, 0x7B, 0xEA, 0x5B, 0xEA, 0x9C,  // ..y{.[..
                /* 0288 */  0x61, 0x29, 0xC8, 0x3E, 0xFC, 0x82, 0x59, 0xEF,  // a).>..Y.
                /* 0290 */  0xE2, 0x9D, 0xB4, 0x21, 0xAA, 0x82, 0x8D, 0x0C,  // ...!....
                /* 0298 */  0x09, 0xC9, 0x15, 0xE8, 0xBC, 0x60, 0x5C, 0x87,  // .....`\.
                /* 02A0 */  0xD0, 0x48, 0x1C, 0x91, 0xF0, 0x67, 0x8A, 0xFA,  // .H...g..
                /* 02A8 */  0xB7, 0x72, 0x57, 0x19, 0xBD, 0xF3, 0x93, 0x95,  // .rW.....
                /* 02B0 */  0x12, 0x97, 0x1D, 0xB6, 0x3E, 0x02, 0xBB, 0xAC,  // ....>...
                /* 02B8 */  0x5D, 0xAE, 0x60, 0x91, 0xCB, 0xC4, 0xDE, 0xD8,  // ].`.....
                /* 02C0 */  0x5F, 0xC0, 0xEA, 0xAA, 0xE2, 0xB5, 0xE8, 0x5E,  // _......^
                /* 02C8 */  0xD6, 0xAA, 0x47, 0x8E, 0xE7, 0x4D, 0xC6, 0x1A,  // ..G..M..
                /* 02D0 */  0xB8, 0xAB, 0x18, 0xCA, 0x32, 0x52, 0xE7, 0x3E,  // ....2R.>
                /* 02D8 */  0x2E, 0x0D, 0xB6, 0x09, 0xEA, 0x80, 0x05, 0x5F,  // ......._
                /* 02E0 */  0x92, 0x0A, 0x29, 0x5E, 0xAC, 0x1B, 0x48, 0xC4,  // ..)^..H.
                /* 02E8 */  0xF8, 0xAC, 0xD4, 0x24, 0x3F, 0x31, 0x34, 0xF1,  // ...$?14.
                /* 02F0 */  0x2E, 0x23, 0x9B, 0xE4, 0x5F, 0x31, 0x00, 0xA1,  // .#.._1..
                /* 02F8 */  0x23, 0x5C, 0x79, 0xD5, 0x98, 0xAF, 0xCD, 0xF7,  // #\y.....
                /* 0300 */  0x8A, 0xD7, 0xEA, 0x86, 0x0B, 0x4F, 0xAE, 0x0E,  // .....O..
                /* 0308 */  0x25, 0xC3, 0x66, 0xD4, 0x1D, 0x70, 0xC0, 0xA5,  // %.f..p..
                /* 0310 */  0xDD, 0x04, 0x23, 0x95, 0xC2, 0x3C, 0xD5, 0x4F,  // ..#..<.O
                /* 0318 */  0xD2, 0xAB, 0xC5, 0x0C, 0x4F, 0x10, 0xED, 0x67,  // ....O..g
                /* 0320 */  0xE9, 0xC2, 0x25, 0x58, 0x6D, 0x4A, 0xF7, 0xFF,  // ..%XmJ..
                /* 0328 */  0x70, 0x74, 0x87, 0xD2, 0x64, 0x06, 0x6D, 0x13,  // pt..d.m.
                /* 0330 */  0xA6, 0xF7, 0xC4, 0xE1, 0xA3, 0xC6, 0x96, 0x28,  // .......(
                /* 0338 */  0xB9, 0x9E, 0x63, 0xBF, 0x75, 0xF7, 0x51, 0x4D,  // ..c.u.QM
                /* 0340 */  0xDA, 0x12, 0x33, 0xFE, 0x94, 0xB9, 0x7F, 0xB1,  // ..3.....
                /* 0348 */  0x8F, 0xB5, 0xD2, 0xDF, 0xA3, 0x98, 0x7E, 0xD1,  // ......~.
                /* 0350 */  0xE7, 0x1D, 0x9E, 0xF2, 0x88, 0xE1, 0x01, 0x43,  // .......C
                /* 0358 */  0x40, 0x34, 0x47, 0xD0, 0x75, 0x25, 0xFC, 0x59,  // @4G.u%.Y
                /* 0360 */  0x75, 0xD2, 0x86, 0xA0, 0xC2, 0x5C, 0x25, 0xA5,  // u....\%.
                /* 0368 */  0xDA, 0x93, 0x77, 0xA1, 0xAB, 0xFE, 0xCE, 0x95,  // ..w.....
                /* 0370 */  0xF8, 0x44, 0xD2, 0xF1, 0xB0, 0x4E, 0x58, 0x73,  // .D...NXs
                /* 0378 */  0x2A, 0x4F, 0xCE, 0x89, 0x5D, 0x51, 0xFB, 0xAB,  // *O..]Q..
                /* 0380 */  0xDC, 0xFD, 0x8C, 0xB4, 0xB0, 0x22, 0xD0, 0x80,  // ....."..
                /* 0388 */  0x46, 0xC4, 0x8C, 0x20, 0xA1, 0x4C, 0x66, 0x73,  // F.. .Lfs
                /* 0390 */  0x8D, 0x7C, 0x1F, 0x94, 0xF3, 0xFA, 0x2C, 0x7E,  // .|....,~
                /* 0398 */  0x6C, 0x24, 0xD2, 0x02, 0x4B, 0x20, 0x71, 0xA0,  // l$..K q.
                /* 03A0 */  0xB7, 0x33, 0x78, 0x8F, 0xEA, 0x70, 0x4A, 0xF8,  // .3x..pJ.
                /* 03A8 */  0x02, 0x29, 0x96, 0x8F, 0xAA, 0xB8, 0x7A, 0x41,  // .)....zA
                /* 03B0 */  0xCD, 0x27, 0xDB, 0x1F, 0xBB, 0x60, 0xFF, 0xA4,  // .'...`..
                /* 03B8 */  0xCC, 0x8D, 0x1B, 0xD5, 0x35, 0x1C, 0xB1, 0x30,  // ....5..0
                /* 03C0 */  0x18, 0x0A, 0x4F, 0x52, 0xA8, 0x13, 0xC9, 0x70,  // ..OR...p
                /* 03C8 */  0xCC, 0xB2, 0xA0, 0x0A, 0xEE, 0x93, 0xF1, 0xAC,  // ........
                /* 03D0 */  0xB5, 0x43, 0xBD, 0xC1, 0x96, 0x8E, 0xD3, 0xA8,  // .C......
                /* 03D8 */  0x79, 0x93, 0x01, 0xB7, 0x8E, 0x40, 0x58, 0x7A,  // y....@Xz
                /* 03E0 */  0xCC, 0x48, 0x27, 0x03, 0x65, 0x51, 0xB4, 0x70,  // .H'.eQ.p
                /* 03E8 */  0xCB, 0x1C, 0x50, 0xEA, 0x68, 0xBE, 0xC5, 0xFC,  // ..P.h...
                /* 03F0 */  0x37, 0x91, 0x16, 0x1F, 0x27, 0x78, 0xBC, 0x73,  // 7...'x.s
                /* 03F8 */  0x1F, 0xF8, 0x23, 0x4B, 0xAD, 0x56, 0xFA, 0x95,  // ..#K.V..
                /* 0400 */  0x54, 0x57, 0x99, 0x19, 0xA6, 0xF7, 0x4F, 0x80,  // TW....O.
                /* 0408 */  0x81, 0xB9, 0x79, 0x60, 0xA9, 0xF1, 0xB3, 0xAC,  // ..y`....
                /* 0410 */  0xF2, 0xF6, 0x95, 0xF7, 0x30, 0xB5, 0x29, 0xC2,  // ....0.).
                /* 0418 */  0x93, 0x90, 0x17, 0x8F, 0xB9, 0x30, 0xFD, 0xD4,  // .....0..
                /* 0420 */  0xEB, 0xF2, 0xE8, 0x02, 0x4B, 0x21, 0x7B, 0xCC,  // ....K!{.
                /* 0428 */  0xDF, 0x02, 0x5C, 0xB4, 0x8E, 0xAD, 0x1B, 0x1E,  // ..\.....
                /* 0430 */  0x93, 0x88, 0xC8, 0x9F, 0x54, 0x7A, 0x80, 0x5A,  // ....Tz.Z
                /* 0438 */  0x3A, 0x32, 0x32                                 // :22
            }
        })
        Name (L535, Package (0x01)
        {
            Buffer (0x043B)
            {
                /* 0000 */  0xE5, 0x1F, 0x94, 0x00, 0x00, 0x00, 0x00, 0x02,  // ........
                /* 0008 */  0x00, 0x00, 0x00, 0x40, 0x67, 0x64, 0x64, 0x76,  // ...@gddv
                /* 0010 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0018 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0020 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0028 */  0x00, 0x00, 0x00, 0x00, 0x4F, 0x45, 0x4D, 0x20,  // ....OEM 
                /* 0030 */  0x45, 0x78, 0x70, 0x6F, 0x72, 0x74, 0x65, 0x64,  // Exported
                /* 0038 */  0x20, 0x44, 0x61, 0x74, 0x61, 0x56, 0x61, 0x75,  //  DataVau
                /* 0040 */  0x6C, 0x74, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // lt......
                /* 0048 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0050 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0058 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0060 */  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // ........
                /* 0068 */  0x00, 0x00, 0x00, 0x00, 0x6E, 0x68, 0x2C, 0xF9,  // ....nh,.
                /* 0070 */  0xB4, 0xEB, 0x79, 0x3C, 0xCF, 0xA2, 0xCA, 0x74,  // ..y<...t
                /* 0078 */  0x3D, 0xDF, 0x46, 0x08, 0x15, 0xC8, 0x9F, 0x6E,  // =.F....n
                /* 0080 */  0xCB, 0x11, 0xE4, 0x7F, 0x95, 0xE3, 0x40, 0x16,  // ......@.
                /* 0088 */  0x99, 0x71, 0x6D, 0xD0, 0xA7, 0x03, 0x00, 0x00,  // .qm.....
                /* 0090 */  0x52, 0x45, 0x50, 0x4F, 0x5D, 0x00, 0x00, 0x00,  // REPO]...
                /* 0098 */  0x01, 0xDC, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00,  // ..@.....
                /* 00A0 */  0x00, 0x00, 0x72, 0x87, 0xCD, 0xFF, 0x6D, 0x24,  // ..r...m$
                /* 00A8 */  0x47, 0xDB, 0x3D, 0x24, 0x92, 0xB4, 0x16, 0x6F,  // G.=$...o
                /* 00B0 */  0x45, 0xD8, 0xC3, 0xF5, 0x66, 0x14, 0x9F, 0x22,  // E...f.."
                /* 00B8 */  0xD7, 0xF7, 0xDE, 0x67, 0x90, 0x9A, 0xA2, 0x0D,  // ...g....
                /* 00C0 */  0x39, 0x25, 0xAD, 0xC3, 0x1A, 0xAD, 0x52, 0x0B,  // 9%....R.
                /* 00C8 */  0x75, 0x38, 0xE1, 0xA4, 0x14, 0x40, 0xED, 0xAE,  // u8...@..
                /* 00D0 */  0x64, 0x44, 0x96, 0xF5, 0x7A, 0x32, 0x35, 0x23,  // dD..z25#
                /* 00D8 */  0x13, 0x13, 0x89, 0xBD, 0x20, 0x18, 0x46, 0x92,  // .... .F.
                /* 00E0 */  0xF7, 0xF5, 0xA9, 0x7E, 0x7C, 0xBF, 0x37, 0xB2,  // ...~|.7.
                /* 00E8 */  0xFC, 0x9F, 0x2D, 0x5F, 0xF1, 0x9E, 0x6C, 0x1B,  // ..-_..l.
                /* 00F0 */  0x66, 0x40, 0xD8, 0x58, 0xCA, 0xDE, 0xAB, 0xCD,  // f@.X....
                /* 00F8 */  0x4D, 0xFA, 0xC6, 0x4F, 0xC5, 0xD9, 0xC3, 0x7F,  // M..O....
                /* 0100 */  0x81, 0xBD, 0xC7, 0x3E, 0x7A, 0x16, 0x90, 0xC2,  // ...>z...
                /* 0108 */  0xDB, 0x96, 0xAE, 0x88, 0xF2, 0xC3, 0x2D, 0xC6,  // ......-.
                /* 0110 */  0x69, 0x4F, 0x53, 0xC6, 0x09, 0x1B, 0x36, 0x21,  // iOS...6!
                /* 0118 */  0x60, 0xFD, 0xF3, 0x8A, 0x27, 0x55, 0xD7, 0xB3,  // `...'U..
                /* 0120 */  0xE9, 0x22, 0x9E, 0xF9, 0xA1, 0xEA, 0xB0, 0x3E,  // .".....>
                /* 0128 */  0x53, 0x6A, 0x74, 0xEB, 0x5E, 0x0C, 0x7C, 0xFC,  // Sjt.^.|.
                /* 0130 */  0x36, 0x29, 0x94, 0x14, 0x95, 0x9B, 0x7B, 0xEA,  // 6)....{.
                /* 0138 */  0x30, 0xBC, 0x14, 0x8F, 0xB7, 0x21, 0xC2, 0x9A,  // 0....!..
                /* 0140 */  0x48, 0x3B, 0x6F, 0x81, 0x0A, 0x52, 0x4E, 0x2F,  // H;o..RN/
                /* 0148 */  0x1B, 0x0C, 0xD4, 0x97, 0x3E, 0xEC, 0xDE, 0x14,  // ....>...
                /* 0150 */  0x34, 0x30, 0x3B, 0x34, 0xAB, 0x36, 0xB0, 0xE5,  // 40;4.6..
                /* 0158 */  0xB5, 0xD0, 0x0A, 0x5C, 0x0D, 0x8E, 0x95, 0x09,  // ...\....
                /* 0160 */  0xB7, 0xD8, 0x00, 0xE1, 0x49, 0xB7, 0x36, 0xD4,  // ....I.6.
                /* 0168 */  0xD8, 0x2D, 0xDF, 0x4A, 0x53, 0x5E, 0xEF, 0x0C,  // .-.JS^..
                /* 0170 */  0xCF, 0xC9, 0xED, 0x17, 0x7D, 0xE8, 0x70, 0x7F,  // ....}.p.
                /* 0178 */  0x54, 0x44, 0x75, 0xBD, 0xCB, 0x6D, 0x14, 0xB4,  // TDu..m..
                /* 0180 */  0xCC, 0xA6, 0x5F, 0x72, 0x86, 0x70, 0x86, 0x6C,  // .._r.p.l
                /* 0188 */  0x86, 0x8E, 0x79, 0x98, 0x23, 0x29, 0xA8, 0x1E,  // ..y.#)..
                /* 0190 */  0x91, 0xEC, 0x11, 0x1F, 0xE3, 0x6A, 0xF5, 0xA6,  // .....j..
                /* 0198 */  0x87, 0x35, 0xAE, 0x4F, 0xD5, 0x37, 0x34, 0x8C,  // .5.O.74.
                /* 01A0 */  0x31, 0x0D, 0x74, 0xBA, 0x08, 0x44, 0xE3, 0x4C,  // 1.t..D.L
                /* 01A8 */  0x63, 0xB7, 0x39, 0xFC, 0x44, 0x6F, 0x98, 0x94,  // c.9.Do..
                /* 01B0 */  0xFD, 0x17, 0x8E, 0x22, 0x20, 0x38, 0x9C, 0xC6,  // ..." 8..
                /* 01B8 */  0x22, 0x88, 0x4A, 0x63, 0x21, 0x5A, 0x43, 0x3C,  // ".Jc!ZC<
                /* 01C0 */  0xA0, 0x78, 0x86, 0x43, 0x37, 0xC5, 0x88, 0xF8,  // .x.C7...
                /* 01C8 */  0x43, 0x87, 0x87, 0x36, 0xAB, 0xC7, 0x16, 0x71,  // C..6...q
                /* 01D0 */  0x2F, 0x05, 0xCF, 0xC1, 0x98, 0xA7, 0x25, 0x87,  // /.....%.
                /* 01D8 */  0x2E, 0x4C, 0xCC, 0x6B, 0x7A, 0x1F, 0x08, 0xDE,  // .L.kz...
                /* 01E0 */  0xFA, 0x13, 0x1A, 0xA8, 0xD3, 0x83, 0x40, 0x9D,  // ......@.
                /* 01E8 */  0x79, 0xBB, 0x34, 0x03, 0xBE, 0x97, 0x9C, 0xEC,  // y.4.....
                /* 01F0 */  0xB0, 0x45, 0x04, 0xE8, 0x7D, 0x9B, 0x82, 0xD4,  // .E..}...
                /* 01F8 */  0xF7, 0x39, 0x46, 0x61, 0x11, 0x04, 0x80, 0xC6,  // .9Fa....
                /* 0200 */  0xAB, 0xB7, 0x67, 0x1D, 0xC2, 0x23, 0x04, 0x20,  // ..g..#. 
                /* 0208 */  0xA6, 0xE8, 0x74, 0x8D, 0x17, 0x89, 0x78, 0xB1,  // ..t...x.
                /* 0210 */  0xE4, 0x78, 0x1B, 0x32, 0x33, 0xD4, 0x72, 0xD8,  // .x.23.r.
                /* 0218 */  0x5E, 0xCC, 0x47, 0x71, 0x41, 0xE7, 0x17, 0x2B,  // ^.GqA..+
                /* 0220 */  0x14, 0xCA, 0x37, 0xE2, 0x03, 0xD0, 0xAE, 0xE5,  // ..7.....
                /* 0228 */  0x35, 0x46, 0xED, 0x66, 0x8D, 0x81, 0x10, 0x92,  // 5F.f....
                /* 0230 */  0x17, 0x7C, 0x91, 0x08, 0x1A, 0xE3, 0x35, 0xF5,  // .|....5.
                /* 0238 */  0x8E, 0xDF, 0x66, 0x0E, 0x54, 0x1D, 0x73, 0x15,  // ..f.T.s.
                /* 0240 */  0x34, 0x19, 0xB1, 0xA6, 0xAA, 0x5E, 0xDE, 0x39,  // 4....^.9
                /* 0248 */  0x5A, 0xC4, 0x24, 0x21, 0xA1, 0x16, 0x2F, 0x36,  // Z.$!../6
                /* 0250 */  0xE3, 0x28, 0xE1, 0x18, 0xAC, 0xEF, 0xD9, 0x03,  // .(......
                /* 0258 */  0x2B, 0xA3, 0xE4, 0x76, 0xC8, 0x88, 0x24, 0x55,  // +..v..$U
                /* 0260 */  0xB9, 0xCF, 0x19, 0xAD, 0xD2, 0xB3, 0xEF, 0x4C,  // .......L
                /* 0268 */  0xAC, 0xD3, 0xE4, 0xFE, 0x28, 0xED, 0x36, 0x9A,  // ....(.6.
                /* 0270 */  0x6C, 0xAD, 0xE3, 0x95, 0x20, 0x50, 0x95, 0x28,  // l... P.(
                /* 0278 */  0xE0, 0x83, 0xCF, 0x0E, 0xFB, 0xB7, 0x00, 0xE9,  // ........
                /* 0280 */  0x0C, 0x9B, 0x79, 0x7B, 0xEA, 0x5B, 0xEA, 0x9C,  // ..y{.[..
                /* 0288 */  0x61, 0x29, 0xC8, 0x3E, 0xFC, 0x82, 0x59, 0xEF,  // a).>..Y.
                /* 0290 */  0xE2, 0x9D, 0xB4, 0x21, 0xAA, 0x82, 0x8D, 0x0C,  // ...!....
                /* 0298 */  0x09, 0xC9, 0x15, 0xE8, 0xBC, 0x60, 0x5C, 0x87,  // .....`\.
                /* 02A0 */  0xD0, 0x48, 0x1C, 0x91, 0xF0, 0x67, 0x8A, 0xFA,  // .H...g..
                /* 02A8 */  0xB7, 0x72, 0x57, 0x19, 0xBD, 0xF3, 0x93, 0x95,  // .rW.....
                /* 02B0 */  0x12, 0x97, 0x1D, 0xB6, 0x3E, 0x02, 0xBB, 0xAC,  // ....>...
                /* 02B8 */  0x5D, 0xAE, 0x60, 0x91, 0xCB, 0xC4, 0xDE, 0xD8,  // ].`.....
                /* 02C0 */  0x5F, 0xC0, 0xEA, 0xAA, 0xE2, 0xB5, 0xE8, 0x5E,  // _......^
                /* 02C8 */  0xD6, 0xAA, 0x47, 0x8E, 0xE7, 0x4D, 0xC6, 0x1A,  // ..G..M..
                /* 02D0 */  0xB8, 0xAB, 0x18, 0xCA, 0x32, 0x52, 0xE7, 0x3E,  // ....2R.>
                /* 02D8 */  0x2E, 0x0D, 0xB6, 0x09, 0xEA, 0x80, 0x05, 0x5F,  // ......._
                /* 02E0 */  0x92, 0x0A, 0x29, 0x5E, 0xAC, 0x1B, 0x48, 0xC4,  // ..)^..H.
                /* 02E8 */  0xF8, 0xAC, 0xD4, 0x24, 0x3F, 0x31, 0x34, 0xF1,  // ...$?14.
                /* 02F0 */  0x2E, 0x23, 0x9B, 0xE4, 0x5F, 0x31, 0x00, 0xA1,  // .#.._1..
                /* 02F8 */  0x23, 0x5C, 0x79, 0xD5, 0x98, 0xAF, 0xCD, 0xF7,  // #\y.....
                /* 0300 */  0x8A, 0xD7, 0xEA, 0x86, 0x0B, 0x4F, 0xAE, 0x0E,  // .....O..
                /* 0308 */  0x25, 0xC3, 0x66, 0xD4, 0x1D, 0x70, 0xC0, 0xA5,  // %.f..p..
                /* 0310 */  0xDD, 0x04, 0x23, 0x95, 0xC2, 0x3C, 0xD5, 0x4F,  // ..#..<.O
                /* 0318 */  0xD2, 0xAB, 0xC5, 0x0C, 0x4F, 0x10, 0xED, 0x67,  // ....O..g
                /* 0320 */  0xE9, 0xC2, 0x25, 0x58, 0x6D, 0x4A, 0xF7, 0xFF,  // ..%XmJ..
                /* 0328 */  0x70, 0x74, 0x87, 0xD2, 0x64, 0x06, 0x6D, 0x13,  // pt..d.m.
                /* 0330 */  0xA6, 0xF7, 0xC4, 0xE1, 0xA3, 0xC6, 0x96, 0x28,  // .......(
                /* 0338 */  0xB9, 0x9E, 0x63, 0xBF, 0x75, 0xF7, 0x51, 0x4D,  // ..c.u.QM
                /* 0340 */  0xDA, 0x12, 0x33, 0xFE, 0x94, 0xB9, 0x7F, 0xB1,  // ..3.....
                /* 0348 */  0x8F, 0xB5, 0xD2, 0xDF, 0xA3, 0x98, 0x7E, 0xD1,  // ......~.
                /* 0350 */  0xE7, 0x1D, 0x9E, 0xF2, 0x88, 0xE1, 0x01, 0x43,  // .......C
                /* 0358 */  0x40, 0x34, 0x47, 0xD0, 0x75, 0x25, 0xFC, 0x59,  // @4G.u%.Y
                /* 0360 */  0x75, 0xD2, 0x86, 0xA0, 0xC2, 0x5C, 0x25, 0xA5,  // u....\%.
                /* 0368 */  0xDA, 0x93, 0x77, 0xA1, 0xAB, 0xFE, 0xCE, 0x95,  // ..w.....
                /* 0370 */  0xF8, 0x44, 0xD2, 0xF1, 0xB0, 0x4E, 0x58, 0x73,  // .D...NXs
                /* 0378 */  0x2A, 0x4F, 0xCE, 0x89, 0x5D, 0x51, 0xFB, 0xAB,  // *O..]Q..
                /* 0380 */  0xDC, 0xFD, 0x8C, 0xB4, 0xB0, 0x22, 0xD0, 0x80,  // ....."..
                /* 0388 */  0x46, 0xC4, 0x8C, 0x20, 0xA1, 0x4C, 0x66, 0x73,  // F.. .Lfs
                /* 0390 */  0x8D, 0x7C, 0x1F, 0x94, 0xF3, 0xFA, 0x2C, 0x7E,  // .|....,~
                /* 0398 */  0x6C, 0x24, 0xD2, 0x02, 0x4B, 0x20, 0x71, 0xA0,  // l$..K q.
                /* 03A0 */  0xB7, 0x33, 0x78, 0x8F, 0xEA, 0x70, 0x4A, 0xF8,  // .3x..pJ.
                /* 03A8 */  0x02, 0x29, 0x96, 0x8F, 0xAA, 0xB8, 0x7A, 0x41,  // .)....zA
                /* 03B0 */  0xCD, 0x27, 0xDB, 0x1F, 0xBB, 0x60, 0xFF, 0xA4,  // .'...`..
                /* 03B8 */  0xCC, 0x8D, 0x1B, 0xD5, 0x35, 0x1C, 0xB1, 0x30,  // ....5..0
                /* 03C0 */  0x18, 0x0A, 0x4F, 0x52, 0xA8, 0x13, 0xC9, 0x70,  // ..OR...p
                /* 03C8 */  0xCC, 0xB2, 0xA0, 0x0A, 0xEE, 0x93, 0xF1, 0xAC,  // ........
                /* 03D0 */  0xB5, 0x43, 0xBD, 0xC1, 0x96, 0x8E, 0xD3, 0xA8,  // .C......
                /* 03D8 */  0x79, 0x93, 0x01, 0xB7, 0x8E, 0x40, 0x58, 0x7A,  // y....@Xz
                /* 03E0 */  0xCC, 0x48, 0x27, 0x03, 0x65, 0x51, 0xB4, 0x70,  // .H'.eQ.p
                /* 03E8 */  0xCB, 0x1C, 0x50, 0xEA, 0x68, 0xBE, 0xC5, 0xFC,  // ..P.h...
                /* 03F0 */  0x37, 0x91, 0x16, 0x1F, 0x27, 0x78, 0xBC, 0x73,  // 7...'x.s
                /* 03F8 */  0x1F, 0xF8, 0x23, 0x4B, 0xAD, 0x56, 0xFA, 0x95,  // ..#K.V..
                /* 0400 */  0x54, 0x57, 0x99, 0x19, 0xA6, 0xF7, 0x4F, 0x80,  // TW....O.
                /* 0408 */  0x81, 0xB9, 0x79, 0x60, 0xA9, 0xF1, 0xB3, 0xAC,  // ..y`....
                /* 0410 */  0xF2, 0xF6, 0x95, 0xF7, 0x30, 0xB5, 0x29, 0xC2,  // ....0.).
                /* 0418 */  0x93, 0x90, 0x17, 0x8F, 0xB9, 0x30, 0xFD, 0xD4,  // .....0..
                /* 0420 */  0xEB, 0xF2, 0xE8, 0x02, 0x4B, 0x21, 0x7B, 0xCC,  // ....K!{.
                /* 0428 */  0xDF, 0x02, 0x5C, 0xB4, 0x8E, 0xAD, 0x1B, 0x1E,  // ..\.....
                /* 0430 */  0x93, 0x88, 0xC8, 0x9F, 0x54, 0x7A, 0x80, 0x5A,  // ....Tz.Z
                /* 0438 */  0x3A, 0x32, 0x32                                 // :22
            }
        })
        Method (GDDV, 0, Serialized)
        {
            If ((SORC == Zero))
            {
                Return (L5C5) /* \_SB_.IETM.L5C5 */
            }

            If ((SORC == One))
            {
                Return (L535) /* \_SB_.IETM.L535 */
            }

            If ((SORC == 0x02))
            {
                Return (L435) /* \_SB_.IETM.L435 */
            }
        }

        Method (IMOK, 1, NotSerialized)
        {
            Return (Arg0)
        }
    }
}

