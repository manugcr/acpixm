/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20230628 (64-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembly of /home/eclypsium/Desktop/output/fpdt.dat, Tue Jul 29 10:45:16 2025
 *
 * ACPI Data Table [FPDT]
 *
 * Format: [HexOffset DecimalOffset ByteLength]  FieldName : FieldValue (in hex)
 */

[000h 0000 004h]                   Signature : "FPDT"    [Firmware Performance Data Table]
[004h 0004 004h]                Table Length : 00000044
[008h 0008 001h]                    Revision : 01
[009h 0009 001h]                    Checksum : 7B
[00Ah 0010 006h]                      Oem ID : "INSYDE"
[010h 0016 008h]                Oem Table ID : "EDK2INTL"
[018h 0024 004h]                Oem Revision : 00000002
[01Ch 0028 004h]             Asl Compiler ID : "    "
[020h 0032 004h]       Asl Compiler Revision : 01000013


[024h 0036 002h]               Subtable Type : 0000
[026h 0038 001h]                      Length : 10
[027h 0039 001h]                    Revision : 01
[028h 0040 004h]                    Reserved : 00000000
[02Ch 0044 008h]    FPDT Boot Record Address : 000000002ADEF000

[034h 0052 002h]               Subtable Type : 0001
[036h 0054 001h]                      Length : 10
[037h 0055 001h]                    Revision : 01
[038h 0056 004h]                    Reserved : 00000000
[03Ch 0060 008h]         S3PT Record Address : 000000002B4DE000

Raw Table Data: Length 68 (0x44)

    0000: 46 50 44 54 44 00 00 00 01 7B 49 4E 53 59 44 45  // FPDTD....{INSYDE
    0010: 45 44 4B 32 49 4E 54 4C 02 00 00 00 20 20 20 20  // EDK2INTL....    
    0020: 13 00 00 01 00 00 10 01 00 00 00 00 00 F0 DE 2A  // ...............*
    0030: 00 00 00 00 01 00 10 01 00 00 00 00 00 E0 4D 2B  // ..............M+
    0040: 00 00 00 00                                      // ....
