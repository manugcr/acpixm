/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20241212 (64-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembling to symbolic ASL+ operators
 *
 * Disassembly of /home/ignatirabo/Downloads/output/ssdt8.dat
 *
 * Original Table Header:
 *     Signature        "SSDT"
 *     Length           0x00000A3D (2621)
 *     Revision         0x02
 *     Checksum         0x2A
 *     OEM ID           "INTEL "
 *     OEM Table ID     "IgfxSsdt"
 *     OEM Revision     0x00003000 (12288)
 *     Compiler ID      "INTL"
 *     Compiler Version 0x20210930 (539035952)
 */
DefinitionBlock ("", "SSDT", 2, "INTEL ", "IgfxSsdt", 0x00003000)
{
    External (_SB_.GGOV, MethodObj)    // 1 Arguments
    External (_SB_.PC00, DeviceObj)
    External (_SB_.PC00.GFX0, DeviceObj)
    External (_SB_.PC00.GFX0.DSEN, UnknownObj)
    External (_SB_.PC00.GFX0.EDMX, UnknownObj)
    External (_SB_.PC00.GFX0.HNOT, MethodObj)    // 1 Arguments
    External (_SB_.PC00.GFX0.OSYS, IntObj)
    External (_SB_.PC00.LPCB.H_EC.ECWT, MethodObj)    // 2 Arguments
    External (_SB_.PC00.LPCB.H_EC.LID0, DeviceObj)
    External (_SB_.PC00.LPCB.H_EC.LSTE, UnknownObj)
    External (_SB_.PC00.MC__, DeviceObj)
    External (_SB_.PC00.PC2M, MethodObj)    // 2 Arguments
    External (_SB_.SGOV, MethodObj)    // 2 Arguments
    External (ADBG, MethodObj)    // 1 Arguments
    External (ASLB, UnknownObj)
    External (BRTL, UnknownObj)
    External (DID1, UnknownObj)
    External (DID2, UnknownObj)
    External (DID3, UnknownObj)
    External (DID4, UnknownObj)
    External (DID5, UnknownObj)
    External (DID6, UnknownObj)
    External (DID7, UnknownObj)
    External (DID8, UnknownObj)
    External (DID9, UnknownObj)
    External (DIDA, UnknownObj)
    External (DIDB, UnknownObj)
    External (DIDC, UnknownObj)
    External (DIDD, UnknownObj)
    External (DIDE, UnknownObj)
    External (DIDF, UnknownObj)
    External (DIDX, UnknownObj)
    External (DIDY, UnknownObj)
    External (ECON, IntObj)
    External (EDPV, UnknownObj)
    External (HGDT, UnknownObj)
    External (IPTP, UnknownObj)
    External (LIDS, UnknownObj)
    External (NDID, UnknownObj)
    External (NXD1, UnknownObj)
    External (NXD2, UnknownObj)
    External (NXD3, UnknownObj)
    External (NXD4, UnknownObj)
    External (NXD5, UnknownObj)
    External (NXD6, UnknownObj)
    External (NXD7, UnknownObj)
    External (NXD8, UnknownObj)
    External (NXDX, UnknownObj)
    External (NXDY, UnknownObj)

    Scope (\_SB.PC00.GFX0)
    {
        Name (DPLD, Package (0x01)
        {
            Buffer (0x14)
            {
                /* 0000 */  0x82, 0x00, 0x00, 0x00, 0x20, 0x03, 0xD0, 0x07,  // .... ...
                /* 0008 */  0x41, 0x0E, 0x00, 0x00, 0x00, 0x00, 0x80, 0x01,  // A.......
                /* 0010 */  0x00, 0x00, 0x00, 0x00                           // ....
            }
        })
        OperationRegion (IGDP, PCI_Config, 0x40, 0xC0)
        Field (IGDP, AnyAcc, NoLock, Preserve)
        {
            Offset (0xBC), 
            ASLS,   32
        }

        OperationRegion (IGDM, SystemMemory, ASLB, 0x2000)
        Field (IGDM, AnyAcc, NoLock, Preserve)
        {
            SIGN,   128, 
            SIZE,   32, 
            OVER,   32, 
            SVER,   256, 
            VVER,   128, 
            GVER,   128, 
            MBOX,   32, 
            DMOD,   32, 
            PCON,   32, 
            DVER,   64, 
            Offset (0x100), 
            DRDY,   32, 
            CSTS,   32, 
            CEVT,   32, 
            Offset (0x120), 
            DIDL,   32, 
            DDL2,   32, 
            DDL3,   32, 
            DDL4,   32, 
            DDL5,   32, 
            DDL6,   32, 
            DDL7,   32, 
            DDL8,   32, 
            CPDL,   32, 
            CPL2,   32, 
            CPL3,   32, 
            CPL4,   32, 
            CPL5,   32, 
            CPL6,   32, 
            CPL7,   32, 
            CPL8,   32, 
            CADL,   32, 
            CAL2,   32, 
            CAL3,   32, 
            CAL4,   32, 
            CAL5,   32, 
            CAL6,   32, 
            CAL7,   32, 
            CAL8,   32, 
            NADL,   32, 
            NDL2,   32, 
            NDL3,   32, 
            NDL4,   32, 
            NDL5,   32, 
            NDL6,   32, 
            NDL7,   32, 
            NDL8,   32, 
            ASLP,   32, 
            TIDX,   32, 
            CHPD,   32, 
            CLID,   32, 
            CDCK,   32, 
            SXSW,   32, 
            EVTS,   32, 
            CNOT,   32, 
            NRDY,   32, 
            DDL9,   32, 
            DD10,   32, 
            DD11,   32, 
            DD12,   32, 
            DD13,   32, 
            DD14,   32, 
            DD15,   32, 
            Offset (0x200), 
            BCL1,   32, 
            BCL2,   32, 
            CBL1,   32, 
            CBL2,   32, 
            BCM1,   960, 
            BCM2,   960, 
            ARDY,   32, 
            ASLC,   32, 
            TCHE,   32, 
            ALSI,   32, 
            BCLP,   32, 
            PFIT,   32, 
            CBLV,   32, 
            BCLM,   320, 
            CPFM,   32, 
            EPFM,   32, 
            PLUT,   592, 
            PFMB,   32, 
            CCDV,   32, 
            PCFT,   32, 
            SROT,   32, 
            IUER,   32, 
            FDSS,   64, 
            FDSP,   32, 
            STAT,   32, 
            RVDA,   64, 
            RVDS,   32, 
            Offset (0x400), 
            RVBT,   49152, 
            PHED,   32, 
            BDDC,   2048
        }

        Method (PDRD, 0, NotSerialized)
        {
            Return (!DRDY)
        }

        Method (PSTS, 0, NotSerialized)
        {
            If ((CSTS > 0x02))
            {
                Sleep (ASLP)
            }

            Return ((CSTS == 0x03))
        }

        Method (GNOT, 2, NotSerialized)
        {
            If (PDRD ())
            {
                Return (One)
            }

            CEVT = Arg0
            CSTS = 0x03
            If ((Arg1 == Zero))
            {
                Notify (\_SB.PC00.GFX0, Arg1)
            }

            If (CondRefOf (HNOT))
            {
                HNOT (Arg0)
            }
            Else
            {
                Notify (\_SB.PC00.GFX0, 0x80) // Status Change
            }

            Return (Zero)
        }

        Method (GLID, 1, NotSerialized)
        {
            If ((Arg0 == One))
            {
                CLID = 0x03
            }
            Else
            {
                CLID = Arg0
            }

            If (GNOT (0x02, Zero))
            {
                CLID |= 0x80000000
                Return (One)
            }

            Return (Zero)
        }

        Method (GDCK, 1, NotSerialized)
        {
            CDCK = Arg0
            Return (GNOT (0x04, Zero))
        }

        Method (IUEH, 1, Serialized)
        {
            IUER &= 0xC0
            IUER ^= (One << Arg0)
            If ((Arg0 <= 0x04))
            {
                Return (AINT (0x05, Zero))
            }
            Else
            {
                Return (AINT (Arg0, Zero))
            }
        }

        Method (AINT, 2, NotSerialized)
        {
            If (((Arg0 >= 0x05) && (Arg0 <= 0x07)))
            {
                Local2 = Zero
                While ((Local2 < 0xFA))
                {
                    Sleep (0x04)
                    Local2++
                }

                Return (Zero)
            }

            If ((Arg0 == One))
            {
                BCL1 = Arg1
                BCL1 |= 0x80000000
            }

            Return (Zero)
        }

        Method (_DSM, 4, Serialized)  // _DSM: Device-Specific Method
        {
            If ((Arg0 == ToUUID ("3e5b41c6-eb1d-4260-9d15-c71fbadae414") /* Unknown UUID */))
            {
                Switch (ToInteger (Arg2))
                {
                    Case (Zero)
                    {
                        If ((Arg1 == One))
                        {
                            Debug = "iGfx Supported Functions Bitmap "
                            ADBG ("iGFX Empty Dongle SKU supported")
                            Local0 = One
                            If ((EDMX != Zero))
                            {
                                ADBG ("Display Mux Supported")
                                Local0 |= 0x00200000
                            }

                            Local0 |= 0x00400000
                            ADBG (Concatenate ("IGFX DSM Function Support = ", ToHexString (Local0)))
                            Return (Local0)
                        }
                    }
                    Case (0x15)
                    {
                        Name (DGDB, Buffer (0x05)
                        {
                             0x00, 0x00, 0x00, 0x00, 0x00                     // .....
                        })
                        CreateDWordField (DGDB, Zero, DGDF)
                        CreateByteField (DGDB, 0x04, DGSF)
                        Local0 = One
                        ADBG ("IGD eDP _DSM (21)")
                        If (((DerefOf (Arg3 [Zero]) & One) == Zero))
                        {
                            ADBG ("Get Current Disp Mux Status")
                            \_SB.GGOV (EDMX)
                            Local0 = Zero
                        }
                        Else
                        {
                            ADBG ("Set Disp Mux Status")
                            If (((DerefOf (Arg3 [Zero]) & 0x02) == Zero))
                            {
                                ADBG ("Set Disp Mux to iGfx")
                                \_SB.SGOV (EDMX, Zero)
                                Local0 = Zero
                            }
                            Else
                            {
                                ADBG ("Set Disp Mux to dGfx")
                                \_SB.SGOV (EDMX, One)
                                Local0 = Zero
                            }
                        }

                        DGDF = (\_SB.GGOV (EDMX) << One)
                        DGSF = Local0
                        ADBG (Concatenate ("ExitResult :: ", ToHexString (DGSF)))
                        ADBG (Concatenate ("Current Mux :: ", ToHexString (DGDF)))
                        Return (DGDB) /* \_SB_.PC00.GFX0._DSM.DGDB */
                    }
                    Case (0x16)
                    {
                        Switch (ToInteger (Arg3))
                        {
                            Case (Zero)
                            {
                                If (CondRefOf (\_SB.PC00.LPCB.H_EC.LSTE))
                                {
                                    \_SB.PC00.LPCB.H_EC.ECWT (Zero, RefOf (\_SB.PC00.LPCB.H_EC.LSTE))
                                    LIDS = Zero
                                    \_SB.PC00.GFX0.CLID = Zero
                                    ADBG ("Notify LID0")
                                    Notify (\_SB.PC00.LPCB.H_EC.LID0, 0x80) // Status Change
                                    ADBG ("OS Notified")
                                    Return (Zero)
                                }
                                Else
                                {
                                    ADBG ("Lid close failed")
                                }
                            }
                            Case (One)
                            {
                                If (CondRefOf (\_SB.PC00.LPCB.H_EC.LSTE))
                                {
                                    \_SB.PC00.LPCB.H_EC.ECWT (One, RefOf (\_SB.PC00.LPCB.H_EC.LSTE))
                                    LIDS = One
                                    \_SB.PC00.GFX0.CLID = 0x03
                                    ADBG ("Notify LID0")
                                    Notify (\_SB.PC00.LPCB.H_EC.LID0, 0x80) // Status Change
                                    ADBG ("OS Notified")
                                    Return (Zero)
                                }
                                Else
                                {
                                    ADBG ("Lid open failed")
                                }
                            }
                            Default
                            {
                                Return (One)
                            }

                        }
                    }

                }
            }

            Return (Buffer (One)
            {
                 0x00                                             // .
            })
        }

        Method (_S3D, 0, NotSerialized)  // _S3D: S3 Device State
        {
            Return (0x03)
        }

        Method (_S4D, 0, NotSerialized)  // _S4D: S4 Device State
        {
            Return (0x03)
        }

        Method (_PS0, 0, Serialized)  // _PS0: Power State 0
        {
        }

        Method (_PS3, 0, Serialized)  // _PS3: Power State 3
        {
        }

        Method (GFPS, 0, Serialized)
        {
            OperationRegion (PXCS, SystemMemory, \_SB.PC00.PC2M (0x00020000, Zero), 0x0100)
            Field (PXCS, AnyAcc, NoLock, Preserve)
            {
                Offset (0xD4), 
                D3HT,   2
            }

            Return (D3HT) /* \_SB_.PC00.GFX0.GFPS.D3HT */
        }
    }
}

