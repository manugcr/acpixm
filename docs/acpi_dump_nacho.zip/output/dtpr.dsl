/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20241212 (64-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembly of /home/ignatirabo/Downloads/output/dtpr.dat
 *
 * ACPI Data Table [DTPR]
 *
 * Format: [HexOffset DecimalOffset ByteLength]  FieldName : FieldValue (in hex)
 */

[000h 0000 004h]                   Signature : "DTPR"    
[004h 0004 004h]                Table Length : 00000098
[008h 0008 001h]                    Revision : 01
[009h 0009 001h]                    Checksum : 3E
[00Ah 0010 006h]                      Oem ID : ""
[010h 0016 008h]                Oem Table ID : ""
[018h 0024 004h]                Oem Revision : 00000000
[01Ch 0028 004h]             Asl Compiler ID : ""
[020h 0032 004h]       Asl Compiler Revision : 00000000


**** Unknown ACPI table signature [DTPR]


Raw Table Data: Length 152 (0x98)

    0000: 44 54 50 52 98 00 00 00 01 3E 00 00 00 00 00 00  // DTPR.....>......
    0010: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0020: 00 00 00 00 00 00 00 00 01 00 00 00 00 00 00 00  // ................
    0030: 02 00 00 00 60 16 DD FE 00 00 00 00 90 16 DD FE  // ....`...........
    0040: 00 00 00 00 0A 00 00 00 28 BD 28 D0 00 00 00 00  // ........(.(.....
    0050: 28 3D 29 D0 00 00 00 00 28 BD 31 D0 00 00 00 00  // (=).....(.1.....
    0060: 28 BD 29 D0 00 00 00 00 28 BD 40 D0 00 00 00 00  // (.).....(.@.....
    0070: 28 3D 41 D0 00 00 00 00 28 BD 38 D0 00 00 00 00  // (=A.....(.8.....
    0080: 28 3D 39 D0 00 00 00 00 28 BD 30 D0 00 00 00 00  // (=9.....(.0.....
    0090: 28 3D 31 D0 00 00 00 00                          // (=1.....
