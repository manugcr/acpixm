/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20241212 (64-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembly of /home/ignatirabo/Downloads/output/apic.dat
 *
 * ACPI Data Table [APIC]
 *
 * Format: [HexOffset DecimalOffset ByteLength]  FieldName : FieldValue (in hex)
 */

[000h 0000 004h]                   Signature : "APIC"    [Multiple APIC Description Table (MADT)]
[004h 0004 004h]                Table Length : 00000358
[008h 0008 001h]                    Revision : 05
[009h 0009 001h]                    Checksum : 22
[00Ah 0010 006h]                      Oem ID : "DELL  "
[010h 0016 008h]                Oem Table ID : "Dell Inc"
[018h 0024 004h]                Oem Revision : 00000002
[01Ch 0028 004h]             Asl Compiler ID : "    "
[020h 0032 004h]       Asl Compiler Revision : 01000013

[024h 0036 004h]          Local Apic Address : FEE00000
[028h 0040 004h]       Flags (decoded below) : 00000001
                         PC-AT Compatibility : 1

[02Ch 0044 001h]               Subtable Type : 09 [Processor Local x2APIC]
[02Dh 0045 001h]                      Length : 10
[02Eh 0046 002h]                    Reserved : 0000
[030h 0048 004h]         Processor x2Apic ID : 00000010
[034h 0052 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[038h 0056 004h]               Processor UID : 00000008

[03Ch 0060 001h]               Subtable Type : 09 [Processor Local x2APIC]
[03Dh 0061 001h]                      Length : 10
[03Eh 0062 002h]                    Reserved : 0000
[040h 0064 004h]         Processor x2Apic ID : 00000011
[044h 0068 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[048h 0072 004h]               Processor UID : 00000009

[04Ch 0076 001h]               Subtable Type : 09 [Processor Local x2APIC]
[04Dh 0077 001h]                      Length : 10
[04Eh 0078 002h]                    Reserved : 0000
[050h 0080 004h]         Processor x2Apic ID : 00000018
[054h 0084 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[058h 0088 004h]               Processor UID : 0000000A

[05Ch 0092 001h]               Subtable Type : 09 [Processor Local x2APIC]
[05Dh 0093 001h]                      Length : 10
[05Eh 0094 002h]                    Reserved : 0000
[060h 0096 004h]         Processor x2Apic ID : 00000019
[064h 0100 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[068h 0104 004h]               Processor UID : 0000000B

[06Ch 0108 001h]               Subtable Type : 09 [Processor Local x2APIC]
[06Dh 0109 001h]                      Length : 10
[06Eh 0110 002h]                    Reserved : 0000
[070h 0112 004h]         Processor x2Apic ID : 00000000
[074h 0116 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[078h 0120 004h]               Processor UID : 00000000

[07Ch 0124 001h]               Subtable Type : 09 [Processor Local x2APIC]
[07Dh 0125 001h]                      Length : 10
[07Eh 0126 002h]                    Reserved : 0000
[080h 0128 004h]         Processor x2Apic ID : 00000002
[084h 0132 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[088h 0136 004h]               Processor UID : 00000001

[08Ch 0140 001h]               Subtable Type : 09 [Processor Local x2APIC]
[08Dh 0141 001h]                      Length : 10
[08Eh 0142 002h]                    Reserved : 0000
[090h 0144 004h]         Processor x2Apic ID : 00000004
[094h 0148 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[098h 0152 004h]               Processor UID : 00000002

[09Ch 0156 001h]               Subtable Type : 09 [Processor Local x2APIC]
[09Dh 0157 001h]                      Length : 10
[09Eh 0158 002h]                    Reserved : 0000
[0A0h 0160 004h]         Processor x2Apic ID : 00000006
[0A4h 0164 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[0A8h 0168 004h]               Processor UID : 00000003

[0ACh 0172 001h]               Subtable Type : 09 [Processor Local x2APIC]
[0ADh 0173 001h]                      Length : 10
[0AEh 0174 002h]                    Reserved : 0000
[0B0h 0176 004h]         Processor x2Apic ID : 00000008
[0B4h 0180 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[0B8h 0184 004h]               Processor UID : 00000004

[0BCh 0188 001h]               Subtable Type : 09 [Processor Local x2APIC]
[0BDh 0189 001h]                      Length : 10
[0BEh 0190 002h]                    Reserved : 0000
[0C0h 0192 004h]         Processor x2Apic ID : 0000000A
[0C4h 0196 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[0C8h 0200 004h]               Processor UID : 00000005

[0CCh 0204 001h]               Subtable Type : 09 [Processor Local x2APIC]
[0CDh 0205 001h]                      Length : 10
[0CEh 0206 002h]                    Reserved : 0000
[0D0h 0208 004h]         Processor x2Apic ID : 0000000C
[0D4h 0212 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[0D8h 0216 004h]               Processor UID : 00000006

[0DCh 0220 001h]               Subtable Type : 09 [Processor Local x2APIC]
[0DDh 0221 001h]                      Length : 10
[0DEh 0222 002h]                    Reserved : 0000
[0E0h 0224 004h]         Processor x2Apic ID : 0000000E
[0E4h 0228 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[0E8h 0232 004h]               Processor UID : 00000007

[0ECh 0236 001h]               Subtable Type : 09 [Processor Local x2APIC]
[0EDh 0237 001h]                      Length : 10
[0EEh 0238 002h]                    Reserved : 0000
[0F0h 0240 004h]         Processor x2Apic ID : 00000040
[0F4h 0244 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[0F8h 0248 004h]               Processor UID : 0000000C

[0FCh 0252 001h]               Subtable Type : 09 [Processor Local x2APIC]
[0FDh 0253 001h]                      Length : 10
[0FEh 0254 002h]                    Reserved : 0000
[100h 0256 004h]         Processor x2Apic ID : 00000042
[104h 0260 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
[108h 0264 004h]               Processor UID : 0000000D

[10Ch 0268 001h]               Subtable Type : 09 [Processor Local x2APIC]
[10Dh 0269 001h]                      Length : 10
[10Eh 0270 002h]                    Reserved : 0000
[110h 0272 004h]         Processor x2Apic ID : FFFFFFFF
[114h 0276 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[118h 0280 004h]               Processor UID : 0000000E

[11Ch 0284 001h]               Subtable Type : 09 [Processor Local x2APIC]
[11Dh 0285 001h]                      Length : 10
[11Eh 0286 002h]                    Reserved : 0000
[120h 0288 004h]         Processor x2Apic ID : FFFFFFFF
[124h 0292 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[128h 0296 004h]               Processor UID : 0000000F

[12Ch 0300 001h]               Subtable Type : 09 [Processor Local x2APIC]
[12Dh 0301 001h]                      Length : 10
[12Eh 0302 002h]                    Reserved : 0000
[130h 0304 004h]         Processor x2Apic ID : FFFFFFFF
[134h 0308 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[138h 0312 004h]               Processor UID : 00000010

[13Ch 0316 001h]               Subtable Type : 09 [Processor Local x2APIC]
[13Dh 0317 001h]                      Length : 10
[13Eh 0318 002h]                    Reserved : 0000
[140h 0320 004h]         Processor x2Apic ID : FFFFFFFF
[144h 0324 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[148h 0328 004h]               Processor UID : 00000011

[14Ch 0332 001h]               Subtable Type : 09 [Processor Local x2APIC]
[14Dh 0333 001h]                      Length : 10
[14Eh 0334 002h]                    Reserved : 0000
[150h 0336 004h]         Processor x2Apic ID : FFFFFFFF
[154h 0340 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[158h 0344 004h]               Processor UID : 00000012

[15Ch 0348 001h]               Subtable Type : 09 [Processor Local x2APIC]
[15Dh 0349 001h]                      Length : 10
[15Eh 0350 002h]                    Reserved : 0000
[160h 0352 004h]         Processor x2Apic ID : FFFFFFFF
[164h 0356 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[168h 0360 004h]               Processor UID : 00000013

[16Ch 0364 001h]               Subtable Type : 09 [Processor Local x2APIC]
[16Dh 0365 001h]                      Length : 10
[16Eh 0366 002h]                    Reserved : 0000
[170h 0368 004h]         Processor x2Apic ID : FFFFFFFF
[174h 0372 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[178h 0376 004h]               Processor UID : 00000014

[17Ch 0380 001h]               Subtable Type : 09 [Processor Local x2APIC]
[17Dh 0381 001h]                      Length : 10
[17Eh 0382 002h]                    Reserved : 0000
[180h 0384 004h]         Processor x2Apic ID : FFFFFFFF
[184h 0388 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[188h 0392 004h]               Processor UID : 00000015

[18Ch 0396 001h]               Subtable Type : 09 [Processor Local x2APIC]
[18Dh 0397 001h]                      Length : 10
[18Eh 0398 002h]                    Reserved : 0000
[190h 0400 004h]         Processor x2Apic ID : FFFFFFFF
[194h 0404 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[198h 0408 004h]               Processor UID : 00000016

[19Ch 0412 001h]               Subtable Type : 09 [Processor Local x2APIC]
[19Dh 0413 001h]                      Length : 10
[19Eh 0414 002h]                    Reserved : 0000
[1A0h 0416 004h]         Processor x2Apic ID : FFFFFFFF
[1A4h 0420 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[1A8h 0424 004h]               Processor UID : 00000017

[1ACh 0428 001h]               Subtable Type : 09 [Processor Local x2APIC]
[1ADh 0429 001h]                      Length : 10
[1AEh 0430 002h]                    Reserved : 0000
[1B0h 0432 004h]         Processor x2Apic ID : FFFFFFFF
[1B4h 0436 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[1B8h 0440 004h]               Processor UID : 00000018

[1BCh 0444 001h]               Subtable Type : 09 [Processor Local x2APIC]
[1BDh 0445 001h]                      Length : 10
[1BEh 0446 002h]                    Reserved : 0000
[1C0h 0448 004h]         Processor x2Apic ID : FFFFFFFF
[1C4h 0452 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[1C8h 0456 004h]               Processor UID : 00000019

[1CCh 0460 001h]               Subtable Type : 09 [Processor Local x2APIC]
[1CDh 0461 001h]                      Length : 10
[1CEh 0462 002h]                    Reserved : 0000
[1D0h 0464 004h]         Processor x2Apic ID : FFFFFFFF
[1D4h 0468 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[1D8h 0472 004h]               Processor UID : 0000001A

[1DCh 0476 001h]               Subtable Type : 09 [Processor Local x2APIC]
[1DDh 0477 001h]                      Length : 10
[1DEh 0478 002h]                    Reserved : 0000
[1E0h 0480 004h]         Processor x2Apic ID : FFFFFFFF
[1E4h 0484 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[1E8h 0488 004h]               Processor UID : 0000001B

[1ECh 0492 001h]               Subtable Type : 09 [Processor Local x2APIC]
[1EDh 0493 001h]                      Length : 10
[1EEh 0494 002h]                    Reserved : 0000
[1F0h 0496 004h]         Processor x2Apic ID : FFFFFFFF
[1F4h 0500 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[1F8h 0504 004h]               Processor UID : 0000001C

[1FCh 0508 001h]               Subtable Type : 09 [Processor Local x2APIC]
[1FDh 0509 001h]                      Length : 10
[1FEh 0510 002h]                    Reserved : 0000
[200h 0512 004h]         Processor x2Apic ID : FFFFFFFF
[204h 0516 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[208h 0520 004h]               Processor UID : 0000001D

[20Ch 0524 001h]               Subtable Type : 09 [Processor Local x2APIC]
[20Dh 0525 001h]                      Length : 10
[20Eh 0526 002h]                    Reserved : 0000
[210h 0528 004h]         Processor x2Apic ID : FFFFFFFF
[214h 0532 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[218h 0536 004h]               Processor UID : 0000001E

[21Ch 0540 001h]               Subtable Type : 09 [Processor Local x2APIC]
[21Dh 0541 001h]                      Length : 10
[21Eh 0542 002h]                    Reserved : 0000
[220h 0544 004h]         Processor x2Apic ID : FFFFFFFF
[224h 0548 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[228h 0552 004h]               Processor UID : 0000001F

[22Ch 0556 001h]               Subtable Type : 09 [Processor Local x2APIC]
[22Dh 0557 001h]                      Length : 10
[22Eh 0558 002h]                    Reserved : 0000
[230h 0560 004h]         Processor x2Apic ID : FFFFFFFF
[234h 0564 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[238h 0568 004h]               Processor UID : 00000020

[23Ch 0572 001h]               Subtable Type : 09 [Processor Local x2APIC]
[23Dh 0573 001h]                      Length : 10
[23Eh 0574 002h]                    Reserved : 0000
[240h 0576 004h]         Processor x2Apic ID : FFFFFFFF
[244h 0580 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[248h 0584 004h]               Processor UID : 00000021

[24Ch 0588 001h]               Subtable Type : 09 [Processor Local x2APIC]
[24Dh 0589 001h]                      Length : 10
[24Eh 0590 002h]                    Reserved : 0000
[250h 0592 004h]         Processor x2Apic ID : FFFFFFFF
[254h 0596 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[258h 0600 004h]               Processor UID : 00000022

[25Ch 0604 001h]               Subtable Type : 09 [Processor Local x2APIC]
[25Dh 0605 001h]                      Length : 10
[25Eh 0606 002h]                    Reserved : 0000
[260h 0608 004h]         Processor x2Apic ID : FFFFFFFF
[264h 0612 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[268h 0616 004h]               Processor UID : 00000023

[26Ch 0620 001h]               Subtable Type : 09 [Processor Local x2APIC]
[26Dh 0621 001h]                      Length : 10
[26Eh 0622 002h]                    Reserved : 0000
[270h 0624 004h]         Processor x2Apic ID : FFFFFFFF
[274h 0628 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[278h 0632 004h]               Processor UID : 00000024

[27Ch 0636 001h]               Subtable Type : 09 [Processor Local x2APIC]
[27Dh 0637 001h]                      Length : 10
[27Eh 0638 002h]                    Reserved : 0000
[280h 0640 004h]         Processor x2Apic ID : FFFFFFFF
[284h 0644 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[288h 0648 004h]               Processor UID : 00000025

[28Ch 0652 001h]               Subtable Type : 09 [Processor Local x2APIC]
[28Dh 0653 001h]                      Length : 10
[28Eh 0654 002h]                    Reserved : 0000
[290h 0656 004h]         Processor x2Apic ID : FFFFFFFF
[294h 0660 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[298h 0664 004h]               Processor UID : 00000026

[29Ch 0668 001h]               Subtable Type : 09 [Processor Local x2APIC]
[29Dh 0669 001h]                      Length : 10
[29Eh 0670 002h]                    Reserved : 0000
[2A0h 0672 004h]         Processor x2Apic ID : FFFFFFFF
[2A4h 0676 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[2A8h 0680 004h]               Processor UID : 00000027

[2ACh 0684 001h]               Subtable Type : 09 [Processor Local x2APIC]
[2ADh 0685 001h]                      Length : 10
[2AEh 0686 002h]                    Reserved : 0000
[2B0h 0688 004h]         Processor x2Apic ID : FFFFFFFF
[2B4h 0692 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[2B8h 0696 004h]               Processor UID : 00000028

[2BCh 0700 001h]               Subtable Type : 09 [Processor Local x2APIC]
[2BDh 0701 001h]                      Length : 10
[2BEh 0702 002h]                    Reserved : 0000
[2C0h 0704 004h]         Processor x2Apic ID : FFFFFFFF
[2C4h 0708 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[2C8h 0712 004h]               Processor UID : 00000029

[2CCh 0716 001h]               Subtable Type : 09 [Processor Local x2APIC]
[2CDh 0717 001h]                      Length : 10
[2CEh 0718 002h]                    Reserved : 0000
[2D0h 0720 004h]         Processor x2Apic ID : FFFFFFFF
[2D4h 0724 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[2D8h 0728 004h]               Processor UID : 0000002A

[2DCh 0732 001h]               Subtable Type : 09 [Processor Local x2APIC]
[2DDh 0733 001h]                      Length : 10
[2DEh 0734 002h]                    Reserved : 0000
[2E0h 0736 004h]         Processor x2Apic ID : FFFFFFFF
[2E4h 0740 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[2E8h 0744 004h]               Processor UID : 0000002B

[2ECh 0748 001h]               Subtable Type : 09 [Processor Local x2APIC]
[2EDh 0749 001h]                      Length : 10
[2EEh 0750 002h]                    Reserved : 0000
[2F0h 0752 004h]         Processor x2Apic ID : FFFFFFFF
[2F4h 0756 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[2F8h 0760 004h]               Processor UID : 0000002C

[2FCh 0764 001h]               Subtable Type : 09 [Processor Local x2APIC]
[2FDh 0765 001h]                      Length : 10
[2FEh 0766 002h]                    Reserved : 0000
[300h 0768 004h]         Processor x2Apic ID : FFFFFFFF
[304h 0772 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[308h 0776 004h]               Processor UID : 0000002D

[30Ch 0780 001h]               Subtable Type : 09 [Processor Local x2APIC]
[30Dh 0781 001h]                      Length : 10
[30Eh 0782 002h]                    Reserved : 0000
[310h 0784 004h]         Processor x2Apic ID : FFFFFFFF
[314h 0788 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[318h 0792 004h]               Processor UID : 0000002E

[31Ch 0796 001h]               Subtable Type : 09 [Processor Local x2APIC]
[31Dh 0797 001h]                      Length : 10
[31Eh 0798 002h]                    Reserved : 0000
[320h 0800 004h]         Processor x2Apic ID : FFFFFFFF
[324h 0804 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
[328h 0808 004h]               Processor UID : 0000002F

[32Ch 0812 001h]               Subtable Type : 01 [I/O APIC]
[32Dh 0813 001h]                      Length : 0C
[32Eh 0814 001h]                 I/O Apic ID : 02
[32Fh 0815 001h]                    Reserved : 00
[330h 0816 004h]                     Address : FEC00000
[334h 0820 004h]                   Interrupt : 00000000

[338h 0824 001h]               Subtable Type : 02 [Interrupt Source Override]
[339h 0825 001h]                      Length : 0A
[33Ah 0826 001h]                         Bus : 00
[33Bh 0827 001h]                      Source : 00
[33Ch 0828 004h]                   Interrupt : 00000002
[340h 0832 002h]       Flags (decoded below) : 0000
                                    Polarity : 0
                                Trigger Mode : 0

[342h 0834 001h]               Subtable Type : 02 [Interrupt Source Override]
[343h 0835 001h]                      Length : 0A
[344h 0836 001h]                         Bus : 00
[345h 0837 001h]                      Source : 09
[346h 0838 004h]                   Interrupt : 00000009
[34Ah 0842 002h]       Flags (decoded below) : 000D
                                    Polarity : 1
                                Trigger Mode : 3

[34Ch 0844 001h]               Subtable Type : 0A [Local x2APIC NMI]
[34Dh 0845 001h]                      Length : 0C
[34Eh 0846 002h]       Flags (decoded below) : 000D
                                    Polarity : 1
                                Trigger Mode : 3
[350h 0848 004h]               Processor UID : FFFFFFFF
[354h 0852 001h]        Interrupt Input LINT : 01
[355h 0853 003h]                    Reserved : 000000

Raw Table Data: Length 856 (0x358)

    0000: 41 50 49 43 58 03 00 00 05 22 44 45 4C 4C 20 20  // APICX...."DELL  
    0010: 44 65 6C 6C 20 49 6E 63 02 00 00 00 20 20 20 20  // Dell Inc....    
    0020: 13 00 00 01 00 00 E0 FE 01 00 00 00 09 10 00 00  // ................
    0030: 10 00 00 00 01 00 00 00 08 00 00 00 09 10 00 00  // ................
    0040: 11 00 00 00 01 00 00 00 09 00 00 00 09 10 00 00  // ................
    0050: 18 00 00 00 01 00 00 00 0A 00 00 00 09 10 00 00  // ................
    0060: 19 00 00 00 01 00 00 00 0B 00 00 00 09 10 00 00  // ................
    0070: 00 00 00 00 01 00 00 00 00 00 00 00 09 10 00 00  // ................
    0080: 02 00 00 00 01 00 00 00 01 00 00 00 09 10 00 00  // ................
    0090: 04 00 00 00 01 00 00 00 02 00 00 00 09 10 00 00  // ................
    00A0: 06 00 00 00 01 00 00 00 03 00 00 00 09 10 00 00  // ................
    00B0: 08 00 00 00 01 00 00 00 04 00 00 00 09 10 00 00  // ................
    00C0: 0A 00 00 00 01 00 00 00 05 00 00 00 09 10 00 00  // ................
    00D0: 0C 00 00 00 01 00 00 00 06 00 00 00 09 10 00 00  // ................
    00E0: 0E 00 00 00 01 00 00 00 07 00 00 00 09 10 00 00  // ................
    00F0: 40 00 00 00 01 00 00 00 0C 00 00 00 09 10 00 00  // @...............
    0100: 42 00 00 00 01 00 00 00 0D 00 00 00 09 10 00 00  // B...............
    0110: FF FF FF FF 00 00 00 00 0E 00 00 00 09 10 00 00  // ................
    0120: FF FF FF FF 00 00 00 00 0F 00 00 00 09 10 00 00  // ................
    0130: FF FF FF FF 00 00 00 00 10 00 00 00 09 10 00 00  // ................
    0140: FF FF FF FF 00 00 00 00 11 00 00 00 09 10 00 00  // ................
    0150: FF FF FF FF 00 00 00 00 12 00 00 00 09 10 00 00  // ................
    0160: FF FF FF FF 00 00 00 00 13 00 00 00 09 10 00 00  // ................
    0170: FF FF FF FF 00 00 00 00 14 00 00 00 09 10 00 00  // ................
    0180: FF FF FF FF 00 00 00 00 15 00 00 00 09 10 00 00  // ................
    0190: FF FF FF FF 00 00 00 00 16 00 00 00 09 10 00 00  // ................
    01A0: FF FF FF FF 00 00 00 00 17 00 00 00 09 10 00 00  // ................
    01B0: FF FF FF FF 00 00 00 00 18 00 00 00 09 10 00 00  // ................
    01C0: FF FF FF FF 00 00 00 00 19 00 00 00 09 10 00 00  // ................
    01D0: FF FF FF FF 00 00 00 00 1A 00 00 00 09 10 00 00  // ................
    01E0: FF FF FF FF 00 00 00 00 1B 00 00 00 09 10 00 00  // ................
    01F0: FF FF FF FF 00 00 00 00 1C 00 00 00 09 10 00 00  // ................
    0200: FF FF FF FF 00 00 00 00 1D 00 00 00 09 10 00 00  // ................
    0210: FF FF FF FF 00 00 00 00 1E 00 00 00 09 10 00 00  // ................
    0220: FF FF FF FF 00 00 00 00 1F 00 00 00 09 10 00 00  // ................
    0230: FF FF FF FF 00 00 00 00 20 00 00 00 09 10 00 00  // ........ .......
    0240: FF FF FF FF 00 00 00 00 21 00 00 00 09 10 00 00  // ........!.......
    0250: FF FF FF FF 00 00 00 00 22 00 00 00 09 10 00 00  // ........".......
    0260: FF FF FF FF 00 00 00 00 23 00 00 00 09 10 00 00  // ........#.......
    0270: FF FF FF FF 00 00 00 00 24 00 00 00 09 10 00 00  // ........$.......
    0280: FF FF FF FF 00 00 00 00 25 00 00 00 09 10 00 00  // ........%.......
    0290: FF FF FF FF 00 00 00 00 26 00 00 00 09 10 00 00  // ........&.......
    02A0: FF FF FF FF 00 00 00 00 27 00 00 00 09 10 00 00  // ........'.......
    02B0: FF FF FF FF 00 00 00 00 28 00 00 00 09 10 00 00  // ........(.......
    02C0: FF FF FF FF 00 00 00 00 29 00 00 00 09 10 00 00  // ........).......
    02D0: FF FF FF FF 00 00 00 00 2A 00 00 00 09 10 00 00  // ........*.......
    02E0: FF FF FF FF 00 00 00 00 2B 00 00 00 09 10 00 00  // ........+.......
    02F0: FF FF FF FF 00 00 00 00 2C 00 00 00 09 10 00 00  // ........,.......
    0300: FF FF FF FF 00 00 00 00 2D 00 00 00 09 10 00 00  // ........-.......
    0310: FF FF FF FF 00 00 00 00 2E 00 00 00 09 10 00 00  // ................
    0320: FF FF FF FF 00 00 00 00 2F 00 00 00 01 0C 02 00  // ......../.......
    0330: 00 00 C0 FE 00 00 00 00 02 0A 00 00 02 00 00 00  // ................
    0340: 00 00 02 0A 00 09 09 00 00 00 0D 00 0A 0C 0D 00  // ................
    0350: FF FF FF FF 01 00 00 00                          // ........
