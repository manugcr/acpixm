/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20241212 (64-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembly of /home/ignatirabo/Downloads/output/msdm.dat
 *
 * ACPI Data Table [MSDM]
 *
 * Format: [HexOffset DecimalOffset ByteLength]  FieldName : FieldValue (in hex)
 */

[000h 0000 004h]                   Signature : "MSDM"    [Microsoft Data Management Table]
[004h 0004 004h]                Table Length : 00000055
[008h 0008 001h]                    Revision : 03
[009h 0009 001h]                    Checksum : 2B
[00Ah 0010 006h]                      Oem ID : "DELL  "
[010h 0016 008h]                Oem Table ID : "CBX3   "
[018h 0024 004h]                Oem Revision : 06222004
[01Ch 0028 004h]             Asl Compiler ID : "AMI "
[020h 0032 004h]       Asl Compiler Revision : 00010013

[024h 0036 031h] Software Licensing Structure : 01 00 00 00 00 00 00 00 01 00 00 00 00 00 00 00 /* ................ */\
/* 034h 0052  16 */                            1D 00 00 00 50 33 57 59 4E 2D 38 47 4B 51 4D 2D /* ....P3WYN-8GKQM- */\
/* 044h 0068  16 */                            4B 42 37 51 59 2D 57 33 4D 56 52 2D 56 4D 4A 47 /* KB7QY-W3MVR-VMJG */\
/* 054h 0084   1 */                            47                                              /* G */\

Raw Table Data: Length 85 (0x55)

    0000: 4D 53 44 4D 55 00 00 00 03 2B 44 45 4C 4C 20 20  // MSDMU....+DELL  
    0010: 43 42 58 33 20 20 20 00 04 20 22 06 41 4D 49 20  // CBX3   .. ".AMI 
    0020: 13 00 01 00 01 00 00 00 00 00 00 00 01 00 00 00  // ................
    0030: 00 00 00 00 1D 00 00 00 50 33 57 59 4E 2D 38 47  // ........P3WYN-8G
    0040: 4B 51 4D 2D 4B 42 37 51 59 2D 57 33 4D 56 52 2D  // KQM-KB7QY-W3MVR-
    0050: 56 4D 4A 47 47                                   // VMJGG
