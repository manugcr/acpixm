/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20241212 (64-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembling to symbolic ASL+ operators
 *
 * Disassembly of /home/ignatirabo/Downloads/output/ssdt17.dat
 *
 * Original Table Header:
 *     Signature        "SSDT"
 *     Length           0x00000024 (36)
 *     Revision         0x02
 *     Checksum         0x61
 *     OEM ID           "INTEL "
 *     OEM Table ID     "TxtSsdt"
 *     OEM Revision     0x00001000 (4096)
 *     Compiler ID      "INTL"
 *     Compiler Version 0x20210930 (539035952)
 */
DefinitionBlock ("", "SSDT", 2, "INTEL ", "TxtSsdt", 0x00001000)
{
