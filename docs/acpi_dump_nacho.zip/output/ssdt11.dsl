/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20241212 (64-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembling to symbolic ASL+ operators
 *
 * Disassembly of /home/ignatirabo/Downloads/output/ssdt11.dat
 *
 * Original Table Header:
 *     Signature        "SSDT"
 *     Length           0x0000043C (1084)
 *     Revision         0x02
 *     Checksum         0x43
 *     OEM ID           "CIRRUS"
 *     OEM Table ID     "SPKRAMPS"
 *     OEM Revision     0x00000002 (2)
 *     Compiler ID      "INTL"
 *     Compiler Version 0x20210930 (539035952)
 */
DefinitionBlock ("", "SSDT", 2, "CIRRUS", "SPKRAMPS", 0x00000002)
{
    External (_SB_.PC00.SPI0, DeviceObj)
    External (BMID, UnknownObj)
    External (SMSW, IntObj)

    Name (GPIB, ResourceTemplate ()
    {
        GpioIo (Exclusive, PullDown, 0x0000, 0x0000, IoRestrictionOutputOnly,
            "\\_SB.GPI0", 0x00, ResourceConsumer, ,
            )
            {   // Pin list
                0x0080
            }
        GpioIo (Exclusive, PullUp, 0x0000, 0x0000, IoRestrictionInputOnly,
            "\\_SB.GPI0", 0x00, ResourceConsumer, ,
            )
            {   // Pin list
                0x00D6
            }
        GpioIo (Shared, PullUp, 0x0064, 0x0000, IoRestrictionInputOnly,
            "\\_SB.GPI0", 0x00, ResourceConsumer, ,
            )
            {   // Pin list
                0x0194
            }
        GpioInt (Edge, ActiveBoth, Shared, PullUp, 0x0064,
            "\\_SB.GPI0", 0x00, ResourceConsumer, ,
            )
            {   // Pin list
                0x0194
            }
    })
    Name (GPIA, ResourceTemplate ()
    {
        GpioIo (Exclusive, PullDown, 0x0000, 0x0000, IoRestrictionOutputOnly,
            "\\_SB.GPI0", 0x00, ResourceConsumer, ,
            )
            {   // Pin list
                0x0080
            }
        GpioIo (Exclusive, PullUp, 0x0000, 0x0000, IoRestrictionInputOnly,
            "\\_SB.GPI0", 0x00, ResourceConsumer, ,
            )
            {   // Pin list
                0x00D7
            }
        GpioIo (Shared, PullUp, 0x0064, 0x0000, IoRestrictionInputOnly,
            "\\_SB.GPI0", 0x00, ResourceConsumer, ,
            )
            {   // Pin list
                0x0194
            }
        GpioInt (Edge, ActiveBoth, Shared, PullUp, 0x0064,
            "\\_SB.GPI0", 0x00, ResourceConsumer, ,
            )
            {   // Pin list
                0x0194
            }
    })
    Scope (\_SB.PC00.SPI0)
    {
        Device (SPKR)
        {
            Name (_HID, "CSC3551")  // _HID: Hardware ID
            Method (_SUB, 0, NotSerialized)  // _SUB: Subsystem ID
            {
                If ((BMID == One))
                {
                    Return ("10280CC3")
                }
                ElseIf ((BMID == 0x02))
                {
                    Return ("10280CC2")
                }
                ElseIf ((BMID == 0x03))
                {
                    Return ("10280CC1")
                }
                Else
                {
                    Return ("10280CC4")
                }
            }

            Name (_UID, One)  // _UID: Unique ID
            Method (_CRS, 0, NotSerialized)  // _CRS: Current Resource Settings
            {
                Name (SBUF, ResourceTemplate ()
                {
                    SpiSerialBusV2 (0x0000, PolarityLow, FourWireMode, 0x08,
                        ControllerInitiated, 0x003D0900, ClockPolarityLow,
                        ClockPhaseFirst, "\\_SB.PC00.SPI0",
                        0x00, ResourceConsumer, , Exclusive,
                        )
                    SpiSerialBusV2 (0x0001, PolarityLow, FourWireMode, 0x08,
                        ControllerInitiated, 0x003D0900, ClockPolarityLow,
                        ClockPhaseFirst, "\\_SB.PC00.SPI0",
                        0x00, ResourceConsumer, , Exclusive,
                        )
                    GpioIo (Exclusive, PullUp, 0x0000, 0x0000, IoRestrictionOutputOnly,
                        "\\_SB.GPI0", 0x00, ResourceConsumer, ,
                        )
                        {   // Pin list
                            0x00CD
                        }
                })
                If ((BMID == 0x07))
                {
                    Return (ConcatenateResTemplate (SBUF, GPIB))
                }
                Else
                {
                    Return (ConcatenateResTemplate (SBUF, GPIA))
                }
            }

            Method (_STA, 0, NotSerialized)  // _STA: Status
            {
                Return (0x0F)
            }

            Method (_DSM, 4, Serialized)  // _DSM: Device-Specific Method
            {
                If ((Arg0 == ToUUID ("50d90cdc-3de4-4f18-b528-c7fe3b71f40d") /* Unknown UUID */))
                {
                    If ((ToInteger (Arg1) >= Zero))
                    {
                        Switch (ToInteger (Arg2))
                        {
                            Case (Zero)
                            {
                                Return (Buffer (One)
                                {
                                     0x21                                             // !
                                })
                            }
                            Case (0x05)
                            {
                                If ((SMSW == Zero))
                                {
                                    Return (Buffer (One)
                                    {
                                         0x01                                             // .
                                    })
                                }
                                Else
                                {
                                    Return (Buffer (One)
                                    {
                                         0x00                                             // .
                                    })
                                }
                            }

                        }
                    }
                }

                Return (Buffer (One)
                {
                     0x00                                             // .
                })
            }

            Name (_DSD, Package (0x02)  // _DSD: Device-Specific Data
            {
                ToUUID ("daffd814-6eba-4d8c-8a91-bc9bbf4aa301") /* Device Properties for _DSD */, 
                Package (0x07)
                {
                    Package (0x02)
                    {
                        "cirrus,dev-index", 
                        Package (0x02)
                        {
                            Zero, 
                            One
                        }
                    }, 

                    Package (0x02)
                    {
                        "reset-gpios", 
                        Package (0x08)
                        {
                            SPKR, 
                            One, 
                            Zero, 
                            Zero, 
                            SPKR, 
                            One, 
                            Zero, 
                            Zero
                        }
                    }, 

                    Package (0x02)
                    {
                        "spk-id-gpios", 
                        Package (0x08)
                        {
                            SPKR, 
                            0x02, 
                            Zero, 
                            Zero, 
                            SPKR, 
                            0x02, 
                            Zero, 
                            Zero
                        }
                    }, 

                    Package (0x02)
                    {
                        "cirrus,speaker-position", 
                        Package (0x02)
                        {
                            One, 
                            Zero
                        }
                    }, 

                    Package (0x02)
                    {
                        "cirrus,boost-type", 
                        Package (0x02)
                        {
                            One, 
                            One
                        }
                    }, 

                    Package (0x02)
                    {
                        "cirrus,gpio1-func", 
                        Package (0x02)
                        {
                            One, 
                            Zero
                        }
                    }, 

                    Package (0x02)
                    {
                        "cirrus,gpio2-func", 
                        Package (0x02)
                        {
                            0x02, 
                            0x02
                        }
                    }
                }
            })
        }

        Name (_DSD, Package (0x02)  // _DSD: Device-Specific Data
        {
            ToUUID ("daffd814-6eba-4d8c-8a91-bc9bbf4aa301") /* Device Properties for _DSD */, 
            Package (0x01)
            {
                Package (0x02)
                {
                    "cs-gpios", 
                    Package (0x05)
                    {
                        Zero, 
                        SPKR, 
                        Zero, 
                        Zero, 
                        Zero
                    }
                }
            }
        })
    }
}

