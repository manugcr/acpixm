/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20230628 (64-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembly of /home/eclypsium/Downloads/output/nhlt.dat, Tue Jul 29 10:46:19 2025
 *
 * ACPI Data Table [NHLT]
 *
 * Format: [HexOffset DecimalOffset ByteLength]  FieldName : FieldValue (in hex)
 */

[000h 0000 004h]                   Signature : "NHLT"    [Non HD Audio Link Table]
[004h 0004 004h]                Table Length : 00000F4E
[008h 0008 001h]                    Revision : 00
[009h 0009 001h]                    Checksum : F6
[00Ah 0010 006h]                      Oem ID : "DELL  "
[010h 0016 008h]                Oem Table ID : "Dell Inc"
[018h 0024 004h]                Oem Revision : 00000002
[01Ch 0028 004h]             Asl Compiler ID : "    "
[020h 0032 004h]       Asl Compiler Revision : 01000013

    /* Main table */
[024h 0036 001h]              Endpoint Count : 03

    /* Endpoint Descriptor #1 */
[025h 0037 004h]           Descriptor Length : 00000C5D
[029h 0041 001h]                   Link Type : 02 [Type PDM]
[02Ah 0042 001h]                 Instance Id : 00
[02Bh 0043 002h]                   Vendor Id : 8086
[02Dh 0045 002h]                   Device Id : AE20 [PDM DMIC]
[02Fh 0047 002h]                 Revision Id : 0001
[031h 0049 004h]                Subsystem Id : 00000001
[035h 0053 001h]                 Device Type : 00
[036h 0054 001h]                   Direction : 01 [Capture]
[037h 0055 001h]              Virtual Bus Id : 00

    /* Endpoint Device_Specific_Config table */
[038h 0056 004h]           Capabilities Size : 00000030
[03Ch 0060 001h]                Virtual Slot : 00
[03Dh 0061 001h]                 Config Type : 01 [Microphone Array]
[03Eh 0062 001h]                  Array Type : 0F [Vendor Defined]

    /* Vendor-defined microphone count */
[03Fh 0063 001h]            Microphone Count : 02

    /* Vendor-defined microphone array #1*/
[040h 0064 001h]                        Type : 01 [Subcardioid]
[041h 0065 001h]                       Panel : 04 [Front]
[042h 0066 002h]   Speaker Position Distance : 0000
[044h 0068 002h]           Horizontal Offset : FFE7
[046h 0070 002h]             Vertical Offset : 0000
[048h 0072 001h]          Frequency Low Band : 14
[049h 0073 001h]         Frequency High Band : 28
[04Ah 0074 002h]             Direction Angle : 0000
[04Ch 0076 002h]             Elevation Angle : 0000
[04Eh 0078 002h]   Work Vertical Angle Begin : 003C
[050h 0080 002h]     Work Vertical Angle End : FFC4
[052h 0082 002h] Work Horizontal Angle Begin : 0032
[054h 0084 002h]   Work Horizontal Angle End : FFCE

    /* Vendor-defined microphone array #2*/
[056h 0086 001h]                        Type : 01 [Subcardioid]
[057h 0087 001h]                       Panel : 04 [Front]
[058h 0088 002h]   Speaker Position Distance : 0000
[05Ah 0090 002h]           Horizontal Offset : 0019
[05Ch 0092 002h]             Vertical Offset : 0000
[05Eh 0094 001h]          Frequency Low Band : 14
[05Fh 0095 001h]         Frequency High Band : 28
[060h 0096 002h]             Direction Angle : 0000
[062h 0098 002h]             Elevation Angle : 0000
[064h 0100 002h]   Work Vertical Angle Begin : 003C
[066h 0102 002h]     Work Vertical Angle End : FFC4
[068h 0104 002h] Work Horizontal Angle Begin : 0032
[06Ah 0106 002h]   Work Horizontal Angle End : FFCE

    /* Formats_Config table */
[06Ch 0108 001h]               Formats Count : 01

    /* Wave_Format_Extensible table #1 */
[06Dh 0109 002h]                  Format Tag : FFFE
[06Fh 0111 002h]               Channel Count : 0002
[071h 0113 004h]          Samples Per Second : 0000BB80
[075h 0117 004h]    Average Bytes Per Second : 0002EE00
[079h 0121 002h]             Block Alignment : 0004
[07Bh 0123 002h]             Bits Per Sample : 0010
[07Dh 0125 002h]           Extra Format Size : 0016
[07Fh 0127 002h]       Valid Bits Per Sample : 0010
[081h 0129 004h]                Channel Mask : 00000003
[085h 0133 010h]              SubFormat GUID : 00000001-0000-0010-8000-00AA00389B71
[095h 0149 004h]         Capabilities Length : 00000BE8

    /* Specific_Config table #1 */
[099h 0153 BE8h]                Capabilities : 01 00 00 00 10 FF FF FF 10 FF FF FF FF FF FF FF /* ................ */\
/* 0A9h 0169  16 */                            FF FF FF FF 03 00 00 00 03 00 00 00 03 00 30 00 /* ..............0. */\
/* 0B9h 0185  16 */                            03 00 30 00 03 00 00 00 01 C0 00 00 03 18 00 0B /* ..0............. */\
/* 0C9h 0201  16 */                            00 00 00 00 03 0E 00 00 00 00 00 00 00 00 00 00 /* ................ */\
/* 0D9h 0217  16 */                            00 00 00 00 00 00 00 00 91 00 00 00 76 00 01 00 /* ............v... */\
/* 0E9h 0233  16 */                            00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 /* ................ */\
/* 0F9h 0249  16 */                            00 00 00 00 00 00 00 00 91 00 00 00 E8 01 05 00 /* ................ */\
/* 109h 0265  16 */                            00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 /* ................ */\
/* 119h 0281  16 */                            00 00 00 00 00 00 00 00 49 00 00 40 81 01 40 40 /* ........I..@..@@ */\
/* 129h 0297  16 */                            6D 03 80 40 53 04 C0 40 78 02 00 41 19 FF 4F 41 /* m..@S..@x..A..OA */\
/* 139h 0313  16 */                            ED FD 8F 41 37 00 C0 41 45 02 00 42 8C 00 40 42 /* ...A7..AE..B..@B */\
/* 149h 0329  16 */                            9B FD 8F 42 9D FE CF 42 6C 02 00 43 67 02 40 43 /* ...B...Bl..Cg.@C */\
/* 159h 0345  16 */                            B1 FD 8F 43 25 FC CF 43 6F 01 00 44 21 05 40 44 /* ...C%..Co..D!.@D */\
/* 169h 0361  16 */                            F3 FF 8F 44 C4 F9 CF 44 F9 FD 0F 45 BF 06 40 45 /* ...D...D...E..@E */\
/* 179h 0377  16 */                            8E 04 80 45 73 F9 CF 45 96 F8 0F 46 72 05 40 46 /* ...Es..E...Fr.@F */\
/* 189h 0393  16 */                            69 0A 80 46 CF FC CF 46 D1 F2 0F 47 A4 FF 4F 47 /* i..F...F...G..OG */\
/* 199h 0409  16 */                            25 0F 80 47 FC 04 C0 47 13 F0 0F 48 93 F5 4F 48 /* %..G...G...H..OH */\
/* 1A9h 0425  16 */                            33 0F 80 48 68 10 C0 48 75 F3 0F 49 99 E9 4F 49 /* 3..Hh..Hu..I..OI */\
/* 1B9h 0441  16 */                            A2 07 80 49 90 1B C0 49 65 FF 0F 4A C2 E0 4F 4A /* ...I...Ie..J..OJ */\
/* 1C9h 0457  16 */                            99 F7 8F 4A 92 20 C0 4A C4 12 00 4B 03 E1 4F 4B /* ...J. .J...K..OK */\
/* 1D9h 0473  16 */                            2C E2 8F 4B F2 19 C0 4B A3 28 00 4C F5 EE 4F 4C /* ,..K...K.(.L..OL */\
/* 1E9h 0489  16 */                            29 CE 8F 4C 84 04 C0 4C 40 38 00 4D 2C 0B 40 4D /* )..L...L@8.M,.@M */\
/* 1F9h 0505  16 */                            5E C5 8F 4D E9 E2 CF 4D F5 37 00 4E F8 2F 40 4E /* ^..M...M.7.N./@N */\
/* 209h 0521  16 */                            92 D0 8F 4E E1 BD CF 4E DD 20 00 4F 18 52 40 4F /* ...N...N. .O.R@O */\
/* 219h 0537  16 */                            4F F4 8F 4F B2 A2 CF 4F 4D F0 0F 50 08 60 40 50 /* O..O...OM..P.`@P */\
/* 229h 0553  16 */                            78 2D 80 50 80 A5 CF 50 54 B3 0F 51 82 4A 40 51 /* x-.P...PT..Q.J@Q */\
/* 239h 0569  16 */                            A2 69 80 51 00 D0 CF 51 F5 7E 0F 52 5C 0B 40 52 /* .i.Q...Q.~.R\.@R */\
/* 249h 0585  16 */                            CF 8E 80 52 52 21 C0 52 DC 70 0F 53 96 AD 4F 53 /* ...RR!.R.p.S..OS */\
/* 259h 0601  16 */                            06 7F 80 53 C7 82 C0 53 0A A3 0F 54 8D 53 4F 54 /* ...S...S...T.SOT */\
/* 269h 0617  16 */                            C1 28 80 54 14 C8 C0 54 21 1B 00 55 23 32 4F 55 /* .(.T...T!..U#2OU */\
/* 279h 0633  16 */                            41 97 8F 55 F2 B6 C0 55 87 B6 00 56 02 81 4F 56 /* A..U...U...V..OV */\
/* 289h 0649  16 */                            43 08 8F 56 34 25 C0 56 19 1C 01 57 7E 50 40 57 /* C..V4%.V...W~P@W */\
/* 299h 0665  16 */                            24 EE 8E 57 FD 2C CF 57 1C C9 00 58 71 47 41 58 /* $..W.,.W...XqGAX */\
/* 2A9h 0681  16 */                            01 C6 8F 58 BA 79 CE 58 6B 6E 0F 59 BE 5E 41 59 /* ...X.y.Xkn.Y.^AY */\
/* 2B9h 0697  16 */                            00 70 81 59 76 5B CF 59 77 F7 0D 5A AC 51 4F 5A /* .p.Yv[.Yw..Z.QOZ */\
/* 2C9h 0713  16 */                            09 CF 81 5A 53 36 C2 5A 37 CE 0F 5B A8 3D 4D 5B /* ...ZS6.Z7..[.=M[ */\
/* 2D9h 0729  16 */                            B8 65 8D 5B EF 50 C0 5B 37 8E 03 5C B2 E2 44 5C /* .e.[.P.[7..\..D\ */\
/* 2E9h 0745  16 */                            A5 11 84 5C A3 59 C2 5C 48 F2 00 5D 0E 3F 40 5D /* ...\.Y.\H..].?@] */\
/* 2F9h 0761  16 */                            39 08 80 5D 1B 00 00 80 18 00 40 80 0A 00 80 80 /* 9..]......@..... */\
/* 309h 0777  16 */                            D7 FF CF 80 67 FF 0F 81 A2 FE 4F 81 76 FD 8F 81 /* ....g.....O.v... */\
/* 319h 0793  16 */                            DD FB CF 81 E2 F9 0F 82 A8 F7 4F 82 67 F5 8F 82 /* ..........O.g... */\
/* 329h 0809  16 */                            6C F3 CF 82 0B F2 0F 83 97 F1 4F 83 4A F2 8F 83 /* l.........O.J... */\
/* 339h 0825  16 */                            3B F4 CF 83 51 F7 0F 84 3F FB 4F 84 88 FF 8F 84 /* ;...Q...?.O..... */\
/* 349h 0841  16 */                            92 03 C0 84 C0 06 00 85 8B 08 40 85 A2 08 80 85 /* ..........@..... */\
/* 359h 0857  16 */                            FD 06 C0 85 E9 03 00 86 FC FF 4F 86 FF FB 8F 86 /* ..........O..... */\
/* 369h 0873  16 */                            C8 F8 CF 86 0F F7 0F 87 45 F7 4F 87 75 F9 8F 87 /* ........E.O.u... */\
/* 379h 0889  16 */                            3D FD CF 87 DA 01 00 88 4C 06 40 88 8F 09 80 88 /* =.......L.@..... */\
/* 389h 0905  16 */                            D0 0A C0 88 A4 09 00 89 27 06 40 89 FF 00 80 89 /* ........'.@..... */\
/* 399h 0921  16 */                            43 FB CF 89 3C F6 0F 8A 26 F3 4F 8A DD F2 8F 8A /* C...<...&.O..... */\
/* 3A9h 0937  16 */                            A5 F5 CF 8A 11 FB 0F 8B 0C 02 40 8B 0E 09 80 8B /* ..........@..... */\
/* 3B9h 0953  16 */                            72 0E C0 8B D3 10 00 8C 69 0F 40 8C 42 0A 80 8C /* r.......i.@.B... */\
/* 3C9h 0969  16 */                            4F 02 C0 8C 3E F9 0F 8D 20 F1 4F 8D F1 EB 8F 8D /* O...>... .O..... */\
/* 3D9h 0985  16 */                            25 EB CF 8D 3D EF 0F 8E 9D F7 4F 8E 96 02 80 8E /* %...=.....O..... */\
/* 3E9h 1001  16 */                            BD 0D C0 8E 6D 16 00 8F 67 1A 40 8F 5F 18 80 8F /* ....m...g.@._... */\
/* 3F9h 1017  16 */                            61 10 C0 8F E4 03 00 90 8F F5 4F 90 AB E8 8F 90 /* a.........O..... */\
/* 409h 1033  16 */                            66 E0 CF 90 12 DF 0F 91 83 E5 4F 91 C3 F2 8F 91 /* f.........O..... */\
/* 419h 1049  16 */                            27 04 C0 91 D6 15 00 92 99 23 40 92 D9 29 80 92 /* '........#@..).. */\
/* 429h 1065  16 */                            84 26 C0 92 AA 19 00 93 A6 05 40 93 B6 EE 8F 93 /* .&........@..... */\
/* 439h 1081  16 */                            21 DA CF 93 09 CD 0F 94 2C CB 4F 94 E8 D5 8F 94 /* !.......,.O..... */\
/* 449h 1097  16 */                            B1 EB CF 94 38 08 00 95 31 25 40 95 AF 3B 80 95 /* ....8...1%@..;.. */\
/* 459h 1113  16 */                            B6 45 C0 95 C0 3F 00 96 C6 29 40 96 99 07 80 96 /* .E...?...)@..... */\
/* 469h 1129  16 */                            4C E0 CF 96 DB BC 0F 97 3A A6 4F 97 39 A3 8F 97 /* L.......:.O.9... */\
/* 479h 1145  16 */                            AF B6 CF 97 6D DE 0F 98 33 13 40 98 D5 49 80 98 /* ....m...3.@..I.. */\
/* 489h 1161  16 */                            5A 75 C0 98 C4 89 00 99 ED 7E 40 99 D5 52 80 99 /* Zu.......~@..R.. */\
/* 499h 1177  16 */                            E7 0A C0 99 CC B3 0F 9A B8 5F 4F 9A 67 23 8F 9A /* ........._O.g#.. */\
/* 4A9h 1193  16 */                            59 12 CF 9A EA 3A 0F 9B 13 A3 4F 9B 87 46 80 9B /* Y....:....O..F.. */\
/* 4B9h 1209  16 */                            8B 16 C1 9B BC FB 01 9C 6F D9 42 9C 33 92 83 9C /* ........o.B.3... */\
/* 4C9h 1225  16 */                            98 0C C4 9C 6B 37 04 9D 98 0C 44 9D 33 92 83 9D /* ....k7....D.3... */\
/* 4D9h 1241  16 */                            6F D9 C2 9D BC FB 01 9E 8B 16 41 9E 87 46 80 9E /* o.........A..F.. */\
/* 4E9h 1257  16 */                            13 A3 CF 9E EA 3A 0F 9F 59 12 4F 9F 67 23 8F 9F /* .....:..Y.O.g#.. */\
/* 4F9h 1273  16 */                            B8 5F CF 9F CC B3 0F A0 E7 0A 40 A0 D5 52 80 A0 /* ._........@..R.. */\
/* 509h 1289  16 */                            ED 7E C0 A0 C4 89 00 A1 5A 75 40 A1 D5 49 80 A1 /* .~......Zu@..I.. */\
/* 519h 1305  16 */                            33 13 C0 A1 6D DE 0F A2 AF B6 4F A2 39 A3 8F A2 /* 3...m.....O.9... */\
/* 529h 1321  16 */                            3A A6 CF A2 DB BC 0F A3 4C E0 4F A3 99 07 80 A3 /* :.......L.O..... */\
/* 539h 1337  16 */                            C6 29 C0 A3 C0 3F 00 A4 B6 45 40 A4 AF 3B 80 A4 /* .)...?...E@..;.. */\
/* 549h 1353  16 */                            31 25 C0 A4 38 08 00 A5 B1 EB 4F A5 E8 D5 8F A5 /* 1%..8.....O..... */\
/* 559h 1369  16 */                            2C CB CF A5 09 CD 0F A6 21 DA 4F A6 B6 EE 8F A6 /* ,.......!.O..... */\
/* 569h 1385  16 */                            A6 05 C0 A6 AA 19 00 A7 84 26 40 A7 D9 29 80 A7 /* .........&@..).. */\
/* 579h 1401  16 */                            99 23 C0 A7 D6 15 00 A8 27 04 40 A8 C3 F2 8F A8 /* .#......'.@..... */\
/* 589h 1417  16 */                            83 E5 CF A8 12 DF 0F A9 66 E0 4F A9 AB E8 8F A9 /* ........f.O..... */\
/* 599h 1433  16 */                            8F F5 CF A9 E4 03 00 AA 61 10 40 AA 5F 18 80 AA /* ........a.@._... */\
/* 5A9h 1449  16 */                            67 1A C0 AA 6D 16 00 AB BD 0D 40 AB 96 02 80 AB /* g...m.....@..... */\
/* 5B9h 1465  16 */                            9D F7 CF AB 3D EF 0F AC 25 EB 4F AC F1 EB 8F AC /* ....=...%.O..... */\
/* 5C9h 1481  16 */                            20 F1 CF AC 3E F9 0F AD 4F 02 40 AD 42 0A 80 AD /*  ...>...O.@.B... */\
/* 5D9h 1497  16 */                            69 0F C0 AD D3 10 00 AE 72 0E 40 AE 0E 09 80 AE /* i.......r.@..... */\
/* 5E9h 1513  16 */                            0C 02 C0 AE 11 FB 0F AF A5 F5 4F AF DD F2 8F AF /* ..........O..... */\
/* 5F9h 1529  16 */                            26 F3 CF AF 3C F6 0F B0 43 FB 4F B0 FF 00 80 B0 /* &...<...C.O..... */\
/* 609h 1545  16 */                            27 06 C0 B0 A4 09 00 B1 D0 0A 40 B1 8F 09 80 B1 /* '.........@..... */\
/* 619h 1561  16 */                            4C 06 C0 B1 DA 01 00 B2 3D FD 4F B2 75 F9 8F B2 /* L.......=.O.u... */\
/* 629h 1577  16 */                            45 F7 CF B2 0F F7 0F B3 C8 F8 4F B3 FF FB 8F B3 /* E.........O..... */\
/* 639h 1593  16 */                            FC FF CF B3 E9 03 00 B4 FD 06 40 B4 A2 08 80 B4 /* ..........@..... */\
/* 649h 1609  16 */                            8B 08 C0 B4 C0 06 00 B5 92 03 40 B5 88 FF 8F B5 /* ..........@..... */\
/* 659h 1625  16 */                            3F FB CF B5 51 F7 0F B6 3B F4 4F B6 4A F2 8F B6 /* ?...Q...;.O.J... */\
/* 669h 1641  16 */                            97 F1 CF B6 0B F2 0F B7 6C F3 4F B7 67 F5 8F B7 /* ........l.O.g... */\
/* 679h 1657  16 */                            A8 F7 CF B7 E2 F9 0F B8 DD FB 4F B8 76 FD 8F B8 /* ..........O.v... */\
/* 689h 1673  16 */                            A2 FE CF B8 67 FF 0F B9 D7 FF 4F B9 0A 00 80 B9 /* ....g.....O..... */\
/* 699h 1689  16 */                            18 00 C0 B9 1B 00 00 BA 01 C0 00 00 03 18 00 0B /* ................ */\
/* 6A9h 1705  16 */                            00 00 00 00 03 0E 00 00 00 00 00 00 00 00 00 00 /* ................ */\
/* 6B9h 1721  16 */                            00 00 00 00 00 00 00 00 91 00 00 00 76 00 01 00 /* ............v... */\
/* 6C9h 1737  16 */                            00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 /* ................ */\
/* 6D9h 1753  16 */                            00 00 00 00 00 00 00 00 91 00 00 00 E8 01 05 00 /* ................ */\
/* 6E9h 1769  16 */                            00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 /* ................ */\
/* 6F9h 1785  16 */                            00 00 00 00 00 00 00 00 49 00 00 40 81 01 40 40 /* ........I..@..@@ */\
/* 709h 1801  16 */                            6D 03 80 40 53 04 C0 40 78 02 00 41 19 FF 4F 41 /* m..@S..@x..A..OA */\
/* 719h 1817  16 */                            ED FD 8F 41 37 00 C0 41 45 02 00 42 8C 00 40 42 /* ...A7..AE..B..@B */\
/* 729h 1833  16 */                            9B FD 8F 42 9D FE CF 42 6C 02 00 43 67 02 40 43 /* ...B...Bl..Cg.@C */\
/* 739h 1849  16 */                            B1 FD 8F 43 25 FC CF 43 6F 01 00 44 21 05 40 44 /* ...C%..Co..D!.@D */\
/* 749h 1865  16 */                            F3 FF 8F 44 C4 F9 CF 44 F9 FD 0F 45 BF 06 40 45 /* ...D...D...E..@E */\
/* 759h 1881  16 */                            8E 04 80 45 73 F9 CF 45 96 F8 0F 46 72 05 40 46 /* ...Es..E...Fr.@F */\
/* 769h 1897  16 */                            69 0A 80 46 CF FC CF 46 D1 F2 0F 47 A4 FF 4F 47 /* i..F...F...G..OG */\
/* 779h 1913  16 */                            25 0F 80 47 FC 04 C0 47 13 F0 0F 48 93 F5 4F 48 /* %..G...G...H..OH */\
/* 789h 1929  16 */                            33 0F 80 48 68 10 C0 48 75 F3 0F 49 99 E9 4F 49 /* 3..Hh..Hu..I..OI */\
/* 799h 1945  16 */                            A2 07 80 49 90 1B C0 49 65 FF 0F 4A C2 E0 4F 4A /* ...I...Ie..J..OJ */\
/* 7A9h 1961  16 */                            99 F7 8F 4A 92 20 C0 4A C4 12 00 4B 03 E1 4F 4B /* ...J. .J...K..OK */\
/* 7B9h 1977  16 */                            2C E2 8F 4B F2 19 C0 4B A3 28 00 4C F5 EE 4F 4C /* ,..K...K.(.L..OL */\
/* 7C9h 1993  16 */                            29 CE 8F 4C 84 04 C0 4C 40 38 00 4D 2C 0B 40 4D /* )..L...L@8.M,.@M */\
/* 7D9h 2009  16 */                            5E C5 8F 4D E9 E2 CF 4D F5 37 00 4E F8 2F 40 4E /* ^..M...M.7.N./@N */\
/* 7E9h 2025  16 */                            92 D0 8F 4E E1 BD CF 4E DD 20 00 4F 18 52 40 4F /* ...N...N. .O.R@O */\
/* 7F9h 2041  16 */                            4F F4 8F 4F B2 A2 CF 4F 4D F0 0F 50 08 60 40 50 /* O..O...OM..P.`@P */\
/* 809h 2057  16 */                            78 2D 80 50 80 A5 CF 50 54 B3 0F 51 82 4A 40 51 /* x-.P...PT..Q.J@Q */\
/* 819h 2073  16 */                            A2 69 80 51 00 D0 CF 51 F5 7E 0F 52 5C 0B 40 52 /* .i.Q...Q.~.R\.@R */\
/* 829h 2089  16 */                            CF 8E 80 52 52 21 C0 52 DC 70 0F 53 96 AD 4F 53 /* ...RR!.R.p.S..OS */\
/* 839h 2105  16 */                            06 7F 80 53 C7 82 C0 53 0A A3 0F 54 8D 53 4F 54 /* ...S...S...T.SOT */\
/* 849h 2121  16 */                            C1 28 80 54 14 C8 C0 54 21 1B 00 55 23 32 4F 55 /* .(.T...T!..U#2OU */\
/* 859h 2137  16 */                            41 97 8F 55 F2 B6 C0 55 87 B6 00 56 02 81 4F 56 /* A..U...U...V..OV */\
/* 869h 2153  16 */                            43 08 8F 56 34 25 C0 56 19 1C 01 57 7E 50 40 57 /* C..V4%.V...W~P@W */\
/* 879h 2169  16 */                            24 EE 8E 57 FD 2C CF 57 1C C9 00 58 71 47 41 58 /* $..W.,.W...XqGAX */\
/* 889h 2185  16 */                            01 C6 8F 58 BA 79 CE 58 6B 6E 0F 59 BE 5E 41 59 /* ...X.y.Xkn.Y.^AY */\
/* 899h 2201  16 */                            00 70 81 59 76 5B CF 59 77 F7 0D 5A AC 51 4F 5A /* .p.Yv[.Yw..Z.QOZ */\
/* 8A9h 2217  16 */                            09 CF 81 5A 53 36 C2 5A 37 CE 0F 5B A8 3D 4D 5B /* ...ZS6.Z7..[.=M[ */\
/* 8B9h 2233  16 */                            B8 65 8D 5B EF 50 C0 5B 37 8E 03 5C B2 E2 44 5C /* .e.[.P.[7..\..D\ */\
/* 8C9h 2249  16 */                            A5 11 84 5C A3 59 C2 5C 48 F2 00 5D 0E 3F 40 5D /* ...\.Y.\H..].?@] */\
/* 8D9h 2265  16 */                            39 08 80 5D 1B 00 00 80 18 00 40 80 0A 00 80 80 /* 9..]......@..... */\
/* 8E9h 2281  16 */                            D7 FF CF 80 67 FF 0F 81 A2 FE 4F 81 76 FD 8F 81 /* ....g.....O.v... */\
/* 8F9h 2297  16 */                            DD FB CF 81 E2 F9 0F 82 A8 F7 4F 82 67 F5 8F 82 /* ..........O.g... */\
/* 909h 2313  16 */                            6C F3 CF 82 0B F2 0F 83 97 F1 4F 83 4A F2 8F 83 /* l.........O.J... */\
/* 919h 2329  16 */                            3B F4 CF 83 51 F7 0F 84 3F FB 4F 84 88 FF 8F 84 /* ;...Q...?.O..... */\
/* 929h 2345  16 */                            92 03 C0 84 C0 06 00 85 8B 08 40 85 A2 08 80 85 /* ..........@..... */\
/* 939h 2361  16 */                            FD 06 C0 85 E9 03 00 86 FC FF 4F 86 FF FB 8F 86 /* ..........O..... */\
/* 949h 2377  16 */                            C8 F8 CF 86 0F F7 0F 87 45 F7 4F 87 75 F9 8F 87 /* ........E.O.u... */\
/* 959h 2393  16 */                            3D FD CF 87 DA 01 00 88 4C 06 40 88 8F 09 80 88 /* =.......L.@..... */\
/* 969h 2409  16 */                            D0 0A C0 88 A4 09 00 89 27 06 40 89 FF 00 80 89 /* ........'.@..... */\
/* 979h 2425  16 */                            43 FB CF 89 3C F6 0F 8A 26 F3 4F 8A DD F2 8F 8A /* C...<...&.O..... */\
/* 989h 2441  16 */                            A5 F5 CF 8A 11 FB 0F 8B 0C 02 40 8B 0E 09 80 8B /* ..........@..... */\
/* 999h 2457  16 */                            72 0E C0 8B D3 10 00 8C 69 0F 40 8C 42 0A 80 8C /* r.......i.@.B... */\
/* 9A9h 2473  16 */                            4F 02 C0 8C 3E F9 0F 8D 20 F1 4F 8D F1 EB 8F 8D /* O...>... .O..... */\
/* 9B9h 2489  16 */                            25 EB CF 8D 3D EF 0F 8E 9D F7 4F 8E 96 02 80 8E /* %...=.....O..... */\
/* 9C9h 2505  16 */                            BD 0D C0 8E 6D 16 00 8F 67 1A 40 8F 5F 18 80 8F /* ....m...g.@._... */\
/* 9D9h 2521  16 */                            61 10 C0 8F E4 03 00 90 8F F5 4F 90 AB E8 8F 90 /* a.........O..... */\
/* 9E9h 2537  16 */                            66 E0 CF 90 12 DF 0F 91 83 E5 4F 91 C3 F2 8F 91 /* f.........O..... */\
/* 9F9h 2553  16 */                            27 04 C0 91 D6 15 00 92 99 23 40 92 D9 29 80 92 /* '........#@..).. */\
/* A09h 2569  16 */                            84 26 C0 92 AA 19 00 93 A6 05 40 93 B6 EE 8F 93 /* .&........@..... */\
/* A19h 2585  16 */                            21 DA CF 93 09 CD 0F 94 2C CB 4F 94 E8 D5 8F 94 /* !.......,.O..... */\
/* A29h 2601  16 */                            B1 EB CF 94 38 08 00 95 31 25 40 95 AF 3B 80 95 /* ....8...1%@..;.. */\
/* A39h 2617  16 */                            B6 45 C0 95 C0 3F 00 96 C6 29 40 96 99 07 80 96 /* .E...?...)@..... */\
/* A49h 2633  16 */                            4C E0 CF 96 DB BC 0F 97 3A A6 4F 97 39 A3 8F 97 /* L.......:.O.9... */\
/* A59h 2649  16 */                            AF B6 CF 97 6D DE 0F 98 33 13 40 98 D5 49 80 98 /* ....m...3.@..I.. */\
/* A69h 2665  16 */                            5A 75 C0 98 C4 89 00 99 ED 7E 40 99 D5 52 80 99 /* Zu.......~@..R.. */\
/* A79h 2681  16 */                            E7 0A C0 99 CC B3 0F 9A B8 5F 4F 9A 67 23 8F 9A /* ........._O.g#.. */\
/* A89h 2697  16 */                            59 12 CF 9A EA 3A 0F 9B 13 A3 4F 9B 87 46 80 9B /* Y....:....O..F.. */\
/* A99h 2713  16 */                            8B 16 C1 9B BC FB 01 9C 6F D9 42 9C 33 92 83 9C /* ........o.B.3... */\
/* AA9h 2729  16 */                            98 0C C4 9C 6B 37 04 9D 98 0C 44 9D 33 92 83 9D /* ....k7....D.3... */\
/* AB9h 2745  16 */                            6F D9 C2 9D BC FB 01 9E 8B 16 41 9E 87 46 80 9E /* o.........A..F.. */\
/* AC9h 2761  16 */                            13 A3 CF 9E EA 3A 0F 9F 59 12 4F 9F 67 23 8F 9F /* .....:..Y.O.g#.. */\
/* AD9h 2777  16 */                            B8 5F CF 9F CC B3 0F A0 E7 0A 40 A0 D5 52 80 A0 /* ._........@..R.. */\
/* AE9h 2793  16 */                            ED 7E C0 A0 C4 89 00 A1 5A 75 40 A1 D5 49 80 A1 /* .~......Zu@..I.. */\
/* AF9h 2809  16 */                            33 13 C0 A1 6D DE 0F A2 AF B6 4F A2 39 A3 8F A2 /* 3...m.....O.9... */\
/* B09h 2825  16 */                            3A A6 CF A2 DB BC 0F A3 4C E0 4F A3 99 07 80 A3 /* :.......L.O..... */\
/* B19h 2841  16 */                            C6 29 C0 A3 C0 3F 00 A4 B6 45 40 A4 AF 3B 80 A4 /* .)...?...E@..;.. */\
/* B29h 2857  16 */                            31 25 C0 A4 38 08 00 A5 B1 EB 4F A5 E8 D5 8F A5 /* 1%..8.....O..... */\
/* B39h 2873  16 */                            2C CB CF A5 09 CD 0F A6 21 DA 4F A6 B6 EE 8F A6 /* ,.......!.O..... */\
/* B49h 2889  16 */                            A6 05 C0 A6 AA 19 00 A7 84 26 40 A7 D9 29 80 A7 /* .........&@..).. */\
/* B59h 2905  16 */                            99 23 C0 A7 D6 15 00 A8 27 04 40 A8 C3 F2 8F A8 /* .#......'.@..... */\
/* B69h 2921  16 */                            83 E5 CF A8 12 DF 0F A9 66 E0 4F A9 AB E8 8F A9 /* ........f.O..... */\
/* B79h 2937  16 */                            8F F5 CF A9 E4 03 00 AA 61 10 40 AA 5F 18 80 AA /* ........a.@._... */\
/* B89h 2953  16 */                            67 1A C0 AA 6D 16 00 AB BD 0D 40 AB 96 02 80 AB /* g...m.....@..... */\
/* B99h 2969  16 */                            9D F7 CF AB 3D EF 0F AC 25 EB 4F AC F1 EB 8F AC /* ....=...%.O..... */\
/* BA9h 2985  16 */                            20 F1 CF AC 3E F9 0F AD 4F 02 40 AD 42 0A 80 AD /*  ...>...O.@.B... */\
/* BB9h 3001  16 */                            69 0F C0 AD D3 10 00 AE 72 0E 40 AE 0E 09 80 AE /* i.......r.@..... */\
/* BC9h 3017  16 */                            0C 02 C0 AE 11 FB 0F AF A5 F5 4F AF DD F2 8F AF /* ..........O..... */\
/* BD9h 3033  16 */                            26 F3 CF AF 3C F6 0F B0 43 FB 4F B0 FF 00 80 B0 /* &...<...C.O..... */\
/* BE9h 3049  16 */                            27 06 C0 B0 A4 09 00 B1 D0 0A 40 B1 8F 09 80 B1 /* '.........@..... */\
/* BF9h 3065  16 */                            4C 06 C0 B1 DA 01 00 B2 3D FD 4F B2 75 F9 8F B2 /* L.......=.O.u... */\
/* C09h 3081  16 */                            45 F7 CF B2 0F F7 0F B3 C8 F8 4F B3 FF FB 8F B3 /* E.........O..... */\
/* C19h 3097  16 */                            FC FF CF B3 E9 03 00 B4 FD 06 40 B4 A2 08 80 B4 /* ..........@..... */\
/* C29h 3113  16 */                            8B 08 C0 B4 C0 06 00 B5 92 03 40 B5 88 FF 8F B5 /* ..........@..... */\
/* C39h 3129  16 */                            3F FB CF B5 51 F7 0F B6 3B F4 4F B6 4A F2 8F B6 /* ?...Q...;.O.J... */\
/* C49h 3145  16 */                            97 F1 CF B6 0B F2 0F B7 6C F3 4F B7 67 F5 8F B7 /* ........l.O.g... */\
/* C59h 3161  16 */                            A8 F7 CF B7 E2 F9 0F B8 DD FB 4F B8 76 FD 8F B8 /* ..........O.v... */\
/* C69h 3177  16 */                            A2 FE CF B8 67 FF 0F B9 D7 FF 4F B9 0A 00 80 B9 /* ....g.....O..... */\
/* C79h 3193   8 */                            18 00 C0 B9 1B 00 00 BA                         /* ........ */\

    /* Structures that are not part of NHLT spec */
[C81h 3201 001h]    Device Info struct count : 00

    /* Endpoint Descriptor #2 */
[C82h 3202 004h]           Descriptor Length : 000001AA
[C86h 3206 001h]                   Link Type : 03 [Type SSP]
[C87h 3207 001h]                 Instance Id : 00
[C88h 3208 002h]                   Vendor Id : 8086
[C8Ah 3210 002h]                   Device Id : AE30 [BT Sideband]
[C8Ch 3212 002h]                 Revision Id : 0001
[C8Eh 3214 004h]                Subsystem Id : 00000001
[C92h 3218 001h]                 Device Type : 00
[C93h 3219 001h]                   Direction : 00 [Render]
[C94h 3220 001h]              Virtual Bus Id : 02

    /* Endpoint Device_Specific_Config table */
[C95h 3221 004h]           Capabilities Size : 00000001
[C99h 3225 001h]                Virtual Slot : 00

    /* Formats_Config table */
[C9Ah 3226 001h]               Formats Count : 03

    /* Wave_Format_Extensible table #1 */
[C9Bh 3227 002h]                  Format Tag : FFFE
[C9Dh 3229 002h]               Channel Count : 0001
[C9Fh 3231 004h]          Samples Per Second : 00001F40
[CA3h 3235 004h]    Average Bytes Per Second : 00003E80
[CA7h 3239 002h]             Block Alignment : 0002
[CA9h 3241 002h]             Bits Per Sample : 0010
[CABh 3243 002h]           Extra Format Size : 0016
[CADh 3245 002h]       Valid Bits Per Sample : 0010
[CAFh 3247 004h]                Channel Mask : 00000004
[CB3h 3251 010h]              SubFormat GUID : 00000001-0000-0010-8000-00AA00389B71
[CC3h 3267 004h]         Capabilities Length : 00000054

    /* Specific_Config table #1 */
[CC7h 3271 054h]                Capabilities : 00 00 00 00 F0 FF FF FF 00 00 00 00 00 00 00 00 /* ................ */\
/* CD7h 3287  16 */                            00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 /* ................ */\
/* CE7h 3303  16 */                            00 00 00 00 3F 00 C0 80 00 00 40 D3 00 00 00 00 /* ....?.....@..... */\
/* CF7h 3319  16 */                            05 00 00 02 01 00 00 00 01 00 00 00 02 40 00 00 /* .............@.. */\
/* D07h 3335  16 */                            00 00 00 00 00 00 02 07 00 00 00 00 01 00 00 00 /* ................ */\
/* D17h 3351   4 */                            00 00 00 00                                     /* .... */\

    /* Wave_Format_Extensible table #2 */
[D1Bh 3355 002h]                  Format Tag : FFFE
[D1Dh 3357 002h]               Channel Count : 0001
[D1Fh 3359 004h]          Samples Per Second : 00003E80
[D23h 3363 004h]    Average Bytes Per Second : 00007D00
[D27h 3367 002h]             Block Alignment : 0002
[D29h 3369 002h]             Bits Per Sample : 0010
[D2Bh 3371 002h]           Extra Format Size : 0016
[D2Dh 3373 002h]       Valid Bits Per Sample : 0010
[D2Fh 3375 004h]                Channel Mask : 00000004
[D33h 3379 010h]              SubFormat GUID : 00000001-0000-0010-8000-00AA00389B71
[D43h 3395 004h]         Capabilities Length : 00000054

    /* Specific_Config table #2 */
[D47h 3399 054h]                Capabilities : 00 00 00 00 F0 FF FF FF 00 00 00 00 00 00 00 00 /* ................ */\
/* D57h 3415  16 */                            00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 /* ................ */\
/* D67h 3431  16 */                            00 00 00 00 3F 00 C0 80 00 00 40 D3 00 00 00 00 /* ....?.....@..... */\
/* D77h 3447  16 */                            05 00 00 02 01 00 00 00 01 00 00 00 02 40 00 00 /* .............@.. */\
/* D87h 3463  16 */                            00 00 00 00 00 00 02 07 00 00 00 00 01 00 00 00 /* ................ */\
/* D97h 3479   4 */                            00 00 00 00                                     /* .... */\

    /* Wave_Format_Extensible table #3 */
[D9Bh 3483 002h]                  Format Tag : FFFE
[D9Dh 3485 002h]               Channel Count : 0002
[D9Fh 3487 004h]          Samples Per Second : 0000BB80
[DA3h 3491 004h]    Average Bytes Per Second : 0002EE00
[DA7h 3495 002h]             Block Alignment : 0004
[DA9h 3497 002h]             Bits Per Sample : 0010
[DABh 3499 002h]           Extra Format Size : 0016
[DADh 3501 002h]       Valid Bits Per Sample : 0010
[DAFh 3503 004h]                Channel Mask : 00000003
[DB3h 3507 010h]              SubFormat GUID : 00000001-0000-0010-8000-00AA00389B71
[DC3h 3523 004h]         Capabilities Length : 00000064

    /* Specific_Config table #3 */
[DC7h 3527 064h]                Capabilities : 00 00 00 00 10 FF FF FF FF FF FF FF FF FF FF FF /* ................ */\
/* DD7h 3543  16 */                            FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF /* ................ */\
/* DE7h 3559  16 */                            FF FF FF FF 7F 18 C0 C1 00 00 70 C0 00 00 00 00 /* ..........p..... */\
/* DF7h 3575  16 */                            05 02 01 02 03 00 00 00 03 00 00 00 02 40 00 00 /* .............@.. */\
/* E07h 3591  16 */                            00 00 00 00 00 0F 07 07 20 00 00 00 01 00 00 00 /* ........ ....... */\
/* E17h 3607  16 */                            FF 0F 00 00 00 00 00 00 08 00 00 00 01 00 00 00 /* ................ */\
/* E27h 3623   4 */                            01 00 00 00                                     /* .... */\

    /* Structures that are not part of NHLT spec */
[E2Bh 3627 001h]    Device Info struct count : 00

    /* Endpoint Descriptor #3 */
[E2Ch 3628 004h]           Descriptor Length : 0000011A
[E30h 3632 001h]                   Link Type : 03 [Type SSP]
[E31h 3633 001h]                 Instance Id : 00
[E32h 3634 002h]                   Vendor Id : 8086
[E34h 3636 002h]                   Device Id : AE30 [BT Sideband]
[E36h 3638 002h]                 Revision Id : 0001
[E38h 3640 004h]                Subsystem Id : 00000001
[E3Ch 3644 001h]                 Device Type : 00
[E3Dh 3645 001h]                   Direction : 01 [Capture]
[E3Eh 3646 001h]              Virtual Bus Id : 02

    /* Endpoint Device_Specific_Config table */
[E3Fh 3647 004h]           Capabilities Size : 00000001
[E43h 3651 001h]                Virtual Slot : 00

    /* Formats_Config table */
[E44h 3652 001h]               Formats Count : 02

    /* Wave_Format_Extensible table #1 */
[E45h 3653 002h]                  Format Tag : FFFE
[E47h 3655 002h]               Channel Count : 0001
[E49h 3657 004h]          Samples Per Second : 00001F40
[E4Dh 3661 004h]    Average Bytes Per Second : 00003E80
[E51h 3665 002h]             Block Alignment : 0002
[E53h 3667 002h]             Bits Per Sample : 0010
[E55h 3669 002h]           Extra Format Size : 0016
[E57h 3671 002h]       Valid Bits Per Sample : 0010
[E59h 3673 004h]                Channel Mask : 00000004
[E5Dh 3677 010h]              SubFormat GUID : 00000001-0000-0010-8000-00AA00389B71
[E6Dh 3693 004h]         Capabilities Length : 00000054

    /* Specific_Config table #1 */
[E71h 3697 054h]                Capabilities : 00 00 00 00 F0 FF FF FF 00 00 00 00 00 00 00 00 /* ................ */\
/* E81h 3713  16 */                            00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 /* ................ */\
/* E91h 3729  16 */                            00 00 00 00 3F 00 C0 80 00 00 40 D3 00 00 00 00 /* ....?.....@..... */\
/* EA1h 3745  16 */                            05 00 00 02 01 00 00 00 01 00 00 00 02 40 00 00 /* .............@.. */\
/* EB1h 3761  16 */                            00 00 00 00 00 00 02 07 00 00 00 00 01 00 00 00 /* ................ */\
/* EC1h 3777   4 */                            00 00 00 00                                     /* .... */\

    /* Wave_Format_Extensible table #2 */
[EC5h 3781 002h]                  Format Tag : FFFE
[EC7h 3783 002h]               Channel Count : 0001
[EC9h 3785 004h]          Samples Per Second : 00003E80
[ECDh 3789 004h]    Average Bytes Per Second : 00007D00
[ED1h 3793 002h]             Block Alignment : 0002
[ED3h 3795 002h]             Bits Per Sample : 0010
[ED5h 3797 002h]           Extra Format Size : 0016
[ED7h 3799 002h]       Valid Bits Per Sample : 0010
[ED9h 3801 004h]                Channel Mask : 00000004
[EDDh 3805 010h]              SubFormat GUID : 00000001-0000-0010-8000-00AA00389B71
[EEDh 3821 004h]         Capabilities Length : 00000054

    /* Specific_Config table #2 */
[EF1h 3825 054h]                Capabilities : 00 00 00 00 F0 FF FF FF 00 00 00 00 00 00 00 00 /* ................ */\
/* F01h 3841  16 */                            00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 /* ................ */\
/* F11h 3857  16 */                            00 00 00 00 3F 00 C0 80 00 00 40 D3 00 00 00 00 /* ....?.....@..... */\
/* F21h 3873  16 */                            05 00 00 02 01 00 00 00 01 00 00 00 02 40 00 00 /* .............@.. */\
/* F31h 3889  16 */                            00 00 00 00 00 00 02 07 00 00 00 00 01 00 00 00 /* ................ */\
/* F41h 3905   4 */                            00 00 00 00                                     /* .... */\

    /* Structures that are not part of NHLT spec */
[F45h 3909 001h]    Device Info struct count : 00

/* Terminating specific config (not part of NHLT spec) */
[F46h 3910 004h]           Capabilities Size : 00000004
[F4Ah 3914 004h]                Capabilities : DE AD BE EF                                     /* .... */\

Raw Table Data: Length 3918 (0xF4E)

    0000: 4E 48 4C 54 4E 0F 00 00 00 F6 44 45 4C 4C 20 20  // NHLTN.....DELL  
    0010: 44 65 6C 6C 20 49 6E 63 02 00 00 00 20 20 20 20  // Dell Inc....    
    0020: 13 00 00 01 03 5D 0C 00 00 02 00 86 80 20 AE 01  // .....]....... ..
    0030: 00 01 00 00 00 00 01 00 30 00 00 00 00 01 0F 02  // ........0.......
    0040: 01 04 00 00 E7 FF 00 00 14 28 00 00 00 00 3C 00  // .........(....<.
    0050: C4 FF 32 00 CE FF 01 04 00 00 19 00 00 00 14 28  // ..2............(
    0060: 00 00 00 00 3C 00 C4 FF 32 00 CE FF 01 FE FF 02  // ....<...2.......
    0070: 00 80 BB 00 00 00 EE 02 00 04 00 10 00 16 00 10  // ................
    0080: 00 03 00 00 00 01 00 00 00 00 00 10 00 80 00 00  // ................
    0090: AA 00 38 9B 71 E8 0B 00 00 01 00 00 00 10 FF FF  // ..8.q...........
    00A0: FF 10 FF FF FF FF FF FF FF FF FF FF FF 03 00 00  // ................
    00B0: 00 03 00 00 00 03 00 30 00 03 00 30 00 03 00 00  // .......0...0....
    00C0: 00 01 C0 00 00 03 18 00 0B 00 00 00 00 03 0E 00  // ................
    00D0: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    00E0: 00 91 00 00 00 76 00 01 00 00 00 00 00 00 00 00  // .....v..........
    00F0: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0100: 00 91 00 00 00 E8 01 05 00 00 00 00 00 00 00 00  // ................
    0110: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0120: 00 49 00 00 40 81 01 40 40 6D 03 80 40 53 04 C0  // .I..@..@@m..@S..
    0130: 40 78 02 00 41 19 FF 4F 41 ED FD 8F 41 37 00 C0  // @x..A..OA...A7..
    0140: 41 45 02 00 42 8C 00 40 42 9B FD 8F 42 9D FE CF  // AE..B..@B...B...
    0150: 42 6C 02 00 43 67 02 40 43 B1 FD 8F 43 25 FC CF  // Bl..Cg.@C...C%..
    0160: 43 6F 01 00 44 21 05 40 44 F3 FF 8F 44 C4 F9 CF  // Co..D!.@D...D...
    0170: 44 F9 FD 0F 45 BF 06 40 45 8E 04 80 45 73 F9 CF  // D...E..@E...Es..
    0180: 45 96 F8 0F 46 72 05 40 46 69 0A 80 46 CF FC CF  // E...Fr.@Fi..F...
    0190: 46 D1 F2 0F 47 A4 FF 4F 47 25 0F 80 47 FC 04 C0  // F...G..OG%..G...
    01A0: 47 13 F0 0F 48 93 F5 4F 48 33 0F 80 48 68 10 C0  // G...H..OH3..Hh..
    01B0: 48 75 F3 0F 49 99 E9 4F 49 A2 07 80 49 90 1B C0  // Hu..I..OI...I...
    01C0: 49 65 FF 0F 4A C2 E0 4F 4A 99 F7 8F 4A 92 20 C0  // Ie..J..OJ...J. .
    01D0: 4A C4 12 00 4B 03 E1 4F 4B 2C E2 8F 4B F2 19 C0  // J...K..OK,..K...
    01E0: 4B A3 28 00 4C F5 EE 4F 4C 29 CE 8F 4C 84 04 C0  // K.(.L..OL)..L...
    01F0: 4C 40 38 00 4D 2C 0B 40 4D 5E C5 8F 4D E9 E2 CF  // L@8.M,.@M^..M...
    0200: 4D F5 37 00 4E F8 2F 40 4E 92 D0 8F 4E E1 BD CF  // M.7.N./@N...N...
    0210: 4E DD 20 00 4F 18 52 40 4F 4F F4 8F 4F B2 A2 CF  // N. .O.R@OO..O...
    0220: 4F 4D F0 0F 50 08 60 40 50 78 2D 80 50 80 A5 CF  // OM..P.`@Px-.P...
    0230: 50 54 B3 0F 51 82 4A 40 51 A2 69 80 51 00 D0 CF  // PT..Q.J@Q.i.Q...
    0240: 51 F5 7E 0F 52 5C 0B 40 52 CF 8E 80 52 52 21 C0  // Q.~.R\.@R...RR!.
    0250: 52 DC 70 0F 53 96 AD 4F 53 06 7F 80 53 C7 82 C0  // R.p.S..OS...S...
    0260: 53 0A A3 0F 54 8D 53 4F 54 C1 28 80 54 14 C8 C0  // S...T.SOT.(.T...
    0270: 54 21 1B 00 55 23 32 4F 55 41 97 8F 55 F2 B6 C0  // T!..U#2OUA..U...
    0280: 55 87 B6 00 56 02 81 4F 56 43 08 8F 56 34 25 C0  // U...V..OVC..V4%.
    0290: 56 19 1C 01 57 7E 50 40 57 24 EE 8E 57 FD 2C CF  // V...W~P@W$..W.,.
    02A0: 57 1C C9 00 58 71 47 41 58 01 C6 8F 58 BA 79 CE  // W...XqGAX...X.y.
    02B0: 58 6B 6E 0F 59 BE 5E 41 59 00 70 81 59 76 5B CF  // Xkn.Y.^AY.p.Yv[.
    02C0: 59 77 F7 0D 5A AC 51 4F 5A 09 CF 81 5A 53 36 C2  // Yw..Z.QOZ...ZS6.
    02D0: 5A 37 CE 0F 5B A8 3D 4D 5B B8 65 8D 5B EF 50 C0  // Z7..[.=M[.e.[.P.
    02E0: 5B 37 8E 03 5C B2 E2 44 5C A5 11 84 5C A3 59 C2  // [7..\..D\...\.Y.
    02F0: 5C 48 F2 00 5D 0E 3F 40 5D 39 08 80 5D 1B 00 00  // \H..].?@]9..]...
    0300: 80 18 00 40 80 0A 00 80 80 D7 FF CF 80 67 FF 0F  // ...@.........g..
    0310: 81 A2 FE 4F 81 76 FD 8F 81 DD FB CF 81 E2 F9 0F  // ...O.v..........
    0320: 82 A8 F7 4F 82 67 F5 8F 82 6C F3 CF 82 0B F2 0F  // ...O.g...l......
    0330: 83 97 F1 4F 83 4A F2 8F 83 3B F4 CF 83 51 F7 0F  // ...O.J...;...Q..
    0340: 84 3F FB 4F 84 88 FF 8F 84 92 03 C0 84 C0 06 00  // .?.O............
    0350: 85 8B 08 40 85 A2 08 80 85 FD 06 C0 85 E9 03 00  // ...@............
    0360: 86 FC FF 4F 86 FF FB 8F 86 C8 F8 CF 86 0F F7 0F  // ...O............
    0370: 87 45 F7 4F 87 75 F9 8F 87 3D FD CF 87 DA 01 00  // .E.O.u...=......
    0380: 88 4C 06 40 88 8F 09 80 88 D0 0A C0 88 A4 09 00  // .L.@............
    0390: 89 27 06 40 89 FF 00 80 89 43 FB CF 89 3C F6 0F  // .'.@.....C...<..
    03A0: 8A 26 F3 4F 8A DD F2 8F 8A A5 F5 CF 8A 11 FB 0F  // .&.O............
    03B0: 8B 0C 02 40 8B 0E 09 80 8B 72 0E C0 8B D3 10 00  // ...@.....r......
    03C0: 8C 69 0F 40 8C 42 0A 80 8C 4F 02 C0 8C 3E F9 0F  // .i.@.B...O...>..
    03D0: 8D 20 F1 4F 8D F1 EB 8F 8D 25 EB CF 8D 3D EF 0F  // . .O.....%...=..
    03E0: 8E 9D F7 4F 8E 96 02 80 8E BD 0D C0 8E 6D 16 00  // ...O.........m..
    03F0: 8F 67 1A 40 8F 5F 18 80 8F 61 10 C0 8F E4 03 00  // .g.@._...a......
    0400: 90 8F F5 4F 90 AB E8 8F 90 66 E0 CF 90 12 DF 0F  // ...O.....f......
    0410: 91 83 E5 4F 91 C3 F2 8F 91 27 04 C0 91 D6 15 00  // ...O.....'......
    0420: 92 99 23 40 92 D9 29 80 92 84 26 C0 92 AA 19 00  // ..#@..)...&.....
    0430: 93 A6 05 40 93 B6 EE 8F 93 21 DA CF 93 09 CD 0F  // ...@.....!......
    0440: 94 2C CB 4F 94 E8 D5 8F 94 B1 EB CF 94 38 08 00  // .,.O.........8..
    0450: 95 31 25 40 95 AF 3B 80 95 B6 45 C0 95 C0 3F 00  // .1%@..;...E...?.
    0460: 96 C6 29 40 96 99 07 80 96 4C E0 CF 96 DB BC 0F  // ..)@.....L......
    0470: 97 3A A6 4F 97 39 A3 8F 97 AF B6 CF 97 6D DE 0F  // .:.O.9.......m..
    0480: 98 33 13 40 98 D5 49 80 98 5A 75 C0 98 C4 89 00  // .3.@..I..Zu.....
    0490: 99 ED 7E 40 99 D5 52 80 99 E7 0A C0 99 CC B3 0F  // ..~@..R.........
    04A0: 9A B8 5F 4F 9A 67 23 8F 9A 59 12 CF 9A EA 3A 0F  // .._O.g#..Y....:.
    04B0: 9B 13 A3 4F 9B 87 46 80 9B 8B 16 C1 9B BC FB 01  // ...O..F.........
    04C0: 9C 6F D9 42 9C 33 92 83 9C 98 0C C4 9C 6B 37 04  // .o.B.3.......k7.
    04D0: 9D 98 0C 44 9D 33 92 83 9D 6F D9 C2 9D BC FB 01  // ...D.3...o......
    04E0: 9E 8B 16 41 9E 87 46 80 9E 13 A3 CF 9E EA 3A 0F  // ...A..F.......:.
    04F0: 9F 59 12 4F 9F 67 23 8F 9F B8 5F CF 9F CC B3 0F  // .Y.O.g#..._.....
    0500: A0 E7 0A 40 A0 D5 52 80 A0 ED 7E C0 A0 C4 89 00  // ...@..R...~.....
    0510: A1 5A 75 40 A1 D5 49 80 A1 33 13 C0 A1 6D DE 0F  // .Zu@..I..3...m..
    0520: A2 AF B6 4F A2 39 A3 8F A2 3A A6 CF A2 DB BC 0F  // ...O.9...:......
    0530: A3 4C E0 4F A3 99 07 80 A3 C6 29 C0 A3 C0 3F 00  // .L.O......)...?.
    0540: A4 B6 45 40 A4 AF 3B 80 A4 31 25 C0 A4 38 08 00  // ..E@..;..1%..8..
    0550: A5 B1 EB 4F A5 E8 D5 8F A5 2C CB CF A5 09 CD 0F  // ...O.....,......
    0560: A6 21 DA 4F A6 B6 EE 8F A6 A6 05 C0 A6 AA 19 00  // .!.O............
    0570: A7 84 26 40 A7 D9 29 80 A7 99 23 C0 A7 D6 15 00  // ..&@..)...#.....
    0580: A8 27 04 40 A8 C3 F2 8F A8 83 E5 CF A8 12 DF 0F  // .'.@............
    0590: A9 66 E0 4F A9 AB E8 8F A9 8F F5 CF A9 E4 03 00  // .f.O............
    05A0: AA 61 10 40 AA 5F 18 80 AA 67 1A C0 AA 6D 16 00  // .a.@._...g...m..
    05B0: AB BD 0D 40 AB 96 02 80 AB 9D F7 CF AB 3D EF 0F  // ...@.........=..
    05C0: AC 25 EB 4F AC F1 EB 8F AC 20 F1 CF AC 3E F9 0F  // .%.O..... ...>..
    05D0: AD 4F 02 40 AD 42 0A 80 AD 69 0F C0 AD D3 10 00  // .O.@.B...i......
    05E0: AE 72 0E 40 AE 0E 09 80 AE 0C 02 C0 AE 11 FB 0F  // .r.@............
    05F0: AF A5 F5 4F AF DD F2 8F AF 26 F3 CF AF 3C F6 0F  // ...O.....&...<..
    0600: B0 43 FB 4F B0 FF 00 80 B0 27 06 C0 B0 A4 09 00  // .C.O.....'......
    0610: B1 D0 0A 40 B1 8F 09 80 B1 4C 06 C0 B1 DA 01 00  // ...@.....L......
    0620: B2 3D FD 4F B2 75 F9 8F B2 45 F7 CF B2 0F F7 0F  // .=.O.u...E......
    0630: B3 C8 F8 4F B3 FF FB 8F B3 FC FF CF B3 E9 03 00  // ...O............
    0640: B4 FD 06 40 B4 A2 08 80 B4 8B 08 C0 B4 C0 06 00  // ...@............
    0650: B5 92 03 40 B5 88 FF 8F B5 3F FB CF B5 51 F7 0F  // ...@.....?...Q..
    0660: B6 3B F4 4F B6 4A F2 8F B6 97 F1 CF B6 0B F2 0F  // .;.O.J..........
    0670: B7 6C F3 4F B7 67 F5 8F B7 A8 F7 CF B7 E2 F9 0F  // .l.O.g..........
    0680: B8 DD FB 4F B8 76 FD 8F B8 A2 FE CF B8 67 FF 0F  // ...O.v.......g..
    0690: B9 D7 FF 4F B9 0A 00 80 B9 18 00 C0 B9 1B 00 00  // ...O............
    06A0: BA 01 C0 00 00 03 18 00 0B 00 00 00 00 03 0E 00  // ................
    06B0: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    06C0: 00 91 00 00 00 76 00 01 00 00 00 00 00 00 00 00  // .....v..........
    06D0: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    06E0: 00 91 00 00 00 E8 01 05 00 00 00 00 00 00 00 00  // ................
    06F0: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0700: 00 49 00 00 40 81 01 40 40 6D 03 80 40 53 04 C0  // .I..@..@@m..@S..
    0710: 40 78 02 00 41 19 FF 4F 41 ED FD 8F 41 37 00 C0  // @x..A..OA...A7..
    0720: 41 45 02 00 42 8C 00 40 42 9B FD 8F 42 9D FE CF  // AE..B..@B...B...
    0730: 42 6C 02 00 43 67 02 40 43 B1 FD 8F 43 25 FC CF  // Bl..Cg.@C...C%..
    0740: 43 6F 01 00 44 21 05 40 44 F3 FF 8F 44 C4 F9 CF  // Co..D!.@D...D...
    0750: 44 F9 FD 0F 45 BF 06 40 45 8E 04 80 45 73 F9 CF  // D...E..@E...Es..
    0760: 45 96 F8 0F 46 72 05 40 46 69 0A 80 46 CF FC CF  // E...Fr.@Fi..F...
    0770: 46 D1 F2 0F 47 A4 FF 4F 47 25 0F 80 47 FC 04 C0  // F...G..OG%..G...
    0780: 47 13 F0 0F 48 93 F5 4F 48 33 0F 80 48 68 10 C0  // G...H..OH3..Hh..
    0790: 48 75 F3 0F 49 99 E9 4F 49 A2 07 80 49 90 1B C0  // Hu..I..OI...I...
    07A0: 49 65 FF 0F 4A C2 E0 4F 4A 99 F7 8F 4A 92 20 C0  // Ie..J..OJ...J. .
    07B0: 4A C4 12 00 4B 03 E1 4F 4B 2C E2 8F 4B F2 19 C0  // J...K..OK,..K...
    07C0: 4B A3 28 00 4C F5 EE 4F 4C 29 CE 8F 4C 84 04 C0  // K.(.L..OL)..L...
    07D0: 4C 40 38 00 4D 2C 0B 40 4D 5E C5 8F 4D E9 E2 CF  // L@8.M,.@M^..M...
    07E0: 4D F5 37 00 4E F8 2F 40 4E 92 D0 8F 4E E1 BD CF  // M.7.N./@N...N...
    07F0: 4E DD 20 00 4F 18 52 40 4F 4F F4 8F 4F B2 A2 CF  // N. .O.R@OO..O...
    0800: 4F 4D F0 0F 50 08 60 40 50 78 2D 80 50 80 A5 CF  // OM..P.`@Px-.P...
    0810: 50 54 B3 0F 51 82 4A 40 51 A2 69 80 51 00 D0 CF  // PT..Q.J@Q.i.Q...
    0820: 51 F5 7E 0F 52 5C 0B 40 52 CF 8E 80 52 52 21 C0  // Q.~.R\.@R...RR!.
    0830: 52 DC 70 0F 53 96 AD 4F 53 06 7F 80 53 C7 82 C0  // R.p.S..OS...S...
    0840: 53 0A A3 0F 54 8D 53 4F 54 C1 28 80 54 14 C8 C0  // S...T.SOT.(.T...
    0850: 54 21 1B 00 55 23 32 4F 55 41 97 8F 55 F2 B6 C0  // T!..U#2OUA..U...
    0860: 55 87 B6 00 56 02 81 4F 56 43 08 8F 56 34 25 C0  // U...V..OVC..V4%.
    0870: 56 19 1C 01 57 7E 50 40 57 24 EE 8E 57 FD 2C CF  // V...W~P@W$..W.,.
    0880: 57 1C C9 00 58 71 47 41 58 01 C6 8F 58 BA 79 CE  // W...XqGAX...X.y.
    0890: 58 6B 6E 0F 59 BE 5E 41 59 00 70 81 59 76 5B CF  // Xkn.Y.^AY.p.Yv[.
    08A0: 59 77 F7 0D 5A AC 51 4F 5A 09 CF 81 5A 53 36 C2  // Yw..Z.QOZ...ZS6.
    08B0: 5A 37 CE 0F 5B A8 3D 4D 5B B8 65 8D 5B EF 50 C0  // Z7..[.=M[.e.[.P.
    08C0: 5B 37 8E 03 5C B2 E2 44 5C A5 11 84 5C A3 59 C2  // [7..\..D\...\.Y.
    08D0: 5C 48 F2 00 5D 0E 3F 40 5D 39 08 80 5D 1B 00 00  // \H..].?@]9..]...
    08E0: 80 18 00 40 80 0A 00 80 80 D7 FF CF 80 67 FF 0F  // ...@.........g..
    08F0: 81 A2 FE 4F 81 76 FD 8F 81 DD FB CF 81 E2 F9 0F  // ...O.v..........
    0900: 82 A8 F7 4F 82 67 F5 8F 82 6C F3 CF 82 0B F2 0F  // ...O.g...l......
    0910: 83 97 F1 4F 83 4A F2 8F 83 3B F4 CF 83 51 F7 0F  // ...O.J...;...Q..
    0920: 84 3F FB 4F 84 88 FF 8F 84 92 03 C0 84 C0 06 00  // .?.O............
    0930: 85 8B 08 40 85 A2 08 80 85 FD 06 C0 85 E9 03 00  // ...@............
    0940: 86 FC FF 4F 86 FF FB 8F 86 C8 F8 CF 86 0F F7 0F  // ...O............
    0950: 87 45 F7 4F 87 75 F9 8F 87 3D FD CF 87 DA 01 00  // .E.O.u...=......
    0960: 88 4C 06 40 88 8F 09 80 88 D0 0A C0 88 A4 09 00  // .L.@............
    0970: 89 27 06 40 89 FF 00 80 89 43 FB CF 89 3C F6 0F  // .'.@.....C...<..
    0980: 8A 26 F3 4F 8A DD F2 8F 8A A5 F5 CF 8A 11 FB 0F  // .&.O............
    0990: 8B 0C 02 40 8B 0E 09 80 8B 72 0E C0 8B D3 10 00  // ...@.....r......
    09A0: 8C 69 0F 40 8C 42 0A 80 8C 4F 02 C0 8C 3E F9 0F  // .i.@.B...O...>..
    09B0: 8D 20 F1 4F 8D F1 EB 8F 8D 25 EB CF 8D 3D EF 0F  // . .O.....%...=..
    09C0: 8E 9D F7 4F 8E 96 02 80 8E BD 0D C0 8E 6D 16 00  // ...O.........m..
    09D0: 8F 67 1A 40 8F 5F 18 80 8F 61 10 C0 8F E4 03 00  // .g.@._...a......
    09E0: 90 8F F5 4F 90 AB E8 8F 90 66 E0 CF 90 12 DF 0F  // ...O.....f......
    09F0: 91 83 E5 4F 91 C3 F2 8F 91 27 04 C0 91 D6 15 00  // ...O.....'......
    0A00: 92 99 23 40 92 D9 29 80 92 84 26 C0 92 AA 19 00  // ..#@..)...&.....
    0A10: 93 A6 05 40 93 B6 EE 8F 93 21 DA CF 93 09 CD 0F  // ...@.....!......
    0A20: 94 2C CB 4F 94 E8 D5 8F 94 B1 EB CF 94 38 08 00  // .,.O.........8..
    0A30: 95 31 25 40 95 AF 3B 80 95 B6 45 C0 95 C0 3F 00  // .1%@..;...E...?.
    0A40: 96 C6 29 40 96 99 07 80 96 4C E0 CF 96 DB BC 0F  // ..)@.....L......
    0A50: 97 3A A6 4F 97 39 A3 8F 97 AF B6 CF 97 6D DE 0F  // .:.O.9.......m..
    0A60: 98 33 13 40 98 D5 49 80 98 5A 75 C0 98 C4 89 00  // .3.@..I..Zu.....
    0A70: 99 ED 7E 40 99 D5 52 80 99 E7 0A C0 99 CC B3 0F  // ..~@..R.........
    0A80: 9A B8 5F 4F 9A 67 23 8F 9A 59 12 CF 9A EA 3A 0F  // .._O.g#..Y....:.
    0A90: 9B 13 A3 4F 9B 87 46 80 9B 8B 16 C1 9B BC FB 01  // ...O..F.........
    0AA0: 9C 6F D9 42 9C 33 92 83 9C 98 0C C4 9C 6B 37 04  // .o.B.3.......k7.
    0AB0: 9D 98 0C 44 9D 33 92 83 9D 6F D9 C2 9D BC FB 01  // ...D.3...o......
    0AC0: 9E 8B 16 41 9E 87 46 80 9E 13 A3 CF 9E EA 3A 0F  // ...A..F.......:.
    0AD0: 9F 59 12 4F 9F 67 23 8F 9F B8 5F CF 9F CC B3 0F  // .Y.O.g#..._.....
    0AE0: A0 E7 0A 40 A0 D5 52 80 A0 ED 7E C0 A0 C4 89 00  // ...@..R...~.....
    0AF0: A1 5A 75 40 A1 D5 49 80 A1 33 13 C0 A1 6D DE 0F  // .Zu@..I..3...m..
    0B00: A2 AF B6 4F A2 39 A3 8F A2 3A A6 CF A2 DB BC 0F  // ...O.9...:......
    0B10: A3 4C E0 4F A3 99 07 80 A3 C6 29 C0 A3 C0 3F 00  // .L.O......)...?.
    0B20: A4 B6 45 40 A4 AF 3B 80 A4 31 25 C0 A4 38 08 00  // ..E@..;..1%..8..
    0B30: A5 B1 EB 4F A5 E8 D5 8F A5 2C CB CF A5 09 CD 0F  // ...O.....,......
    0B40: A6 21 DA 4F A6 B6 EE 8F A6 A6 05 C0 A6 AA 19 00  // .!.O............
    0B50: A7 84 26 40 A7 D9 29 80 A7 99 23 C0 A7 D6 15 00  // ..&@..)...#.....
    0B60: A8 27 04 40 A8 C3 F2 8F A8 83 E5 CF A8 12 DF 0F  // .'.@............
    0B70: A9 66 E0 4F A9 AB E8 8F A9 8F F5 CF A9 E4 03 00  // .f.O............
    0B80: AA 61 10 40 AA 5F 18 80 AA 67 1A C0 AA 6D 16 00  // .a.@._...g...m..
    0B90: AB BD 0D 40 AB 96 02 80 AB 9D F7 CF AB 3D EF 0F  // ...@.........=..
    0BA0: AC 25 EB 4F AC F1 EB 8F AC 20 F1 CF AC 3E F9 0F  // .%.O..... ...>..
    0BB0: AD 4F 02 40 AD 42 0A 80 AD 69 0F C0 AD D3 10 00  // .O.@.B...i......
    0BC0: AE 72 0E 40 AE 0E 09 80 AE 0C 02 C0 AE 11 FB 0F  // .r.@............
    0BD0: AF A5 F5 4F AF DD F2 8F AF 26 F3 CF AF 3C F6 0F  // ...O.....&...<..
    0BE0: B0 43 FB 4F B0 FF 00 80 B0 27 06 C0 B0 A4 09 00  // .C.O.....'......
    0BF0: B1 D0 0A 40 B1 8F 09 80 B1 4C 06 C0 B1 DA 01 00  // ...@.....L......
    0C00: B2 3D FD 4F B2 75 F9 8F B2 45 F7 CF B2 0F F7 0F  // .=.O.u...E......
    0C10: B3 C8 F8 4F B3 FF FB 8F B3 FC FF CF B3 E9 03 00  // ...O............
    0C20: B4 FD 06 40 B4 A2 08 80 B4 8B 08 C0 B4 C0 06 00  // ...@............
    0C30: B5 92 03 40 B5 88 FF 8F B5 3F FB CF B5 51 F7 0F  // ...@.....?...Q..
    0C40: B6 3B F4 4F B6 4A F2 8F B6 97 F1 CF B6 0B F2 0F  // .;.O.J..........
    0C50: B7 6C F3 4F B7 67 F5 8F B7 A8 F7 CF B7 E2 F9 0F  // .l.O.g..........
    0C60: B8 DD FB 4F B8 76 FD 8F B8 A2 FE CF B8 67 FF 0F  // ...O.v.......g..
    0C70: B9 D7 FF 4F B9 0A 00 80 B9 18 00 C0 B9 1B 00 00  // ...O............
    0C80: BA 00 AA 01 00 00 03 00 86 80 30 AE 01 00 01 00  // ..........0.....
    0C90: 00 00 00 00 02 01 00 00 00 00 03 FE FF 01 00 40  // ...............@
    0CA0: 1F 00 00 80 3E 00 00 02 00 10 00 16 00 10 00 04  // ....>...........
    0CB0: 00 00 00 01 00 00 00 00 00 10 00 80 00 00 AA 00  // ................
    0CC0: 38 9B 71 54 00 00 00 00 00 00 00 F0 FF FF FF 00  // 8.qT............
    0CD0: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0CE0: 00 00 00 00 00 00 00 00 00 00 00 3F 00 C0 80 00  // ...........?....
    0CF0: 00 40 D3 00 00 00 00 05 00 00 02 01 00 00 00 01  // .@..............
    0D00: 00 00 00 02 40 00 00 00 00 00 00 00 00 02 07 00  // ....@...........
    0D10: 00 00 00 01 00 00 00 00 00 00 00 FE FF 01 00 80  // ................
    0D20: 3E 00 00 00 7D 00 00 02 00 10 00 16 00 10 00 04  // >...}...........
    0D30: 00 00 00 01 00 00 00 00 00 10 00 80 00 00 AA 00  // ................
    0D40: 38 9B 71 54 00 00 00 00 00 00 00 F0 FF FF FF 00  // 8.qT............
    0D50: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0D60: 00 00 00 00 00 00 00 00 00 00 00 3F 00 C0 80 00  // ...........?....
    0D70: 00 40 D3 00 00 00 00 05 00 00 02 01 00 00 00 01  // .@..............
    0D80: 00 00 00 02 40 00 00 00 00 00 00 00 00 02 07 00  // ....@...........
    0D90: 00 00 00 01 00 00 00 00 00 00 00 FE FF 02 00 80  // ................
    0DA0: BB 00 00 00 EE 02 00 04 00 10 00 16 00 10 00 03  // ................
    0DB0: 00 00 00 01 00 00 00 00 00 10 00 80 00 00 AA 00  // ................
    0DC0: 38 9B 71 64 00 00 00 00 00 00 00 10 FF FF FF FF  // 8.qd............
    0DD0: FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF  // ................
    0DE0: FF FF FF FF FF FF FF FF FF FF FF 7F 18 C0 C1 00  // ................
    0DF0: 00 70 C0 00 00 00 00 05 02 01 02 03 00 00 00 03  // .p..............
    0E00: 00 00 00 02 40 00 00 00 00 00 00 00 0F 07 07 20  // ....@.......... 
    0E10: 00 00 00 01 00 00 00 FF 0F 00 00 00 00 00 00 08  // ................
    0E20: 00 00 00 01 00 00 00 01 00 00 00 00 1A 01 00 00  // ................
    0E30: 03 00 86 80 30 AE 01 00 01 00 00 00 00 01 02 01  // ....0...........
    0E40: 00 00 00 00 02 FE FF 01 00 40 1F 00 00 80 3E 00  // .........@....>.
    0E50: 00 02 00 10 00 16 00 10 00 04 00 00 00 01 00 00  // ................
    0E60: 00 00 00 10 00 80 00 00 AA 00 38 9B 71 54 00 00  // ..........8.qT..
    0E70: 00 00 00 00 00 F0 FF FF FF 00 00 00 00 00 00 00  // ................
    0E80: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0E90: 00 00 00 00 00 3F 00 C0 80 00 00 40 D3 00 00 00  // .....?.....@....
    0EA0: 00 05 00 00 02 01 00 00 00 01 00 00 00 02 40 00  // ..............@.
    0EB0: 00 00 00 00 00 00 00 02 07 00 00 00 00 01 00 00  // ................
    0EC0: 00 00 00 00 00 FE FF 01 00 80 3E 00 00 00 7D 00  // ..........>...}.
    0ED0: 00 02 00 10 00 16 00 10 00 04 00 00 00 01 00 00  // ................
    0EE0: 00 00 00 10 00 80 00 00 AA 00 38 9B 71 54 00 00  // ..........8.qT..
    0EF0: 00 00 00 00 00 F0 FF FF FF 00 00 00 00 00 00 00  // ................
    0F00: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0F10: 00 00 00 00 00 3F 00 C0 80 00 00 40 D3 00 00 00  // .....?.....@....
    0F20: 00 05 00 00 02 01 00 00 00 01 00 00 00 02 40 00  // ..............@.
    0F30: 00 00 00 00 00 00 00 02 07 00 00 00 00 01 00 00  // ................
    0F40: 00 00 00 00 00 00 04 00 00 00 DE AD BE EF        // ..............
