/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20230628 (64-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembly of /home/eclypsium/Downloads/output/uefi2.dat, Tue Jul 29 10:46:19 2025
 *
 * ACPI Data Table [UEFI]
 *
 * Format: [HexOffset DecimalOffset ByteLength]  FieldName : FieldValue (in hex)
 */

[000h 0000 004h]                   Signature : "UEFI"    [UEFI Boot Optimization Table]
[004h 0004 004h]                Table Length : 0000005C
[008h 0008 001h]                    Revision : 01
[009h 0009 001h]                    Checksum : E5
[00Ah 0010 006h]                      Oem ID : "INTEL"
[010h 0016 008h]                Oem Table ID : "RstVmdV"
[018h 0024 004h]                Oem Revision : 00000000
[01Ch 0028 004h]             Asl Compiler ID : "INTL"
[020h 0032 004h]       Asl Compiler Revision : 00000000

[024h 0036 010h]             UUID Identifier : E4DD92E0-AC7D-11DF-94E2-0800200C9A66
[034h 0052 002h]                 Data Offset : 0036

Raw Table Data: Length 92 (0x5C)

    0000: 55 45 46 49 5C 00 00 00 01 E5 49 4E 54 45 4C 00  // UEFI\.....INTEL.
    0010: 52 73 74 56 6D 64 56 00 00 00 00 00 49 4E 54 4C  // RstVmdV.....INTL
    0020: 00 00 00 00 E0 92 DD E4 7D AC DF 11 94 E2 08 00  // ........}.......
    0030: 20 0C 9A 66 36 00 24 56 45 52 02 02 13 00 05 00  //  ..f6.$VER......
    0040: 00 00 2C 16 26 74 37 00 7E 00 06 00 20 00 02 04  // ..,.&t7.~... ...
    0050: 37 00 00 AF 25 00 00 02 3B CE 00 00              // 7...%...;...
